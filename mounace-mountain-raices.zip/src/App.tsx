import React, { useEffect, useRef, useState, useCallback } from 'react';
import { 
  GameStatus, 
  PlayerProgress, 
  CharacterId, 
  CharacterCustomization, 
  RunStats, 
  ActivePowerUp, 
  TrickEvent,
  WeatherInfo,
  MapTheme,
  DifficultyLevel,
  GameModeId
} from './types/game';
import { CHARACTERS, getInitialProgress, saveProgress } from './game/charactersConfig';
import { GameEngine } from './game/gameEngine';
import { sound } from './game/audio';
import { TitleScreen } from './components/TitleScreen';
import { CustomizerModal } from './components/CustomizerModal';
import { InGameHUD } from './components/InGameHUD';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { DailyChallengesModal } from './components/DailyChallengesModal';
import { LoadingScreen } from './components/LoadingScreen';
import { VipModal } from './components/VipModal';
import { LuckySpinModal } from './components/LuckySpinModal';
import { PowerTapModal } from './components/PowerTapModal';
import { MountainQuizModal } from './components/MountainQuizModal';
import { QuickWashModal } from './components/QuickWashModal';
import { DailyGiftModal } from './components/DailyGiftModal';
import { MysteryBoxModal } from './components/MysteryBoxModal';
import { HalloweenJumpscareModal } from './components/HalloweenJumpscareModal';
import { loadDailyChallenges } from './game/dailyChallenges';
import { SupportedLanguage, getSavedLanguage, saveLanguage } from './game/i18n';

export default function App() {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // App Initial Loading Screen
  const [isLoading, setIsLoading] = useState(true);
  const [showHalloweenJumpscare, setShowHalloweenJumpscare] = useState(false);

  // Language state (Persisted in localStorage)
  const [language, setLanguage] = useState<SupportedLanguage>(getSavedLanguage);

  const handleSelectLanguage = useCallback((lang: SupportedLanguage) => {
    setLanguage(lang);
    saveLanguage(lang);
  }, []);

  // Persistent Player Progress State
  const [progress, setProgress] = useState<PlayerProgress>(getInitialProgress);

  // Daily challenges UI state
  const [showDailyChallenges, setShowDailyChallenges] = useState(false);
  const [unclaimedChallengesCount, setUnclaimedChallengesCount] = useState(0);
  const [invertSteering, setInvertSteering] = useState(false);
  const [activeMiniGame, setActiveMiniGame] = useState<'spin' | 'tap' | 'quiz' | 'wash' | 'gift' | null>(null);
  const [showVipModal, setShowVipModal] = useState(false);
  const [showMysteryBoxModal, setShowMysteryBoxModal] = useState(false);
  const [webGlError, setWebGlError] = useState<string | null>(null);

  const handleToggleInvertSteering = useCallback(() => {
    setInvertSteering((prev) => {
      const next = !prev;
      if (engineRef.current) {
        engineRef.current.setInvertSteering(next);
      }
      return next;
    });
  }, []);

  // Active Game State
  const [gameStatus, setGameStatus] = useState<GameStatus>('title');
  const [stats, setStats] = useState<RunStats>({
    distance: 0,
    speed: 0,
    topSpeed: 0,
    score: 0,
    multiplier: 1,
    coinsCollected: 0,
    gemsCollected: 0,
    gatesPassed: 0,
    tricksLanded: 0,
    airtimeTotal: 0,
    nearMisses: 0,
    isDoubleCoinsActive: false,
  });

  const [weather, setWeather] = useState<WeatherInfo | null>(null);
  const [activePowerUps, setActivePowerUps] = useState<ActivePowerUp[]>([]);
  const [recentTrick, setRecentTrick] = useState<TrickEvent | null>(null);
  const [nearMissFlash, setNearMissFlash] = useState(false);
  const [isNewHighScore, setIsNewHighScore] = useState(false);

  // Active character reference
  const activeCharDef = CHARACTERS.find((c) => c.id === progress.selectedCharacter) || CHARACTERS[0];
  const activeCustomization = progress.customizations[activeCharDef.id] || activeCharDef.defaultCustomization;

  const refreshUnclaimedCount = useCallback(() => {
    try {
      const challenges = loadDailyChallenges();
      const ready = challenges.filter(c => c.completed && !c.claimed).length;
      setUnclaimedChallengesCount(ready);
    } catch {
      // fallback
    }
  }, []);

  useEffect(() => {
    refreshUnclaimedCount();
  }, [refreshUnclaimedCount]);

  // Refs for callbacks so stable WebGL loop doesn't re-mount
  const callbacksRef = useRef({
    onStatsUpdate: (newStats: RunStats) => {
      setStats({ ...newStats });
    },
    onWeatherUpdate: (w: WeatherInfo) => {
      setWeather(w);
    },
    onPowerUpsUpdate: (powerUps: ActivePowerUp[]) => {
      setActivePowerUps([...powerUps]);
    },
    onTrick: (trick: TrickEvent) => {
      setRecentTrick(trick);
    },
    onNearMiss: () => {
      setNearMissFlash(true);
      setTimeout(() => setNearMissFlash(false), 900);
    },
    onGatePassed: () => {
      // Triggered on slalom gate
    },
    onShieldLost: () => {
      // Triggered when shield absorbs hit
    },
    onGameOver: (finalStats: RunStats) => {
      // Update persistent progress
      setProgress((prev) => {
        const isHigh = finalStats.score > prev.highScore;
        setIsNewHighScore(isHigh);

        const updated: PlayerProgress = {
          ...prev,
          coins: prev.coins + finalStats.coinsCollected,
          gems: prev.gems + finalStats.gemsCollected,
          highScore: Math.max(prev.highScore, finalStats.score),
          maxDistance: Math.max(prev.maxDistance, finalStats.distance),
        };
        saveProgress(updated);
        return updated;
      });

      refreshUnclaimedCount();

      // User requirement: Jumpscare in Halloween Mansion
      const isHalloween = (engineRef.current?.getMapTheme() || progress.selectedMap) === 'halloween';
      if (isHalloween) {
        setShowHalloweenJumpscare(true);
      } else {
        setGameStatus('gameover');
      }
    },
  });

  // Initialize Three.js Game Engine once on mount with safety
  useEffect(() => {
    if (!canvasMountRef.current) return;

    sound.setMuted(!progress.soundEnabled);

    try {
      const engine = new GameEngine(
        canvasMountRef.current,
        activeCharDef,
        activeCustomization,
        {
          onStatsUpdate: (s) => callbacksRef.current.onStatsUpdate(s),
          onWeatherUpdate: (w) => callbacksRef.current.onWeatherUpdate(w),
          onPowerUpsUpdate: (p) => callbacksRef.current.onPowerUpsUpdate(p),
          onTrick: (t) => callbacksRef.current.onTrick(t),
          onNearMiss: () => callbacksRef.current.onNearMiss(),
          onGatePassed: () => callbacksRef.current.onGatePassed(),
          onShieldLost: () => callbacksRef.current.onShieldLost(),
          onGameOver: (f) => callbacksRef.current.onGameOver(f),
        },
        progress.selectedMap || 'snow'
      );

      engineRef.current = engine;
      setWebGlError(null);

      return () => {
        try {
          engine.dispose();
        } catch (e) {
          console.warn('Error during engine dispose:', e);
        }
        engineRef.current = null;
      };
    } catch (err: any) {
      console.error('WebGL Engine initialization caught error:', err);
      setWebGlError(err?.message || 'WebGL context could not be created');
    }
  }, []); // Run once!

  // Map theme selection (Snowy Alpine vs Sandy Beach vs Halloween Mansion vs High School)
  const handleSelectMap = useCallback((theme: MapTheme) => {
    setProgress((prev) => {
      const updated: PlayerProgress = { ...prev, selectedMap: theme };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.setMapTheme(theme);
    }
  }, []);

  // Map unlocking with coins/gems
  const handleUnlockMap = useCallback((theme: MapTheme, costCoins: number, costGems: number) => {
    setProgress((prev) => {
      if (prev.coins < costCoins || prev.gems < costGems) return prev;
      const currentUnlocked = prev.unlockedMaps || ['snow', 'beach'];
      const updatedUnlocked = currentUnlocked.includes(theme)
        ? currentUnlocked
        : [...currentUnlocked, theme];
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins - costCoins,
        gems: prev.gems - costGems,
        unlockedMaps: updatedUnlocked,
        selectedMap: theme,
      };
      saveProgress(updated);
      return updated;
    });

    sound.playGem();
    sound.playZoneTransition();

    if (engineRef.current) {
      engineRef.current.setMapTheme(theme);
    }
  }, []);

  // Handle Game State Transitions
  const handleStartGame = useCallback(() => {
    sound.stopLobbyMusic();
    if (engineRef.current) {
      if (progress.selectedGameMode) {
        engineRef.current.setGameMode(progress.selectedGameMode);
      }
      engineRef.current.syncGear(progress);
      engineRef.current.startGame(progress);
      setGameStatus('playing');
    }
  }, [progress]);

  const handlePauseGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.pauseGame();
      setGameStatus('paused');
    }
  }, []);

  const handleResumeGame = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.syncGear(progress);
      engineRef.current.resumeGame();
      setGameStatus('playing');
    }
  }, [progress]);

  const handleRestartGame = useCallback(() => {
    if (engineRef.current) {
      if (progress.selectedGameMode) {
        engineRef.current.setGameMode(progress.selectedGameMode);
      }
      engineRef.current.syncGear(progress);
      engineRef.current.startGame(progress);
      setGameStatus('playing');
    }
  }, [progress]);

  const handleSelectDifficulty = useCallback((diff: DifficultyLevel) => {
    setProgress((prev) => {
      const updated: PlayerProgress = { ...prev, selectedDifficulty: diff };
      saveProgress(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setDifficulty(diff);
    }
  }, []);

  const handleSelectGameMode = useCallback((mode: GameModeId) => {
    setProgress((prev) => {
      const updated: PlayerProgress = { ...prev, selectedGameMode: mode };
      saveProgress(updated);
      return updated;
    });
    if (engineRef.current) {
      engineRef.current.setGameMode(mode);
    }
  }, []);

  const handleRevive = useCallback(() => {
    if (!progress.isVip) {
      if (progress.gems < 30) return;
      setProgress((prev) => {
        const updated: PlayerProgress = {
          ...prev,
          gems: prev.gems - 30,
        };
        saveProgress(updated);
        return updated;
      });
    }

    if (engineRef.current) {
      engineRef.current.revivePlayer();
    }
    setGameStatus('playing');
  }, [progress.isVip, progress.gems]);

  const handleOpenCustomizer = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.setStatus('customize');
    }
    setGameStatus('customize');
  }, []);

  const handleCloseCustomizer = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.setStatus('title');
    }
    setGameStatus('title');
  }, []);

  const handleSelectCharacter = useCallback((id: CharacterId) => {
    const char = CHARACTERS.find((c) => c.id === id);
    if (!char) return;

    const custom = progress.customizations[id] || char.defaultCustomization;

    setProgress((prev) => {
      const updated = { ...prev, selectedCharacter: id };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.loadCharacter(char, custom, progress.selectedMap);
    }
  }, [progress.customizations, progress.selectedMap]);

  const handleUpdateCustomization = useCallback((charId: CharacterId, newCustom: CharacterCustomization) => {
    setProgress((prev) => {
      const updated = {
        ...prev,
        customizations: {
          ...prev.customizations,
          [charId]: newCustom,
        },
      };
      saveProgress(updated);
      return updated;
    });

    if (engineRef.current) {
      engineRef.current.updateCustomization(newCustom);
    }
  }, []);

  const handleUnlockCharacter = useCallback((charId: CharacterId, cost: number) => {
    setProgress((prev) => {
      if (prev.coins < cost) return prev;
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins - cost,
        unlockedCharacters: [...prev.unlockedCharacters, charId],
        selectedCharacter: charId,
      };
      saveProgress(updated);
      return updated;
    });

    const char = CHARACTERS.find((c) => c.id === charId);
    if (char && engineRef.current) {
      engineRef.current.loadCharacter(char, char.defaultCustomization, progress.selectedMap);
    }
  }, [progress.selectedMap]);

  const handleClaimChallengeReward = useCallback((rewardCoins: number) => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins + rewardCoins,
      };
      saveProgress(updated);
      return updated;
    });
    refreshUnclaimedCount();
  }, [refreshUnclaimedCount]);

  const handleToggleSound = useCallback(() => {
    const isMuted = sound.toggleMute();
    setProgress((prev) => {
      const updated = { ...prev, soundEnabled: !isMuted };
      saveProgress(updated);
      return updated;
    });
  }, []);

  // Keyboard shortcut for pausing during active play
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        if (showDailyChallenges) {
          setShowDailyChallenges(false);
        } else if (gameStatus === 'playing') {
          handlePauseGame();
        } else if (gameStatus === 'paused') {
          handleResumeGame();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameStatus, showDailyChallenges, handlePauseGame, handleResumeGame]);

  const handleCycleWeather = useCallback(() => {
    if (engineRef.current) engineRef.current.cycleWeather();
  }, []);

  // Touch handlers for mobile
  const handleSteerTouch = (val: number) => {
    if (engineRef.current) engineRef.current.setVirtualSteer(val);
  };
  const handleJumpTouch = () => {
    if (engineRef.current) engineRef.current.triggerVirtualJump();
  };
  const handleBoostTouch = (active: boolean) => {
    if (engineRef.current) engineRef.current.setVirtualBoost(active);
  };

  // Mini-game and VIP UI handlers
  const handleOpenLuckySpin = useCallback(() => setActiveMiniGame('spin'), []);
  const handleOpenPowerTap = useCallback(() => setActiveMiniGame('tap'), []);
  const handleOpenQuiz = useCallback(() => setActiveMiniGame('quiz'), []);
  const handleOpenQuickWash = useCallback(() => setActiveMiniGame('wash'), []);
  const handleOpenDailyGift = useCallback(() => setActiveMiniGame('gift'), []);
  const handleCloseMiniGame = useCallback(() => setActiveMiniGame(null), []);

  const handleBuyVip = useCallback(() => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins + 1000000,
        gems: Math.max(0, prev.gems - 1000),
        isVip: true,
      };
      saveProgress(updated);
      if (engineRef.current) {
        engineRef.current.setVip(true);
      }
      return updated;
    });
  }, []);

  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.syncGear(progress);
    }
  }, [
    progress.isVip,
    progress.selectedDifficulty,
    progress.magnetLevel,
    progress.shieldCharges,
    progress.doubleCoinsPerma,
    progress.gliderWings,
    progress.selectedAuraTrail,
  ]);

  // Lobby Music loop for main screen and customization
  useEffect(() => {
    if (!progress.soundEnabled) {
      sound.stopLobbyMusic();
      return;
    }
    if (gameStatus === 'title' || gameStatus === 'customize') {
      sound.startLobbyMusic();
    } else {
      sound.stopLobbyMusic();
    }
    return () => {
      sound.stopLobbyMusic();
    };
  }, [gameStatus, progress.soundEnabled]);

  const handleMiniGameReward = useCallback((rewardCoins: number, rewardGems: number, extraDate?: string, extraStreak?: number) => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: Math.max(0, prev.coins + rewardCoins),
        gems: Math.max(0, prev.gems + rewardGems),
        lastDailyClaimDate: extraDate !== undefined ? extraDate : prev.lastDailyClaimDate,
        dailyStreak: extraStreak !== undefined ? extraStreak : prev.dailyStreak,
      };
      saveProgress(updated);
      return updated;
    });
  }, []);

  const handleUpdatePlayerProgress = useCallback((updater: (prev: PlayerProgress) => PlayerProgress) => {
    setProgress((prev) => {
      const updated = updater(prev);
      saveProgress(updated);
      if (engineRef.current) {
        engineRef.current.syncGear(updated);
      }
      return updated;
    });
  }, []);

  // Mystery Box Unboxing Handlers
  const handleUnlockCharacterFromBox = useCallback((newCharId: CharacterId) => {
    setProgress((prev) => {
      if (prev.unlockedCharacters.includes(newCharId)) return prev;
      const updated: PlayerProgress = {
        ...prev,
        unlockedCharacters: [...prev.unlockedCharacters, newCharId],
        selectedCharacter: newCharId,
      };
      saveProgress(updated);
      return updated;
    });

    const char = CHARACTERS.find((c) => c.id === newCharId);
    if (char && engineRef.current) {
      engineRef.current.loadCharacter(char, char.defaultCustomization, progress.selectedMap);
    }
  }, [progress.selectedMap]);

  const handleAddCurrency = useCallback((coinsToAdd: number, gemsToAdd: number) => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: prev.coins + coinsToAdd,
        gems: prev.gems + gemsToAdd,
      };
      saveProgress(updated);
      return updated;
    });
  }, []);

  const handleDeductCurrency = useCallback((coinsToDeduct: number, gemsToDeduct: number) => {
    setProgress((prev) => {
      const updated: PlayerProgress = {
        ...prev,
        coins: Math.max(0, prev.coins - coinsToDeduct),
        gems: Math.max(0, prev.gems - gemsToDeduct),
      };
      saveProgress(updated);
      return updated;
    });
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans">
      {/* 1. Isolated WebGL Canvas Mount Container */}
      <div 
        ref={canvasMountRef} 
        className="absolute inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing" 
      />

      {/* WebGL Context Recovery Banner if GPU context is lost */}
      {webGlError && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 border border-amber-500/70 rounded-2xl p-3.5 px-5 text-center shadow-2xl backdrop-blur-md max-w-sm">
          <div className="text-amber-300 font-race font-bold text-xs uppercase tracking-wider">
            3D Graphics Context Reset
          </div>
          <div className="text-slate-300 text-[11px] mt-0.5 mb-2.5">
            Browser GPU context was reset. Tap below to reload 3D mountain graphics.
          </div>
          <button
            onClick={() => window.location.reload()}
            className="px-4 py-1.5 bg-gradient-to-r from-amber-400 to-yellow-400 hover:brightness-110 text-slate-950 rounded-xl font-race font-black text-xs cursor-pointer shadow-md"
          >
            RESTORE 3D GRAPHICS
          </button>
        </div>
      )}

      {/* 2. UI Overlays (Full Viewport Game Shell) */}
      {gameStatus === 'title' && (
        <TitleScreen
          progress={progress}
          activeCharacter={activeCharDef}
          onStart={handleStartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onToggleSound={handleToggleSound}
          onSelectMap={handleSelectMap}
          onUnlockMap={handleUnlockMap}
          onOpenDailyChallenges={() => setShowDailyChallenges(true)}
          unclaimedChallengesCount={unclaimedChallengesCount}
          onOpenVip={() => setShowVipModal(true)}
          onOpenMysteryBox={() => setShowMysteryBoxModal(true)}
          onOpenLuckySpin={handleOpenLuckySpin}
          onOpenPowerTap={handleOpenPowerTap}
          onOpenQuiz={handleOpenQuiz}
          onOpenQuickWash={handleOpenQuickWash}
          onOpenDailyGift={handleOpenDailyGift}
          onSelectDifficulty={handleSelectDifficulty}
          onSelectGameMode={handleSelectGameMode}
          language={language}
          onSelectLanguage={handleSelectLanguage}
        />
      )}

      {gameStatus === 'customize' && (
        <CustomizerModal
          progress={progress}
          onClose={handleCloseCustomizer}
          onSelectCharacter={handleSelectCharacter}
          onUpdateCustomization={handleUpdateCustomization}
          onUnlockCharacter={handleUnlockCharacter}
        />
      )}

      {gameStatus === 'playing' && (
        <InGameHUD
          stats={stats}
          weather={weather}
          activePowerUps={activePowerUps}
          recentTrick={recentTrick}
          nearMissFlash={nearMissFlash}
          soundEnabled={progress.soundEnabled}
          isVip={progress.isVip}
          onPause={handlePauseGame}
          onToggleSound={handleToggleSound}
          onCycleWeather={handleCycleWeather}
          onSteerTouch={handleSteerTouch}
          onJumpTouch={handleJumpTouch}
          onBoostTouch={handleBoostTouch}
        />
      )}

      {gameStatus === 'paused' && (
        <PauseModal
          soundEnabled={progress.soundEnabled}
          invertSteering={invertSteering}
          onResume={handleResumeGame}
          onRestart={handleRestartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onMainMenu={handleCloseCustomizer}
          onToggleSound={handleToggleSound}
          onToggleInvertSteering={handleToggleInvertSteering}
        />
      )}

      {gameStatus === 'gameover' && (
        <GameOverModal
          stats={stats}
          isNewHighScore={isNewHighScore}
          gems={progress.gems}
          isVip={progress.isVip}
          onRevive={handleRevive}
          onRestart={handleRestartGame}
          onOpenCustomizer={handleOpenCustomizer}
          onMainMenu={handleCloseCustomizer}
        />
      )}

      {/* 3. Daily Challenges Modal */}
      {showDailyChallenges && (
        <DailyChallengesModal
          onClose={() => {
            setShowDailyChallenges(false);
            refreshUnclaimedCount();
          }}
          onRewardClaimed={handleClaimChallengeReward}
        />
      )}

      {/* 4. Mini-Games & Admin Modals */}
      {activeMiniGame === 'spin' && (
        <LuckySpinModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          lastSpinTimestamp={progress.lastSpinTimestamp}
          onReward={(coins, gems, ts) => {
            handleMiniGameReward(coins, gems);
            if (ts) {
              setProgress((p) => {
                const upd = { ...p, lastSpinTimestamp: ts };
                saveProgress(upd);
                return upd;
              });
            }
          }}
          onClose={handleCloseMiniGame}
        />
      )}

      {activeMiniGame === 'tap' && (
        <PowerTapModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          onReward={handleMiniGameReward}
          onClose={handleCloseMiniGame}
        />
      )}

      {activeMiniGame === 'quiz' && (
        <MountainQuizModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          onReward={handleMiniGameReward}
          onClose={handleCloseMiniGame}
        />
      )}

      {activeMiniGame === 'wash' && (
        <QuickWashModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          onReward={handleMiniGameReward}
          onClose={handleCloseMiniGame}
        />
      )}

      {activeMiniGame === 'gift' && (
        <DailyGiftModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          lastDailyClaimDate={progress.lastDailyClaimDate}
          dailyStreak={progress.dailyStreak}
          onClaim={(c, g, d, s) => handleMiniGameReward(c, g, d, s)}
          onClose={handleCloseMiniGame}
        />
      )}

      {/* 5. V.I.P Membership Modal */}
      {showVipModal && (
        <VipModal
          coins={progress.coins}
          gems={progress.gems}
          isVip={progress.isVip}
          onBuyVip={handleBuyVip}
          onClose={() => setShowVipModal(false)}
        />
      )}

      {/* 5b. Mystery Box Crate Shop Modal */}
      {showMysteryBoxModal && (
        <MysteryBoxModal
          progress={progress}
          onClose={() => setShowMysteryBoxModal(false)}
          onUnlockCharacter={handleUnlockCharacterFromBox}
          onSelectCharacter={handleSelectCharacter}
          onAddCurrency={handleAddCurrency}
          onDeductCurrency={handleDeductCurrency}
          onUpdateProgress={handleUpdatePlayerProgress}
        />
      )}

      {/* 7. Initial High-Octane Downhill Arcade Loading Screen */}
      {isLoading && (
        <LoadingScreen onLoaded={() => setIsLoading(false)} />
      )}

      {/* 8. Spooky Halloween Mansion Jumpscare Overlay */}
      {showHalloweenJumpscare && (
        <HalloweenJumpscareModal
          onFinished={() => {
            setShowHalloweenJumpscare(false);
            setGameStatus('gameover');
          }}
        />
      )}
    </div>
  );
}
