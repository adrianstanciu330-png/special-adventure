import * as THREE from 'three';
import { PowerUpType, MapTheme } from '../types/game';
import { 
  createSnowDiffuseTexture, 
  createSnowNormalTexture,
  createSandDiffuseTexture,
  createSandNormalTexture,
  createWoodPlankTexture,
  createWoodWallTexture,
  createCemeteryGroundTexture,
  createSchoolHallwayFloorTexture,
  createCyberHighwayFloorTexture,
  createCyberClubFloorTexture,
  createSpringRoadFloorTexture,
  createSpringSakuraBloomFloorTexture,
  createCandyFloorTexture,
  createCandyPalaceFloorTexture,
  createUniverseCosmicRoadTexture,
  createUniversePlanetSurfaceTexture,
  createForestMossyFloorTexture,
  createForestWoodGladeTexture,
  createDinnerTableclothTexture,
  createDinnerGoldClothTexture
} from './textures';
import { DifficultyLevel } from '../types/game';

export type ObstacleType = 
  | 'tree' 
  | 'rock' 
  | 'snowman' 
  | 'log_rail' 
  | 'slalom_gate' 
  | 'icicle' 
  | 'rolling_snowball' 
  | 'thin_ice' 
  | 'tiki' 
  | 'sandcastle' 
  | 'coconut'
  | 'furniture_table'
  | 'furniture_sofa'
  | 'furniture_fireplace'
  | 'furniture_chair'
  | 'furniture_barrel'
  | 'furniture_clock'
  | 'furniture_skirack'
  | 'beach_umbrella'
  | 'surfboard_stand'
  | 'volleyball_net'
  | 'beach_cooler'
  | 'tombstone'
  | 'pumpkin'
  | 'spooky_tree'
  | 'cauldron'
  | 'bookcase'
  | 'candelabra'
  | 'locker_bank'
  | 'wet_floor_cone'
  | 'backpack'
  | 'student_desk'
  | 'chalkboard'
  | 'globe_stand'
  | 'vending_machine'
  | 'mop_bucket'
  | 'gym_hurdle'
  | 'lab_desk'
  | 'trash_bin'
  | 'cyber_pylon'
  | 'holo_barrier'
  | 'neon_cone'
  | 'laser_grid'
  | 'holo_billboard'
  | 'arcade_cabinet'
  | 'dj_booth'
  | 'sakura_tree'
  | 'pastel_tent'
  | 'flower_arch'
  | 'wooden_bench'
  | 'giant_candy_cane'
  | 'lollipop'
  | 'gummy_drop'
  | 'peppermint_swirl'
  | 'cotton_candy_tree'
  | 'space_asteroid'
  | 'satellite_beacon'
  | 'space_crystal'
  | 'energy_gate'
  | 'orbital_capsule'
  | 'redwood_trunk'
  | 'mossy_boulder'
  | 'forest_mushroom'
  | 'ancient_gate'
  | 'spirit_totem'
  | 'dinner_plate'
  | 'dinner_fork'
  | 'dinner_knife'
  | 'dinner_burger'
  | 'dinner_pizza'
  | 'dinner_roast_turkey'
  | 'dinner_ketchup'
  | 'dinner_mustard'
  | 'dinner_donut'
  | string;

export interface ObstacleInstance {
  id: number;
  type: ObstacleType;
  mesh: THREE.Group;
  collider: {
    type: 'box' | 'cylinder' | 'sphere';
    radius: number;
    halfWidth?: number;
    halfLength?: number;
    height: number;
  };
  position: THREE.Vector3;
  isActive: boolean;
  // Dynamic hazard properties
  dynamic?: {
    vy?: number;
    vx?: number;
    vz?: number;
    timer?: number;
    warningCircle?: THREE.Mesh;
    hasTriggered?: boolean;
    isPassed?: boolean;
  };
}

export interface CollectibleInstance {
  id: number;
  type: 'coin' | 'gem' | 'powerup';
  powerUpType?: PowerUpType;
  mesh: THREE.Group;
  position: THREE.Vector3;
  baseY: number;
  isCollected: boolean;
  radius: number;
}

export interface JumpRamp {
  position: THREE.Vector3;
  width: number;
  length: number;
  height: number;
  mesh: THREE.Mesh;
}

interface TerrainChunkRecord {
  mesh: THREE.Mesh;
  oceanLeft?: THREE.Mesh;
  oceanRight?: THREE.Mesh;
  chaletProps?: THREE.Group;
  zStart: number;
  zEnd: number;
  subZone: number;
}

export class MountainTrack {
  public root: THREE.Group;
  public obstacles: ObstacleInstance[] = [];
  public collectibles: CollectibleInstance[] = [];
  public ramps: JumpRamp[] = [];
  public mapTheme: MapTheme = 'snow';
  public currentSubZone: number = 0; // 0 = primary (snow mountain / ocean surf), 1 = alternate (wood chalet house / sunny beach dunes)
  public difficulty: DifficultyLevel = 'normal';

  public setDifficulty(level: DifficultyLevel) {
    this.difficulty = level;
  }

  public getObstacleMultiplier(): number {
    switch (this.difficulty) {
      case 'easy': return 0.55;       // Low obstacle density for smooth cruising
      case 'normal': return 1.0;      // Standard obstacles
      case 'hard': return 1.6;        // +60% obstacles
      case 'insane': return 2.2;      // +120% obstacles
      case 'impossible': return 3.0;  // +200% swarm of obstacles!
      default: return 1.0;
    }
  }

  private terrainChunks: TerrainChunkRecord[] = [];
  private chunkLength = 120;
  private chunkWidth = 60;
  private activeChunkCount = 4;
  private nextObstacleId = 1;
  private nextCollectibleId = 1;

  // Snow Mountain Materials
  private snowMaterial: THREE.MeshPhysicalMaterial;
  private icePatchMaterial: THREE.MeshStandardMaterial;
  private woodMaterial: THREE.MeshStandardMaterial;
  private pineFoliageMaterial: THREE.MeshStandardMaterial;
  private pineSnowMaterial: THREE.MeshStandardMaterial;
  private rockMaterial: THREE.MeshStandardMaterial;

  // Chalet House Materials (Indoor Living Room Lodge)
  private chaletFloorMaterial: THREE.MeshStandardMaterial;
  private chaletWallMaterial: THREE.MeshStandardMaterial;
  private furnitureWoodMaterial: THREE.MeshStandardMaterial;
  private furnitureCushionMaterial: THREE.MeshStandardMaterial;
  private stoneBrickMaterial: THREE.MeshStandardMaterial;
  private fireGlowMaterial: THREE.MeshStandardMaterial;
  private chandelierIronMaterial: THREE.MeshStandardMaterial;
  private lanternGlassMaterial: THREE.MeshBasicMaterial;

  // Beach & Ocean Materials
  private sandMaterial: THREE.MeshPhysicalMaterial;
  private oceanMaterial: THREE.MeshStandardMaterial;
  private palmBarkMaterial: THREE.MeshStandardMaterial;
  private palmFrondMaterial: THREE.MeshStandardMaterial;
  private coconutMaterial: THREE.MeshStandardMaterial;
  private beachRockMaterial: THREE.MeshStandardMaterial;
  private sandcastleMaterial: THREE.MeshStandardMaterial;
  private tikiWoodMaterial: THREE.MeshStandardMaterial;
  private tidePoolMaterial: THREE.MeshStandardMaterial;
  private umbrellaCanopyMaterial: THREE.MeshStandardMaterial;
  private coolerMaterial: THREE.MeshStandardMaterial;

  // Halloween Materials
  private cemeteryGroundMaterial: THREE.MeshStandardMaterial;
  private tombstoneMaterial: THREE.MeshStandardMaterial;
  private pumpkinMaterial: THREE.MeshStandardMaterial;
  private pumpkinGlowMaterial: THREE.MeshBasicMaterial;
  private spookyBarkMaterial: THREE.MeshStandardMaterial;
  private cauldronMaterial: THREE.MeshStandardMaterial;
  private potionMaterial: THREE.MeshBasicMaterial;

  // School Materials
  private schoolHallwayFloorMaterial: THREE.MeshStandardMaterial;
  private lockerBlueMaterial: THREE.MeshStandardMaterial;
  private lockerOrangeMaterial: THREE.MeshStandardMaterial;
  private deskWoodMaterial: THREE.MeshStandardMaterial;
  private chalkboardMaterial: THREE.MeshStandardMaterial;
  private coneHazardMaterial: THREE.MeshStandardMaterial;
  private vendingRedMaterial: THREE.MeshStandardMaterial;
  private mopYellowMaterial: THREE.MeshStandardMaterial;
  private metalHurdleMaterial: THREE.MeshStandardMaterial;

  // Cyber City Materials
  private cyberHighwayFloorMaterial: THREE.MeshStandardMaterial;
  private cyberClubFloorMaterial: THREE.MeshStandardMaterial;
  private neonCyanMaterial: THREE.MeshBasicMaterial;
  private neonPinkMaterial: THREE.MeshBasicMaterial;
  private neonYellowMaterial: THREE.MeshBasicMaterial;
  private cyberMetalMaterial: THREE.MeshStandardMaterial;

  // Spring Blossom Coast Materials
  private springRoadFloorMaterial: THREE.MeshStandardMaterial;
  private springSakuraFloorMaterial: THREE.MeshStandardMaterial;
  private sakuraBarkMaterial: THREE.MeshStandardMaterial;
  private sakuraFoliageMaterial: THREE.MeshStandardMaterial;
  private tentPastelPinkMaterial: THREE.MeshStandardMaterial;
  private tentPastelYellowMaterial: THREE.MeshStandardMaterial;
  private tentPastelBlueMaterial: THREE.MeshStandardMaterial;
  private springBenchWoodMaterial: THREE.MeshStandardMaterial;

  // Candy Kingdom Materials
  private candyFloorMaterial: THREE.MeshStandardMaterial;
  private candyPalaceFloorMaterial: THREE.MeshStandardMaterial;
  private candyCaneMaterial: THREE.MeshStandardMaterial;
  private lollipopSwirlMaterial: THREE.MeshStandardMaterial;
  private gummyRubyMaterial: THREE.MeshStandardMaterial;
  private gummyEmeraldMaterial: THREE.MeshStandardMaterial;
  private peppermintSwirlMaterial: THREE.MeshStandardMaterial;
  private cottonCandyMaterial: THREE.MeshStandardMaterial;

  // The Universe Materials
  private universeRoadMaterial: THREE.MeshStandardMaterial;
  private universePlanetMaterial: THREE.MeshStandardMaterial;
  private asteroidMaterial: THREE.MeshStandardMaterial;
  private cosmicCrystalMaterial: THREE.MeshStandardMaterial;
  private energyRingMaterial: THREE.MeshBasicMaterial;
  private quantumBeaconMaterial: THREE.MeshStandardMaterial;

  // The Deep Forest Materials
  private forestMossMaterial: THREE.MeshStandardMaterial;
  private forestGladeMaterial: THREE.MeshStandardMaterial;
  private redwoodBarkMaterial: THREE.MeshStandardMaterial;
  private mossyRockMaterial: THREE.MeshStandardMaterial;
  private mushroomCapMaterial: THREE.MeshStandardMaterial;
  private totemWoodMaterial: THREE.MeshStandardMaterial;

  // Dinner Time Banquet Materials
  private dinnerTableclothMaterial: THREE.MeshStandardMaterial;
  private dinnerGoldClothMaterial: THREE.MeshStandardMaterial;
  private dinnerPlateMaterial: THREE.MeshPhysicalMaterial;
  private dinnerSteelMaterial: THREE.MeshStandardMaterial;
  private dinnerBunMaterial: THREE.MeshStandardMaterial;
  private dinnerPattyMaterial: THREE.MeshStandardMaterial;
  private dinnerCheeseMaterial: THREE.MeshStandardMaterial;
  private dinnerLettuceMaterial: THREE.MeshStandardMaterial;
  private dinnerPizzaMaterial: THREE.MeshStandardMaterial;
  private dinnerPepperoniMaterial: THREE.MeshStandardMaterial;
  private dinnerTurkeyMaterial: THREE.MeshStandardMaterial;
  private dinnerKetchupMaterial: THREE.MeshStandardMaterial;
  private dinnerMustardMaterial: THREE.MeshStandardMaterial;
  private dinnerDonutMaterial: THREE.MeshStandardMaterial;

  // Collectible Materials
  private coinMaterial: THREE.MeshStandardMaterial;
  private gemMaterial: THREE.MeshStandardMaterial;
  private powerUpMaterials: Record<PowerUpType, THREE.MeshStandardMaterial>;
  private warningMaterial: THREE.MeshBasicMaterial;

  constructor(initialTheme: MapTheme = 'snow') {
    this.mapTheme = initialTheme;
    this.root = new THREE.Group();
    this.root.name = 'mountain_track';

    // 1. Snow Materials
    const snowDiffuse = createSnowDiffuseTexture();
    const snowNormal = createSnowNormalTexture();

    this.snowMaterial = new THREE.MeshPhysicalMaterial({
      map: snowDiffuse,
      normalMap: snowNormal,
      normalScale: new THREE.Vector2(0.8, 0.8),
      roughness: 0.78,
      metalness: 0.04,
      clearcoat: 0.22,
      clearcoatRoughness: 0.4,
    });

    this.icePatchMaterial = new THREE.MeshStandardMaterial({
      color: 0xbae6fd,
      roughness: 0.08,
      metalness: 0.35,
      transparent: true,
      opacity: 0.85,
    });

    this.woodMaterial = new THREE.MeshStandardMaterial({
      color: 0x5c3d2e,
      roughness: 0.85,
      metalness: 0.05,
    });

    this.pineFoliageMaterial = new THREE.MeshStandardMaterial({
      color: 0x164e3b, // Deep forest green
      roughness: 0.8,
      metalness: 0.1,
    });

    this.pineSnowMaterial = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.9,
      metalness: 0.05,
    });

    this.rockMaterial = new THREE.MeshStandardMaterial({
      color: 0x475569,
      roughness: 0.95,
      metalness: 0.15,
      flatShading: true,
    });

    // 2. Chalet House Materials (Warm timber floorboards, cedar walls, cozy furniture)
    const chaletFloorDiffuse = createWoodPlankTexture();
    this.chaletFloorMaterial = new THREE.MeshStandardMaterial({
      map: chaletFloorDiffuse,
      roughness: 0.35,
      metalness: 0.08,
    });

    const chaletWallDiffuse = createWoodWallTexture();
    this.chaletWallMaterial = new THREE.MeshStandardMaterial({
      map: chaletWallDiffuse,
      roughness: 0.75,
      metalness: 0.05,
    });

    this.furnitureWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Warm carved oak
      roughness: 0.55,
      metalness: 0.08,
    });

    this.furnitureCushionMaterial = new THREE.MeshStandardMaterial({
      color: 0x991b1b, // Rich lodge burgundy velvet/leather
      roughness: 0.75,
      metalness: 0.05,
    });

    this.stoneBrickMaterial = new THREE.MeshStandardMaterial({
      color: 0x475569, // Fireplace masonry stone
      roughness: 0.9,
      metalness: 0.1,
      flatShading: true,
    });

    this.fireGlowMaterial = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      emissive: 0xf97316,
      emissiveIntensity: 1.4,
      roughness: 0.3,
    });

    this.chandelierIronMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b,
      metalness: 0.8,
      roughness: 0.3,
    });

    this.lanternGlassMaterial = new THREE.MeshBasicMaterial({
      color: 0xfef08a,
    });

    // 3. Beach & Ocean Materials
    const sandDiffuse = createSandDiffuseTexture();
    const sandNormal = createSandNormalTexture();

    this.sandMaterial = new THREE.MeshPhysicalMaterial({
      map: sandDiffuse,
      normalMap: sandNormal,
      normalScale: new THREE.Vector2(0.85, 0.85),
      roughness: 0.82,
      metalness: 0.02,
      clearcoat: 0.18,
      clearcoatRoughness: 0.35,
    });

    this.oceanMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Tropical azure ocean water
      roughness: 0.06,
      metalness: 0.2,
      transparent: true,
      opacity: 0.92,
    });

    this.palmBarkMaterial = new THREE.MeshStandardMaterial({
      color: 0x78350f, // Segmented tropical palm bark
      roughness: 0.88,
      metalness: 0.05,
    });

    this.palmFrondMaterial = new THREE.MeshStandardMaterial({
      color: 0x16a34a, // Vibrant tropical green
      roughness: 0.7,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });

    this.coconutMaterial = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.85,
      metalness: 0.1,
    });

    this.beachRockMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f766e, // Deep turquoise coral reef spire
      roughness: 0.75,
      metalness: 0.15,
      flatShading: true,
    });

    this.sandcastleMaterial = new THREE.MeshStandardMaterial({
      color: 0xfde047,
      roughness: 0.8,
      metalness: 0.1,
    });

    this.tikiWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0x3f2314, // Dark Polynesian carved wood
      roughness: 0.85,
      metalness: 0.05,
    });

    this.tidePoolMaterial = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.05,
      metalness: 0.2,
      transparent: true,
      opacity: 0.75,
    });

    this.umbrellaCanopyMaterial = new THREE.MeshStandardMaterial({
      color: 0x0284c7, // Tropical azure striped
      roughness: 0.6,
      metalness: 0.1,
    });

    this.coolerMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626, // Bright beach cooler red
      roughness: 0.4,
      metalness: 0.1,
    });

    // 4. Halloween Materials
    this.cemeteryGroundMaterial = new THREE.MeshStandardMaterial({
      map: createCemeteryGroundTexture(),
      roughness: 0.92,
      metalness: 0.05,
    });
    this.tombstoneMaterial = new THREE.MeshStandardMaterial({
      color: 0x475569, // Weathered grey stone
      roughness: 0.88,
      metalness: 0.1,
    });
    this.pumpkinMaterial = new THREE.MeshStandardMaterial({
      color: 0xea580c, // Bright carved pumpkin orange
      roughness: 0.65,
      metalness: 0.05,
    });
    this.pumpkinGlowMaterial = new THREE.MeshBasicMaterial({
      color: 0xfacc15, // Glowing yellow-amber
    });
    this.spookyBarkMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b, // Gnarled charcoal dead bark
      roughness: 0.95,
      metalness: 0.05,
    });
    this.cauldronMaterial = new THREE.MeshStandardMaterial({
      color: 0x18181b, // Witches cast iron pot
      roughness: 0.45,
      metalness: 0.75,
    });
    this.potionMaterial = new THREE.MeshBasicMaterial({
      color: 0x22c55e, // Glowing neon potion green
    });

    // 5. School Materials
    this.schoolHallwayFloorMaterial = new THREE.MeshStandardMaterial({
      map: createSchoolHallwayFloorTexture(),
      roughness: 0.22,
      metalness: 0.12,
    });
    this.lockerBlueMaterial = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8, // Royal blue metal lockers
      roughness: 0.35,
      metalness: 0.5,
    });
    this.lockerOrangeMaterial = new THREE.MeshStandardMaterial({
      color: 0xf97316, // Orange metal lockers
      roughness: 0.35,
      metalness: 0.5,
    });
    this.deskWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0xd97706, // School desk oak
      roughness: 0.55,
      metalness: 0.08,
    });
    this.chalkboardMaterial = new THREE.MeshStandardMaterial({
      color: 0x064e3b, // Deep green slate chalkboard
      roughness: 0.75,
      metalness: 0.08,
    });
    this.coneHazardMaterial = new THREE.MeshStandardMaterial({
      color: 0xf97316, // Fluorescent hazard orange
      roughness: 0.3,
      metalness: 0.05,
    });
    this.vendingRedMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626, // Bright red vending machine
      roughness: 0.25,
      metalness: 0.65,
    });
    this.mopYellowMaterial = new THREE.MeshStandardMaterial({
      color: 0xeab308, // Janitor bucket bright yellow
      roughness: 0.4,
      metalness: 0.15,
    });
    this.metalHurdleMaterial = new THREE.MeshStandardMaterial({
      color: 0x94a3b8, // Silver chrome gym hurdle
      roughness: 0.2,
      metalness: 0.85,
    });

    // Cyber City Materials
    this.cyberHighwayFloorMaterial = new THREE.MeshStandardMaterial({
      map: createCyberHighwayFloorTexture(),
      roughness: 0.2,
      metalness: 0.7,
    });
    this.cyberClubFloorMaterial = new THREE.MeshStandardMaterial({
      map: createCyberClubFloorTexture(),
      roughness: 0.15,
      metalness: 0.85,
    });
    this.neonCyanMaterial = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    this.neonPinkMaterial = new THREE.MeshBasicMaterial({ color: 0xec4899 });
    this.neonYellowMaterial = new THREE.MeshBasicMaterial({ color: 0xfacc15 });
    this.cyberMetalMaterial = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.35,
      metalness: 0.8,
    });

    // Spring Blossom Coast Materials
    this.springRoadFloorMaterial = new THREE.MeshStandardMaterial({
      map: createSpringRoadFloorTexture(),
      roughness: 0.7,
      metalness: 0.05,
    });
    this.springSakuraFloorMaterial = new THREE.MeshStandardMaterial({
      map: createSpringSakuraBloomFloorTexture(),
      roughness: 0.65,
      metalness: 0.05,
    });
    this.sakuraBarkMaterial = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.9,
      metalness: 0.05,
    });
    this.sakuraFoliageMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbcfe8,
      roughness: 0.7,
      metalness: 0.02,
    });
    this.tentPastelPinkMaterial = new THREE.MeshStandardMaterial({
      color: 0xf472b6,
      roughness: 0.5,
      metalness: 0.1,
    });
    this.tentPastelYellowMaterial = new THREE.MeshStandardMaterial({
      color: 0xfde047,
      roughness: 0.5,
      metalness: 0.1,
    });
    this.tentPastelBlueMaterial = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      roughness: 0.5,
      metalness: 0.1,
    });
    this.springBenchWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0xb45309,
      roughness: 0.8,
      metalness: 0.05,
    });

    // Candy Kingdom Materials
    this.candyFloorMaterial = new THREE.MeshStandardMaterial({
      map: createCandyFloorTexture(),
      roughness: 0.35,
      metalness: 0.15,
    });
    this.candyPalaceFloorMaterial = new THREE.MeshStandardMaterial({
      map: createCandyPalaceFloorTexture(),
      roughness: 0.25,
      metalness: 0.3,
    });
    this.candyCaneMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.3,
      metalness: 0.2,
    });
    this.lollipopSwirlMaterial = new THREE.MeshStandardMaterial({
      color: 0xec4899,
      roughness: 0.2,
      metalness: 0.3,
    });
    this.gummyRubyMaterial = new THREE.MeshStandardMaterial({
      color: 0xf43f5e,
      roughness: 0.15,
      metalness: 0.1,
      transparent: true,
      opacity: 0.88,
    });
    this.gummyEmeraldMaterial = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.15,
      metalness: 0.1,
      transparent: true,
      opacity: 0.88,
    });
    this.peppermintSwirlMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.3,
      metalness: 0.1,
    });
    this.cottonCandyMaterial = new THREE.MeshStandardMaterial({
      color: 0xf472b6,
      roughness: 0.95,
      metalness: 0.0,
    });

    // The Universe Materials
    this.universeRoadMaterial = new THREE.MeshStandardMaterial({
      map: createUniverseCosmicRoadTexture(),
      roughness: 0.18,
      metalness: 0.85,
    });
    this.universePlanetMaterial = new THREE.MeshStandardMaterial({
      map: createUniversePlanetSurfaceTexture(),
      roughness: 0.65,
      metalness: 0.45,
    });
    this.asteroidMaterial = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.95,
      metalness: 0.25,
      flatShading: true,
    });
    this.cosmicCrystalMaterial = new THREE.MeshStandardMaterial({
      color: 0xc084fc,
      emissive: 0xa855f7,
      emissiveIntensity: 0.85,
      roughness: 0.1,
      metalness: 0.7,
    });
    this.energyRingMaterial = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    this.quantumBeaconMaterial = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x0284c7,
      emissiveIntensity: 0.8,
      metalness: 0.9,
      roughness: 0.15,
    });

    // The Deep Forest Materials
    this.forestMossMaterial = new THREE.MeshStandardMaterial({
      map: createForestMossyFloorTexture(),
      roughness: 0.75,
      metalness: 0.1,
    });
    this.forestGladeMaterial = new THREE.MeshStandardMaterial({
      map: createForestWoodGladeTexture(),
      roughness: 0.6,
      metalness: 0.15,
    });
    this.redwoodBarkMaterial = new THREE.MeshStandardMaterial({
      color: 0x3b1a0d,
      roughness: 0.9,
      metalness: 0.05,
    });
    this.mossyRockMaterial = new THREE.MeshStandardMaterial({
      color: 0x223828,
      roughness: 0.85,
      metalness: 0.15,
      flatShading: true,
    });
    this.mushroomCapMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.35,
      metalness: 0.1,
    });
    this.totemWoodMaterial = new THREE.MeshStandardMaterial({
      color: 0x5c3d2e,
      roughness: 0.7,
      metalness: 0.1,
    });

    // Dinner Time Banquet Materials
    this.dinnerTableclothMaterial = new THREE.MeshStandardMaterial({
      map: createDinnerTableclothTexture(),
      roughness: 0.85,
      metalness: 0.05,
    });
    this.dinnerGoldClothMaterial = new THREE.MeshStandardMaterial({
      map: createDinnerGoldClothTexture(),
      roughness: 0.8,
      metalness: 0.1,
    });
    this.dinnerPlateMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xfafafa,
      roughness: 0.12,
      metalness: 0.02,
      clearcoat: 0.9,
      clearcoatRoughness: 0.15,
    });
    this.dinnerSteelMaterial = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      metalness: 0.92,
      roughness: 0.18,
    });
    this.dinnerBunMaterial = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      roughness: 0.65,
    });
    this.dinnerPattyMaterial = new THREE.MeshStandardMaterial({
      color: 0x3f1f14,
      roughness: 0.85,
    });
    this.dinnerCheeseMaterial = new THREE.MeshStandardMaterial({
      color: 0xfacc15,
      roughness: 0.35,
    });
    this.dinnerLettuceMaterial = new THREE.MeshStandardMaterial({
      color: 0x22c55e,
      roughness: 0.5,
    });
    this.dinnerPizzaMaterial = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.55,
    });
    this.dinnerPepperoniMaterial = new THREE.MeshStandardMaterial({
      color: 0x991b1b,
      roughness: 0.45,
    });
    this.dinnerTurkeyMaterial = new THREE.MeshStandardMaterial({
      color: 0x9a3412,
      roughness: 0.4,
      metalness: 0.15,
    });
    this.dinnerKetchupMaterial = new THREE.MeshStandardMaterial({
      color: 0xdc2626,
      roughness: 0.22,
    });
    this.dinnerMustardMaterial = new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.22,
    });
    this.dinnerDonutMaterial = new THREE.MeshStandardMaterial({
      color: 0xf472b6,
      roughness: 0.3,
    });

    // 6. Collectibles & FX
    this.coinMaterial = new THREE.MeshStandardMaterial({
      color: 0xfbbf24, // Gold
      metalness: 0.85,
      roughness: 0.25,
    });

    this.gemMaterial = new THREE.MeshStandardMaterial({
      color: 0x06b6d4, // Cyan diamond
      opacity: 0.9,
      transparent: true,
      roughness: 0.08,
      metalness: 0.4,
    });

    this.powerUpMaterials = {
      nitro: new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.7, roughness: 0.3 }),
      shield: new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.5, roughness: 0.2 }),
      multiplier: new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.8, roughness: 0.2 }),
      magnet: new THREE.MeshStandardMaterial({ color: 0xec4899, metalness: 0.7, roughness: 0.3 }),
      freeze: new THREE.MeshStandardMaterial({ color: 0x67e8f9, metalness: 0.6, roughness: 0.2 }),
      star: new THREE.MeshStandardMaterial({
        color: 0xfde047,
        emissive: 0xf59e0b,
        emissiveIntensity: 0.85,
        metalness: 0.9,
        roughness: 0.1,
      }),
    };

    this.warningMaterial = new THREE.MeshBasicMaterial({
      color: 0xff0000,
      transparent: true,
      opacity: 0.5,
      wireframe: true,
    });

    // Initialize 4 starting chunks (-60m to ~420m)
    for (let i = -1; i < this.activeChunkCount - 1; i++) {
      this.spawnChunk(i * this.chunkLength);
    }
  }

  public setMapTheme(theme: MapTheme) {
    if (this.mapTheme === theme) return;
    this.mapTheme = theme;
    this.currentSubZone = 0;
    this.reset();
  }

  public setSubZone(subZone: number) {
    if (this.currentSubZone === subZone) return;
    this.currentSubZone = subZone;
  }

  /**
   * Terrain height calculation with natural slope, ocean wave swells, and indoor timber leveling
   */
  public getTerrainHeight(x: number, z: number): number {
    const baseSlope = -z * 0.14;

    if (this.mapTheme === 'beach') {
      if (this.currentSubZone === 1) {
        // Beach Sand Dunes: gentle rolling dunes with sandy banks
        const dunes = Math.sin(z * 0.05) * 0.65 + Math.sin(x * 0.08) * 0.45;
        const playHalfWidth = 20;
        let bank = 0;
        const absX = Math.abs(x);
        if (absX > playHalfWidth) {
          bank = Math.pow(absX - playHalfWidth, 1.6) * 0.4;
        }
        return baseSlope + dunes + bank;
      } else {
        // Ocean Surf Rapids: rolling water waves & swells
        const swells = Math.sin(z * 0.065) * 0.85 + Math.cos(x * 0.11) * 0.55 + Math.sin(z * 0.14 + x * 0.07) * 0.22;
        const playHalfWidth = 22;
        let atollBank = 0;
        const absX = Math.abs(x);
        if (absX > playHalfWidth) {
          atollBank = Math.pow(absX - playHalfWidth, 1.7) * 0.42;
        }
        return baseSlope + swells + atollBank;
      }
    }

    // Halloween theme
    if (this.mapTheme === 'halloween') {
      if (this.currentSubZone === 1) {
        // Inside Haunted Mansion: level ancient stone flagging
        return baseSlope;
      } else {
        // Spooky Cemetery: eerie rolling grave mounds
        const mounds = Math.sin(z * 0.07) * 0.45 + Math.cos(x * 0.09) * 0.35;
        const playHalfWidth = 20;
        let cliff = 0;
        const absX = Math.abs(x);
        if (absX > playHalfWidth) {
          cliff = Math.pow(absX - playHalfWidth, 1.6) * 0.4;
        }
        return baseSlope + mounds + cliff;
      }
    }

    // School theme
    if (this.mapTheme === 'school') {
      return baseSlope; // Polished indoor linoleum floor
    }

    // Cyber City theme
    if (this.mapTheme === 'cyber') {
      return baseSlope; // Flat neon cyber speedway
    }

    // Spring Blossom Coast theme
    if (this.mapTheme === 'spring') {
      if (this.currentSubZone === 1) {
        // Sakura Bloom Tunnel & Flower Festival: smooth paved flower plaza
        return baseSlope;
      } else {
        // Rolling green hills along coast
        const gentleHills = Math.sin(z * 0.05) * 0.55 + Math.cos(x * 0.08) * 0.4;
        const playHalfWidth = 20;
        let hillBank = 0;
        const absX = Math.abs(x);
        if (absX > playHalfWidth) {
          hillBank = Math.pow(absX - playHalfWidth, 1.6) * 0.38;
        }
        return baseSlope + gentleHills + hillBank;
      }
    }

    // Sugar Candy Kingdom theme
    if (this.mapTheme === 'candy') {
      if (this.currentSubZone === 1) {
        // Gummy Bear Palace: flat candy marble flooring
        return baseSlope;
      } else {
        // Wavy bubblegum highway
        const candyWaves = Math.sin(z * 0.06) * 0.6 + Math.sin(x * 0.1) * 0.35;
        const playHalfWidth = 20;
        let frostingBank = 0;
        const absX = Math.abs(x);
        if (absX > playHalfWidth) {
          frostingBank = Math.pow(absX - playHalfWidth, 1.5) * 0.35;
        }
        return baseSlope + candyWaves + frostingBank;
      }
    }

    // The Universe theme (Anti-gravity cosmic speedway & lunar surface)
    if (this.mapTheme === 'universe') {
      const warpWaves = Math.sin(z * 0.032) * 0.75 + Math.cos(x * 0.07) * 0.35;
      const playHalfWidth = 21;
      let voidBank = 0;
      const absX = Math.abs(x);
      if (absX > playHalfWidth) {
        voidBank = Math.pow(absX - playHalfWidth, 1.6) * 0.42;
      }
      return baseSlope + warpWaves + voidBank;
    }

    // The Deep Forest theme (Rolling mossy woodland knolls & redwood trails)
    if (this.mapTheme === 'forest') {
      const woodlandWaves = Math.sin(z * 0.045) * 0.7 + Math.cos(x * 0.09) * 0.45;
      const playHalfWidth = 20;
      let forestBank = 0;
      const absX = Math.abs(x);
      if (absX > playHalfWidth) {
        forestBank = Math.pow(absX - playHalfWidth, 1.6) * 0.45;
      }
      return baseSlope + woodlandWaves + forestBank;
    }

    // Dinner Time theme (Giant banquet dining table with tablecloth folds)
    if (this.mapTheme === 'dinner_time') {
      const tableWaves = Math.sin(z * 0.035) * 0.2 + Math.cos(x * 0.07) * 0.15;
      const playHalfWidth = 20;
      let clothBank = 0;
      const absX = Math.abs(x);
      if (absX > playHalfWidth) {
        clothBank = Math.pow(absX - playHalfWidth, 1.5) * 0.35;
      }
      return baseSlope + tableWaves + clothBank;
    }

    // Snow theme
    if (this.currentSubZone === 1) {
      // Inside Wooden Chalet House: smooth, level oak parquet timber floor
      const subtleCreak = Math.sin(z * 0.03) * 0.12;
      return baseSlope + subtleCreak;
    }

    // Outdoor Snow terrain: rolling moguls & cliff barriers
    const moguls = Math.sin(z * 0.04) * 1.2 + Math.sin(x * 0.08) * 0.8;
    const playHalfWidth = 20;
    let cliffHeight = 0;
    const absX = Math.abs(x);
    if (absX > playHalfWidth) {
      const over = absX - playHalfWidth;
      cliffHeight = Math.pow(over, 1.8) * 0.45;
    }
    return baseSlope + moguls + cliffHeight;
  }

  /**
   * Builds and attaches a track slope chunk
   */
  private spawnChunk(zStart: number) {
    const zEnd = zStart + this.chunkLength;
    const isAlternate = this.currentSubZone === 1;
    const isBeach = this.mapTheme === 'beach';

    const xSegments = 26;
    const zSegments = 26;

    const geo = new THREE.PlaneGeometry(
      this.chunkWidth,
      this.chunkLength,
      xSegments,
      zSegments
    );
    geo.rotateX(-Math.PI / 2); // align horizontally

    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const vx = pos.getX(i);
      const vz = pos.getZ(i) + zStart + this.chunkLength * 0.5;
      const vy = this.getTerrainHeight(vx, vz);
      pos.setY(i, vy);
      pos.setZ(i, vz);
    }
    geo.computeVertexNormals();

    // Select primary material for this chunk
    let mainMaterial: THREE.Material;
    if (isBeach) {
      mainMaterial = isAlternate ? this.sandMaterial : this.oceanMaterial;
    } else if (this.mapTheme === 'halloween') {
      mainMaterial = isAlternate ? this.stoneBrickMaterial : this.cemeteryGroundMaterial;
    } else if (this.mapTheme === 'school') {
      mainMaterial = this.schoolHallwayFloorMaterial;
    } else if (this.mapTheme === 'cyber') {
      mainMaterial = isAlternate ? this.cyberClubFloorMaterial : this.cyberHighwayFloorMaterial;
    } else if (this.mapTheme === 'spring') {
      mainMaterial = isAlternate ? this.springSakuraFloorMaterial : this.springRoadFloorMaterial;
    } else if (this.mapTheme === 'candy') {
      mainMaterial = isAlternate ? this.candyPalaceFloorMaterial : this.candyFloorMaterial;
    } else if (this.mapTheme === 'universe') {
      mainMaterial = isAlternate ? this.universePlanetMaterial : this.universeRoadMaterial;
    } else if (this.mapTheme === 'forest') {
      mainMaterial = isAlternate ? this.forestGladeMaterial : this.forestMossMaterial;
    } else if (this.mapTheme === 'dinner_time') {
      mainMaterial = isAlternate ? this.dinnerGoldClothMaterial : this.dinnerTableclothMaterial;
    } else {
      mainMaterial = isAlternate ? this.chaletFloorMaterial : this.snowMaterial;
    }

    const mesh = new THREE.Mesh(geo, mainMaterial);
    mesh.receiveShadow = true;
    mesh.castShadow = false;
    this.root.add(mesh);

    let oceanLeft: THREE.Mesh | undefined;
    let oceanRight: THREE.Mesh | undefined;
    let chaletProps: THREE.Group | undefined;

    if (this.mapTheme === 'forest') {
      const flankWidth = 70;
      const midZ = zStart + this.chunkLength * 0.5;
      const baseForestY = -midZ * 0.14 - 0.2;
      const flankMat = this.forestMossMaterial;

      const forGeoL = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 4, 4);
      forGeoL.rotateX(-Math.PI / 2);
      oceanLeft = new THREE.Mesh(forGeoL, flankMat);
      oceanLeft.position.set(-(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2), baseForestY, midZ);
      this.root.add(oceanLeft);

      const forGeoR = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 4, 4);
      forGeoR.rotateX(-Math.PI / 2);
      oceanRight = new THREE.Mesh(forGeoR, flankMat);
      oceanRight.position.set(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2, baseForestY, midZ);
      this.root.add(oceanRight);
    } else if (this.mapTheme === 'universe') {
      const flankWidth = 85;
      const midZ = zStart + this.chunkLength * 0.5;
      const baseVoidY = -midZ * 0.14 - 1.2;
      const flankMat = this.universePlanetMaterial;

      const voidGeoL = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 4, 4);
      voidGeoL.rotateX(-Math.PI / 2);
      oceanLeft = new THREE.Mesh(voidGeoL, flankMat);
      oceanLeft.position.set(-(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2), baseVoidY, midZ);
      this.root.add(oceanLeft);

      const voidGeoR = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 4, 4);
      voidGeoR.rotateX(-Math.PI / 2);
      oceanRight = new THREE.Mesh(voidGeoR, flankMat);
      oceanRight.position.set(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2, baseVoidY, midZ);
      this.root.add(oceanRight);
    } else if (isBeach) {
      const flankWidth = 75;
      const midZ = zStart + this.chunkLength * 0.5;
      const baseSeaY = -midZ * 0.14 - (isAlternate ? 0.8 : 0.3);
      const flankMat = isAlternate ? this.oceanMaterial : this.sandMaterial;

      const seaGeoL = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 6, 6);
      seaGeoL.rotateX(-Math.PI / 2);
      oceanLeft = new THREE.Mesh(seaGeoL, flankMat);
      oceanLeft.position.set(-(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2), baseSeaY, midZ);
      oceanLeft.receiveShadow = true;
      this.root.add(oceanLeft);

      const seaGeoR = new THREE.PlaneGeometry(flankWidth, this.chunkLength, 6, 6);
      seaGeoR.rotateX(-Math.PI / 2);
      oceanRight = new THREE.Mesh(seaGeoR, flankMat);
      oceanRight.position.set(this.chunkWidth * 0.5 + flankWidth * 0.5 - 2, baseSeaY, midZ);
      oceanRight.receiveShadow = true;
      this.root.add(oceanRight);
    } else if (isAlternate) {
      // Inside Wooden Chalet: Build solid timber log cabin walls & ceiling cross-rafters!
      chaletProps = this.buildChaletArchitecture(zStart, zEnd);
      this.root.add(chaletProps);
    }

    this.terrainChunks.push({ 
      mesh, 
      oceanLeft, 
      oceanRight, 
      chaletProps, 
      zStart, 
      zEnd, 
      subZone: this.currentSubZone 
    });

    if (zStart >= 0) {
      this.populateChunkFeatures(zStart, zEnd, this.currentSubZone);
    }
  }

  /**
   * Spawns obstacles, furniture, gates, kickers, and powerups in a slope chunk
   */
  private populateChunkFeatures(zStart: number, zEnd: number, subZone: number) {
    const isBeach = this.mapTheme === 'beach';
    const isChalet = this.mapTheme === 'snow' && subZone === 1;
    const isBeachDunes = isBeach && subZone === 1;

    // Handle World 3: Halloween Mansion
    if (this.mapTheme === 'halloween') {
      if (subZone === 1) {
        this.populateMansionFeatures(zStart, zEnd);
      } else {
        this.populateCemeteryFeatures(zStart, zEnd);
      }
      return;
    }

    // Handle World 4: School World
    if (this.mapTheme === 'school') {
      if (subZone === 1) {
        this.populateClassroomFeatures(zStart, zEnd);
      } else {
        this.populateHallwayFeatures(zStart, zEnd);
      }
      return;
    }

    // Handle World 5: Neon Cyber City
    if (this.mapTheme === 'cyber') {
      if (subZone === 1) {
        this.populateCyberArcadeFeatures(zStart, zEnd);
      } else {
        this.populateCyberHighwayFeatures(zStart, zEnd);
      }
      return;
    }

    // Handle World 6: Spring Blossom Coast
    if (this.mapTheme === 'spring') {
      if (subZone === 1) {
        this.populateSpringSakuraFeatures(zStart, zEnd);
      } else {
        this.populateSpringCoastFeatures(zStart, zEnd);
      }
      return;
    }

    // Handle World 7: Sugar Candy Kingdom
    if (this.mapTheme === 'candy') {
      if (subZone === 1) {
        this.populateCandyPalaceFeatures(zStart, zEnd);
      } else {
        this.populateCandyForestFeatures(zStart, zEnd);
      }
      return;
    }

    // Handle World 8: The Universe (Solar System & Planetary Space Speedway)
    if (this.mapTheme === 'universe') {
      this.populateUniverseFeatures(zStart, zEnd, subZone);
      return;
    }

    // Handle World 9: The Deep Forest (Redwoods & The Sacred Deer Chase)
    if (this.mapTheme === 'forest') {
      this.populateForestFeatures(zStart, zEnd, subZone);
      return;
    }

    // Handle World 10: Dinner Time (Banquet Feast & Food Obstacles)
    if (this.mapTheme === 'dinner_time') {
      this.populateDinnerTimeFeatures(zStart, zEnd, subZone);
      return;
    }

    // A. CHALET LODGE INTERIOR: FURNITURE OBSTACLES!
    if (isChalet) {
      // 1. Long Oak Dining Tables with Bench Seats
      for (let i = 0; i < 4; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 15 + i * 26;
        const y = this.getTerrainHeight(x, z);

        const table = this.buildChaletTable();
        table.position.set(x, y, z);
        this.root.add(table);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'furniture_table',
          mesh: table,
          collider: { type: 'box', radius: 1.5, halfWidth: 1.8, halfLength: 1.1, height: 1.2 },
          position: table.position,
          isActive: true,
        });
      }

      // 2. Cozy Leather Sofas & Armchairs
      for (let i = 0; i < 5; i++) {
        const x = (Math.random() - 0.5) * 24;
        const z = zStart + 10 + i * 22;
        const y = this.getTerrainHeight(x, z);

        const sofa = this.buildChaletSofa();
        sofa.position.set(x, y, z);
        this.root.add(sofa);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'furniture_sofa',
          mesh: sofa,
          collider: { type: 'box', radius: 1.3, halfWidth: 1.4, halfLength: 0.9, height: 1.0 },
          position: sofa.position,
          isActive: true,
        });
      }

      // 3. Grand Stone Fireplace Hearths with Glowing Flame
      for (let i = 0; i < 2; i++) {
        const side = i === 0 ? -1 : 1;
        const x = side * (10 + Math.random() * 4);
        const z = zStart + 35 + i * 50;
        const y = this.getTerrainHeight(x, z);

        const fireplace = this.buildChaletFireplace();
        fireplace.position.set(x, y, z);
        this.root.add(fireplace);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'furniture_fireplace',
          mesh: fireplace,
          collider: { type: 'box', radius: 1.4, halfWidth: 1.5, halfLength: 0.8, height: 2.8 },
          position: fireplace.position,
          isActive: true,
        });
      }

      // 4. Wooden Dining Chairs & Rockers (Breakable for bonus points!)
      for (let i = 0; i < 6; i++) {
        const x = (Math.random() - 0.5) * 24;
        const z = zStart + 8 + i * 18;
        const y = this.getTerrainHeight(x, z);

        const chair = this.buildChaletChair();
        chair.position.set(x, y, z);
        this.root.add(chair);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'furniture_chair',
          mesh: chair,
          collider: { type: 'cylinder', radius: 0.65, height: 1.2 },
          position: chair.position,
          isActive: true,
        });
      }

      // 5. Stacked Oak Wine & Cider Barrels
      for (let i = 0; i < 3; i++) {
        const x = (Math.random() - 0.5) * 20;
        const z = zStart + 25 + i * 35;
        const y = this.getTerrainHeight(x, z);

        const barrel = this.buildChaletBarrel();
        barrel.position.set(x, y, z);
        this.root.add(barrel);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'furniture_barrel',
          mesh: barrel,
          collider: { type: 'cylinder', radius: 0.85, height: 1.4 },
          position: barrel.position,
          isActive: true,
        });
      }

      // 6. Grandfather Clocks & Ski Racks
      for (let i = 0; i < 3; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 18 + i * 36;
        const y = this.getTerrainHeight(x, z);

        const isClock = i % 2 === 0;
        const item = isClock ? this.buildChaletClock() : this.buildChaletSkiRack();
        item.position.set(x, y, z);
        this.root.add(item);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: isClock ? 'furniture_clock' : 'furniture_skirack',
          mesh: item,
          collider: { type: 'box', radius: 0.8, halfWidth: 0.8, halfLength: 0.6, height: 2.2 },
          position: item.position,
          isActive: true,
        });
      }

      // 7. Indoor Wooden Ramps
      if (Math.random() > 0.3) {
        const rx = (Math.random() - 0.5) * 16;
        const rz = zStart + 45;
        const ry = this.getTerrainHeight(rx, rz);
        this.spawnIndoorJumpRamp(rx, ry, rz);
      }

    } else if (isBeachDunes) {
      // B. TROPICAL BEACH RESORT & SAND DUNES!
      // 1. Striped Beach Umbrellas with Sun Loungers
      for (let i = 0; i < 5; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 12 + i * 22;
        const y = this.getTerrainHeight(x, z);

        const umbrella = this.buildBeachUmbrella();
        umbrella.position.set(x, y, z);
        this.root.add(umbrella);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'beach_umbrella',
          mesh: umbrella,
          collider: { type: 'cylinder', radius: 1.3, height: 2.4 },
          position: umbrella.position,
          isActive: true,
        });
      }

      // 2. Multi-turret Sandcastles
      for (let i = 0; i < 3; i++) {
        const x = (Math.random() - 0.5) * 20;
        const z = zStart + 20 + i * 32;
        const y = this.getTerrainHeight(x, z);

        const sc = this.buildSandcastle();
        sc.position.set(x, y, z);
        this.root.add(sc);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'sandcastle',
          mesh: sc,
          collider: { type: 'sphere', radius: 0.95, height: 1.8 },
          position: sc.position,
          isActive: true,
        });
      }

      // 3. Tiki Totems with Flaming Torches
      for (let i = 0; i < 3; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 15 + i * 35;
        const y = this.getTerrainHeight(x, z);

        const tiki = this.buildTikiTotem();
        tiki.position.set(x, y, z);
        this.root.add(tiki);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'tiki',
          mesh: tiki,
          collider: { type: 'cylinder', radius: 0.8, height: 2.4 },
          position: tiki.position,
          isActive: true,
        });
      }

      // 4. Surfboards Planted in Sand
      for (let i = 0; i < 4; i++) {
        const x = (Math.random() - 0.5) * 24;
        const z = zStart + 8 + i * 28;
        const y = this.getTerrainHeight(x, z);

        const boards = this.buildSurfboardStand();
        boards.position.set(x, y, z);
        this.root.add(boards);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'surfboard_stand',
          mesh: boards,
          collider: { type: 'box', radius: 0.9, halfWidth: 0.9, halfLength: 0.5, height: 2.0 },
          position: boards.position,
          isActive: true,
        });
      }

      // 5. Red & Blue Drink Coolers (Smashable for bonus coins!)
      for (let i = 0; i < 4; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 14 + i * 26;
        const y = this.getTerrainHeight(x, z);

        const cooler = this.buildBeachCooler();
        cooler.position.set(x, y, z);
        this.root.add(cooler);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'beach_cooler',
          mesh: cooler,
          collider: { type: 'box', radius: 0.7, halfWidth: 0.7, halfLength: 0.5, height: 0.8 },
          position: cooler.position,
          isActive: true,
        });
      }

      // 6. Beach Volleyball Nets
      for (let i = 0; i < 2; i++) {
        const x = (Math.random() - 0.5) * 12;
        const z = zStart + 35 + i * 50;
        const y = this.getTerrainHeight(x, z);

        const net = this.buildVolleyballNet();
        net.position.set(x, y, z);
        this.root.add(net);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'volleyball_net',
          mesh: net,
          collider: { type: 'box', radius: 2.6, halfWidth: 3.2, halfLength: 0.4, height: 2.2 },
          position: net.position,
          isActive: true,
        });
      }

      // 7. Lush Tropical Palm Trees lining the dunes (100% PALM TREES!)
      for (let i = 0; i < 12; i++) {
        const side = Math.random() > 0.5 ? 1 : -1;
        const x = side * (12 + Math.random() * 12);
        const z = zStart + 10 + i * 9;
        const y = this.getTerrainHeight(x, z);

        const palm = this.buildPalmTree();
        palm.position.set(x, y, z);
        this.root.add(palm);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'tree',
          mesh: palm,
          collider: { type: 'cylinder', radius: 0.75, height: 4.5 },
          position: palm.position,
          isActive: true,
        });
      }

      // 8. Sand Dune Jump Ramps
      if (Math.random() > 0.3) {
        const rx = (Math.random() - 0.5) * 16;
        const rz = zStart + 45;
        const ry = this.getTerrainHeight(rx, rz);
        this.spawnBeachJumpRamp(rx, ry, rz);
      }

    } else if (isBeach && subZone === 0) {
      // C. OCEAN SURF RAPIDS (Everything on water, 100% Palm Trees on banks!)
      // 1. Protruding Coral Reef Spires
      for (let i = 0; i < 7; i++) {
        const x = (Math.random() - 0.5) * 26;
        const z = zStart + 15 + Math.random() * (this.chunkLength - 30);
        const y = this.getTerrainHeight(x, z);

        const rock = this.buildBeachRock();
        rock.position.set(x, y, z);
        this.root.add(rock);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'rock',
          mesh: rock,
          collider: { type: 'sphere', radius: 1.1, height: 1.8 },
          position: rock.position,
          isActive: true,
        });
      }

      // 2. Floating Marine Navigation Buoys
      for (let i = 0; i < 2; i++) {
        const x = (Math.random() - 0.5) * 16;
        const z = zStart + 25 + i * 50;
        const y = this.getTerrainHeight(x, z);

        const gate = this.buildBeachSlalomGate(i % 2 === 0);
        gate.position.set(x, y, z);
        this.root.add(gate);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'slalom_gate',
          mesh: gate,
          collider: { type: 'box', radius: 2.5, halfWidth: 2.8, halfLength: 0.4, height: 2.5 },
          position: gate.position,
          isActive: true,
          dynamic: { isPassed: false },
        });
      }

      // 3. Floating Cargo Barrels bobbing in waves
      for (let i = 0; i < 2; i++) {
        const side = Math.random() > 0.5 ? 1 : -1;
        const sx = side * 16;
        const sz = zStart + 40 + i * 40;
        const sy = this.getTerrainHeight(sx, sz) + 1.0;

        const barrel = this.buildRollingBarrel();
        barrel.position.set(sx, sy, sz);
        this.root.add(barrel);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'rolling_snowball',
          mesh: barrel,
          collider: { type: 'sphere', radius: 1.3, height: 2.6 },
          position: barrel.position,
          isActive: true,
          dynamic: {
            vx: -side * (6 + Math.random() * 4),
            vz: 8,
            hasTriggered: false,
          },
        });
      }

      // 4. Floating Tiki Rafts
      for (let i = 0; i < 3; i++) {
        const x = (Math.random() - 0.5) * 22;
        const z = zStart + 18 + i * 35;
        const y = this.getTerrainHeight(x, z);

        const tiki = this.buildTikiTotem();
        tiki.position.set(x, y, z);
        this.root.add(tiki);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'tiki',
          mesh: tiki,
          collider: { type: 'cylinder', radius: 0.8, height: 2.4 },
          position: tiki.position,
          isActive: true,
        });
      }

      // 5. Floating Timber Boom Logs
      for (let i = 0; i < 2; i++) {
        const x = (Math.random() - 0.5) * 18;
        const z = zStart + 20 + i * 45;
        const y = this.getTerrainHeight(x, z) + 0.25;

        const log = this.buildDriftwoodRail();
        log.position.set(x, y, z);
        this.root.add(log);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'log_rail',
          mesh: log,
          collider: { type: 'box', radius: 0.5, halfWidth: 0.4, halfLength: 4.0, height: 0.8 },
          position: log.position,
          isActive: true,
        });
      }

      // 6. Lush Tropical Palm Trees on ocean islet banks (100% PALM TREES!)
      for (let i = 0; i < 14; i++) {
        const side = Math.random() > 0.5 ? 1 : -1;
        const x = side * (14 + Math.random() * 14);
        const z = zStart + 10 + i * 8;
        const y = this.getTerrainHeight(x, z);

        const palm = this.buildPalmTree();
        palm.position.set(x, y, z);
        this.root.add(palm);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'tree',
          mesh: palm,
          collider: { type: 'cylinder', radius: 0.75, height: 4.5 },
          position: palm.position,
          isActive: true,
        });
      }

      // 7. Floating Wooden Surf Kickers
      if (Math.random() > 0.3) {
        const rx = (Math.random() - 0.5) * 16;
        const rz = zStart + 45;
        const ry = this.getTerrainHeight(rx, rz);
        this.spawnBeachJumpRamp(rx, ry, rz);
      }

    } else {
      // D. OUTDOOR ALPINE MOUNTAIN PEAK (Snow, Pines, Rocks, Snowmen)
      const obsMult = this.getObstacleMultiplier();
      const treeCount = Math.max(3, Math.round(14 * obsMult));
      const rockCount = Math.max(1, Math.round(6 * obsMult));
      const snowmanCount = Math.max(1, Math.round(3 * obsMult));

      // 1. Natural Snowy Pines
      for (let i = 0; i < treeCount; i++) {
        const x = (Math.random() - 0.5) * 36;
        const z = zStart + 10 + Math.random() * (this.chunkLength - 20);
        const y = this.getTerrainHeight(x, z);

        const tree = this.buildPineTree();
        tree.position.set(x, y, z);
        this.root.add(tree);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'tree',
          mesh: tree,
          collider: { type: 'cylinder', radius: 0.9, height: 4.5 },
          position: tree.position,
          isActive: true,
        });
      }

      // 2. Glacial Boulders
      for (let i = 0; i < rockCount; i++) {
        const x = (Math.random() - 0.5) * 32;
        const z = zStart + 15 + Math.random() * (this.chunkLength - 30);
        const y = this.getTerrainHeight(x, z);

        const rock = this.buildRock();
        rock.position.set(x, y, z);
        this.root.add(rock);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'rock',
          mesh: rock,
          collider: { type: 'sphere', radius: 1.1, height: 1.8 },
          position: rock.position,
          isActive: true,
        });
      }

      // 3. Snowmen
      for (let i = 0; i < snowmanCount; i++) {
        const x = (Math.random() - 0.5) * 24;
        const z = zStart + 10 + Math.random() * (this.chunkLength - 20);
        const y = this.getTerrainHeight(x, z);

        const sm = this.buildSnowman();
        sm.position.set(x, y, z);
        this.root.add(sm);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'snowman',
          mesh: sm,
          collider: { type: 'sphere', radius: 0.95, height: 1.8 },
          position: sm.position,
          isActive: true,
        });
      }

      // 4. Fallen Snow Log Rails
      for (let i = 0; i < 2; i++) {
        const x = (Math.random() - 0.5) * 18;
        const z = zStart + 25 + i * 40;
        const y = this.getTerrainHeight(x, z) + 0.3;

        const log = this.buildLogRail();
        log.position.set(x, y, z);
        this.root.add(log);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'log_rail',
          mesh: log,
          collider: { type: 'box', radius: 0.5, halfWidth: 0.4, halfLength: 4.0, height: 0.8 },
          position: log.position,
          isActive: true,
        });
      }

      // 5. Slalom Checkpoint Gates
      for (let i = 0; i < 2; i++) {
        const x = (Math.random() - 0.5) * 16;
        const z = zStart + 20 + i * 50;
        const y = this.getTerrainHeight(x, z);

        const gate = this.buildSlalomGate(i % 2 === 0);
        gate.position.set(x, y, z);
        this.root.add(gate);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'slalom_gate',
          mesh: gate,
          collider: { type: 'box', radius: 2.5, halfWidth: 2.8, halfLength: 0.4, height: 2.5 },
          position: gate.position,
          isActive: true,
          dynamic: { isPassed: false },
        });
      }

      // 6. Natural Ski Jump Ramp
      if (Math.random() > 0.3) {
        const rx = (Math.random() - 0.5) * 16;
        const rz = zStart + 40;
        const ry = this.getTerrainHeight(rx, rz);
        this.spawnJumpRamp(rx, ry, rz);
      }

      // 7. Dynamic Hazard: Falling Icicles
      if (Math.random() > 0.4) {
        const ix = (Math.random() - 0.5) * 20;
        const iz = zStart + 45;
        const iy = this.getTerrainHeight(ix, iz);

        const hazardGroup = this.buildFallingIcicle();
        hazardGroup.position.set(ix, iy + 16, iz);
        this.root.add(hazardGroup);

        const circleGeo = new THREE.RingGeometry(0.8, 1.4, 16);
        circleGeo.rotateX(-Math.PI / 2);
        const warnCircle = new THREE.Mesh(circleGeo, this.warningMaterial);
        warnCircle.position.set(ix, iy + 0.05, iz);
        this.root.add(warnCircle);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'icicle',
          mesh: hazardGroup,
          collider: { type: 'cylinder', radius: 0.75, height: 2.5 },
          position: hazardGroup.position,
          isActive: true,
          dynamic: {
            vy: 0,
            warningCircle: warnCircle,
            hasTriggered: false,
          },
        });
      }

      // 8. Dynamic Hazard: Rolling Snowballs
      if (Math.random() > 0.4) {
        const side = Math.random() > 0.5 ? 1 : -1;
        const sx = side * 18;
        const sz = zStart + 60;
        const sy = this.getTerrainHeight(sx, sz) + 1.2;

        const ballMesh = this.buildRollingSnowball();
        ballMesh.position.set(sx, sy, sz);
        this.root.add(ballMesh);

        this.obstacles.push({
          id: this.nextObstacleId++,
          type: 'rolling_snowball',
          mesh: ballMesh,
          collider: { type: 'sphere', radius: 1.4, height: 2.8 },
          position: ballMesh.position,
          isActive: true,
          dynamic: {
            vx: -side * (6 + Math.random() * 4),
            vz: 8,
            hasTriggered: false,
          },
        });
      }
    }

    // Collectibles: Coins & Gems (Rich runs for effortless farming!)
    const lineCount = 3;
    for (let l = 0; l < lineCount; l++) {
      const coinRunCount = 12;
      const startX = (Math.random() - 0.5) * 16;
      const zOffset = zStart + 6 + l * 34;
      for (let c = 0; c < coinRunCount; c++) {
        const cz = zOffset + c * 2.5;
        const cx = startX + Math.sin(c * 0.45) * 3.5;
        const cy = this.getTerrainHeight(cx, cz) + 0.85;

        const isGem = Math.random() < 0.35;
        const colMesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
        colMesh.position.set(cx, cy, cz);
        this.root.add(colMesh);

        this.collectibles.push({
          id: this.nextCollectibleId++,
          type: isGem ? 'gem' : 'coin',
          mesh: colMesh,
          position: colMesh.position,
          baseY: cy,
          isCollected: false,
          radius: isGem ? 1.6 : 1.3,
        });
      }
    }
  }

  // --- Procedural Geometry Builders ---

  /**
   * Builds the log cabin walls, overhead timber rafters, and chandeliers for the Chalet interior
   */
  private buildChaletArchitecture(zStart: number, zEnd: number): THREE.Group {
    const group = new THREE.Group();
    const length = zEnd - zStart;
    const midZ = zStart + length * 0.5;
    const midY = -midZ * 0.14;

    // Left and Right Timber Cabin Walls
    const wallGeo = new THREE.BoxGeometry(0.8, 8.0, length);
    wallGeo.rotateX(0.14); // match 14% slope angle

    const wallL = new THREE.Mesh(wallGeo, this.chaletWallMaterial);
    wallL.position.set(-20.5, midY + 3.5, midZ);
    wallL.receiveShadow = true;
    group.add(wallL);

    const wallR = new THREE.Mesh(wallGeo, this.chaletWallMaterial);
    wallR.position.set(20.5, midY + 3.5, midZ);
    wallR.receiveShadow = true;
    group.add(wallR);

    // Warm glowing wall lanterns every 25m
    for (let z = zStart + 15; z < zEnd - 10; z += 25) {
      const y = this.getTerrainHeight(0, z) + 3.2;

      const lanternL = this.buildWallLantern();
      lanternL.position.set(-20.0, y, z);
      lanternL.rotation.y = Math.PI / 2;
      group.add(lanternL);

      const lanternR = this.buildWallLantern();
      lanternR.position.set(20.0, y, z);
      lanternR.rotation.y = -Math.PI / 2;
      group.add(lanternR);
    }

    // Overhead heavy timber cross beams with iron candelabra chandeliers
    for (let z = zStart + 25; z < zEnd - 15; z += 35) {
      const y = this.getTerrainHeight(0, z) + 7.5;
      const rafter = this.buildChaletRafter();
      rafter.position.set(0, y, z);
      group.add(rafter);
    }

    return group;
  }

  private buildWallLantern(): THREE.Group {
    const group = new THREE.Group();
    const bracketGeo = new THREE.BoxGeometry(0.1, 0.4, 0.3);
    const bracket = new THREE.Mesh(bracketGeo, this.chandelierIronMaterial);
    group.add(bracket);

    const cageGeo = new THREE.BoxGeometry(0.3, 0.45, 0.3);
    const cage = new THREE.Mesh(cageGeo, this.lanternGlassMaterial);
    cage.position.set(0, -0.05, 0.2);
    group.add(cage);

    return group;
  }

  private buildChaletRafter(): THREE.Group {
    const group = new THREE.Group();

    // Cedar cross beam spanning across room
    const beamGeo = new THREE.BoxGeometry(41.5, 0.7, 0.7);
    const beam = new THREE.Mesh(beamGeo, this.chaletWallMaterial);
    beam.castShadow = true;
    group.add(beam);

    // Two hanging iron chandeliers
    const chandelierOffsets = [-8, 8];
    chandelierOffsets.forEach((ox) => {
      const ch = new THREE.Group();
      ch.position.set(ox, -1.6, 0);

      // Chain
      const chainGeo = new THREE.CylinderGeometry(0.03, 0.03, 1.4, 4);
      const chain = new THREE.Mesh(chainGeo, this.chandelierIronMaterial);
      chain.position.y = 0.7;
      ch.add(chain);

      // Iron ring
      const ringGeo = new THREE.TorusGeometry(1.2, 0.05, 6, 16);
      ringGeo.rotateX(Math.PI / 2);
      const ring = new THREE.Mesh(ringGeo, this.chandelierIronMaterial);
      ch.add(ring);

      // Candles
      for (let c = 0; c < 6; c++) {
        const ang = (c * Math.PI * 2) / 6;
        const candleGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.3, 6);
        const candle = new THREE.Mesh(candleGeo, this.lanternGlassMaterial);
        candle.position.set(Math.cos(ang) * 1.2, 0.15, Math.sin(ang) * 1.2);
        ch.add(candle);
      }

      group.add(ch);
    });

    return group;
  }

  // --- Chalet Furniture Builders ---

  private buildChaletTable(): THREE.Group {
    const group = new THREE.Group();

    // Heavy oak tabletop
    const topGeo = new THREE.BoxGeometry(3.2, 0.16, 1.8);
    const top = new THREE.Mesh(topGeo, this.furnitureWoodMaterial);
    top.position.y = 0.9;
    top.castShadow = true;
    group.add(top);

    // 4 Sturdy carved legs
    const legGeo = new THREE.BoxGeometry(0.18, 0.9, 0.18);
    const legOffsets = [
      [-1.4, 0.45, -0.7],
      [1.4, 0.45, -0.7],
      [-1.4, 0.45, 0.7],
      [1.4, 0.45, 0.7],
    ];
    legOffsets.forEach(([lx, ly, lz]) => {
      const leg = new THREE.Mesh(legGeo, this.furnitureWoodMaterial);
      leg.position.set(lx, ly, lz);
      leg.castShadow = true;
      group.add(leg);
    });

    // Side bench seats
    const benchGeo = new THREE.BoxGeometry(3.0, 0.1, 0.45);
    const bench1 = new THREE.Mesh(benchGeo, this.furnitureWoodMaterial);
    bench1.position.set(0, 0.5, -1.25);
    group.add(bench1);

    const bench2 = new THREE.Mesh(benchGeo, this.furnitureWoodMaterial);
    bench2.position.set(0, 0.5, 1.25);
    group.add(bench2);

    // Candle lantern centerpiece on table
    const lanternGeo = new THREE.CylinderGeometry(0.12, 0.14, 0.35, 6);
    const lantern = new THREE.Mesh(lanternGeo, this.fireGlowMaterial);
    lantern.position.set(0, 1.15, 0);
    group.add(lantern);

    return group;
  }

  private buildChaletSofa(): THREE.Group {
    const group = new THREE.Group();

    // Plush burgundy seat cushion
    const seatGeo = new THREE.BoxGeometry(2.6, 0.45, 1.3);
    const seat = new THREE.Mesh(seatGeo, this.furnitureCushionMaterial);
    seat.position.y = 0.35;
    seat.castShadow = true;
    group.add(seat);

    // High padded backrest
    const backGeo = new THREE.BoxGeometry(2.6, 0.7, 0.35);
    const back = new THREE.Mesh(backGeo, this.furnitureCushionMaterial);
    back.position.set(0, 0.8, -0.48);
    back.castShadow = true;
    group.add(back);

    // Carved wooden armrests
    const armGeo = new THREE.BoxGeometry(0.24, 0.55, 1.3);
    const armL = new THREE.Mesh(armGeo, this.furnitureWoodMaterial);
    armL.position.set(-1.35, 0.45, 0);
    armL.castShadow = true;
    group.add(armL);

    const armR = new THREE.Mesh(armGeo, this.furnitureWoodMaterial);
    armR.position.set(1.35, 0.45, 0);
    armR.castShadow = true;
    group.add(armR);

    // Plaid throw pillows
    const pillowGeo = new THREE.BoxGeometry(0.45, 0.45, 0.18);
    const p1 = new THREE.Mesh(pillowGeo, this.sandcastleMaterial);
    p1.position.set(-0.85, 0.65, -0.28);
    p1.rotation.z = 0.2;
    group.add(p1);

    const p2 = new THREE.Mesh(pillowGeo, this.sandcastleMaterial);
    p2.position.set(0.85, 0.65, -0.28);
    p2.rotation.z = -0.2;
    group.add(p2);

    return group;
  }

  private buildChaletFireplace(): THREE.Group {
    const group = new THREE.Group();

    // Stone hearth base
    const baseGeo = new THREE.BoxGeometry(2.8, 0.3, 1.4);
    const base = new THREE.Mesh(baseGeo, this.stoneBrickMaterial);
    base.position.y = 0.15;
    base.castShadow = true;
    group.add(base);

    // Masonry chimney pillar
    const chimneyGeo = new THREE.BoxGeometry(2.4, 3.2, 1.1);
    const chimney = new THREE.Mesh(chimneyGeo, this.stoneBrickMaterial);
    chimney.position.set(0, 1.8, 0);
    chimney.castShadow = true;
    group.add(chimney);

    // Wooden mantle shelf
    const mantleGeo = new THREE.BoxGeometry(2.8, 0.18, 0.6);
    const mantle = new THREE.Mesh(mantleGeo, this.furnitureWoodMaterial);
    mantle.position.set(0, 2.3, 0.35);
    group.add(mantle);

    // Recessed firebox with blazing fire
    const fireGeo = new THREE.ConeGeometry(0.4, 0.8, 6);
    const fire = new THREE.Mesh(fireGeo, this.fireGlowMaterial);
    fire.position.set(0, 0.6, 0.25);
    group.add(fire);

    const fireSmall = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.6, 5), this.fireGlowMaterial);
    fireSmall.position.set(0.3, 0.5, 0.2);
    group.add(fireSmall);

    // Firewood logs inside hearth
    const logGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.8, 6);
    logGeo.rotateZ(Math.PI / 2);
    const log1 = new THREE.Mesh(logGeo, this.woodMaterial);
    log1.position.set(0, 0.4, 0.25);
    group.add(log1);

    return group;
  }

  private buildChaletChair(): THREE.Group {
    const group = new THREE.Group();
    // Solid wood seat
    const seatGeo = new THREE.BoxGeometry(0.75, 0.08, 0.75);
    const seat = new THREE.Mesh(seatGeo, this.furnitureWoodMaterial);
    seat.position.y = 0.45;
    seat.castShadow = true;
    group.add(seat);

    // 4 Turned legs
    const legGeo = new THREE.CylinderGeometry(0.04, 0.03, 0.45, 6);
    const offsets = [
      [-0.3, 0.225, -0.3],
      [0.3, 0.225, -0.3],
      [-0.3, 0.225, 0.3],
      [0.3, 0.225, 0.3],
    ];
    offsets.forEach(([lx, ly, lz]) => {
      const leg = new THREE.Mesh(legGeo, this.furnitureWoodMaterial);
      leg.position.set(lx, ly, lz);
      group.add(leg);
    });

    // Spindle backrest
    const backGeo = new THREE.BoxGeometry(0.75, 0.65, 0.08);
    const back = new THREE.Mesh(backGeo, this.furnitureWoodMaterial);
    back.position.set(0, 0.82, -0.34);
    group.add(back);

    return group;
  }

  private buildChaletBarrel(): THREE.Group {
    const group = new THREE.Group();
    const barrelGeo = new THREE.CylinderGeometry(0.7, 0.7, 1.4, 10);
    const barrel = new THREE.Mesh(barrelGeo, this.furnitureWoodMaterial);
    barrel.position.y = 0.7;
    barrel.castShadow = true;
    group.add(barrel);

    // Metal hoop bands
    const hoopGeo = new THREE.TorusGeometry(0.71, 0.03, 4, 12);
    hoopGeo.rotateX(Math.PI / 2);
    const h1 = new THREE.Mesh(hoopGeo, this.chandelierIronMaterial);
    h1.position.y = 0.35;
    barrel.add(h1);

    const h2 = new THREE.Mesh(hoopGeo, this.chandelierIronMaterial);
    h2.position.y = 1.05;
    barrel.add(h2);

    return group;
  }

  private buildChaletClock(): THREE.Group {
    const group = new THREE.Group();
    // Tall wooden case
    const caseGeo = new THREE.BoxGeometry(0.7, 2.3, 0.5);
    const clockCase = new THREE.Mesh(caseGeo, this.furnitureWoodMaterial);
    clockCase.position.y = 1.15;
    clockCase.castShadow = true;
    group.add(clockCase);

    // Brass clock face
    const faceGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.05, 12);
    faceGeo.rotateX(Math.PI / 2);
    const face = new THREE.Mesh(faceGeo, this.coinMaterial);
    face.position.set(0, 1.85, 0.26);
    group.add(face);

    // Glass pendulum door
    const glassGeo = new THREE.BoxGeometry(0.35, 0.75, 0.05);
    const glass = new THREE.Mesh(glassGeo, this.icePatchMaterial);
    glass.position.set(0, 1.1, 0.26);
    group.add(glass);

    return group;
  }

  private buildChaletSkiRack(): THREE.Group {
    const group = new THREE.Group();
    // A-frame timber rack
    const postGeo = new THREE.BoxGeometry(0.12, 1.8, 0.12);
    const pL = new THREE.Mesh(postGeo, this.furnitureWoodMaterial);
    pL.position.set(-1.0, 0.9, 0);
    group.add(pL);

    const pR = new THREE.Mesh(postGeo, this.furnitureWoodMaterial);
    pR.position.set(1.0, 0.9, 0);
    group.add(pR);

    const barGeo = new THREE.BoxGeometry(2.2, 0.08, 0.1);
    const bar = new THREE.Mesh(barGeo, this.furnitureWoodMaterial);
    bar.position.set(0, 1.2, 0);
    group.add(bar);

    // 4 Pairs of upright skis resting in rack
    const skiColors = [0xef4444, 0x0284c7, 0xfacc15, 0x10b981];
    for (let s = 0; s < 4; s++) {
      const skiMat = new THREE.MeshStandardMaterial({ color: skiColors[s] });
      const skiGeo = new THREE.BoxGeometry(0.1, 1.7, 0.02);
      const ski = new THREE.Mesh(skiGeo, skiMat);
      ski.position.set(-0.75 + s * 0.5, 0.85, 0.04);
      ski.rotation.z = (Math.random() - 0.5) * 0.1;
      group.add(ski);
    }

    return group;
  }

  private spawnIndoorJumpRamp(x: number, y: number, z: number) {
    const width = 6.0;
    const length = 7.0;
    const height = 1.6;

    const shape = new THREE.Shape();
    shape.moveTo(-length / 2, 0);
    shape.lineTo(length / 2, height);
    shape.lineTo(length / 2, 0);
    shape.closePath();

    const rampGeo = new THREE.ExtrudeGeometry(shape, { depth: width, bevelEnabled: false });
    rampGeo.rotateY(Math.PI / 2);
    rampGeo.translate(-width / 2, 0, 0);

    const rampMesh = new THREE.Mesh(rampGeo, this.furnitureWoodMaterial);
    rampMesh.position.set(x, y, z);
    rampMesh.castShadow = true;
    rampMesh.receiveShadow = true;
    this.root.add(rampMesh);

    this.ramps.push({ position: rampMesh.position, width, length, height, mesh: rampMesh });

    for (let i = 0; i < 5; i++) {
      const acz = z + length * 0.5 + i * 5.0;
      const acx = x;
      const acy = this.getTerrainHeight(acx, acz) + height + 2.2 + Math.sin((i / 4) * Math.PI) * 2.8;
      const isGem = i === 2;
      const mesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
      mesh.position.set(acx, acy, acz);
      this.root.add(mesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: isGem ? 'gem' : 'coin',
        mesh,
        position: mesh.position,
        baseY: acy,
        isCollected: false,
        radius: isGem ? 1.6 : 1.3,
      });
    }
  }

  // --- Beach Resort Builders ---

  private buildBeachUmbrella(): THREE.Group {
    const group = new THREE.Group();

    // Tilted metal umbrella pole
    const poleGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.6, 6);
    const pole = new THREE.Mesh(poleGeo, this.woodMaterial);
    pole.position.set(0, 1.25, 0);
    pole.rotation.z = 0.12;
    pole.castShadow = true;
    group.add(pole);

    // Large colorful striped umbrella canopy
    const canopyGeo = new THREE.ConeGeometry(2.2, 0.85, 8);
    const canopy = new THREE.Mesh(canopyGeo, this.umbrellaCanopyMaterial);
    canopy.position.set(0.15, 2.4, 0);
    canopy.rotation.z = 0.12;
    canopy.castShadow = true;
    group.add(canopy);

    // Sun lounger / deck chair beneath umbrella
    const loungerGeo = new THREE.BoxGeometry(0.85, 0.25, 1.9);
    const lounger = new THREE.Mesh(loungerGeo, this.sandcastleMaterial);
    lounger.position.set(-0.6, 0.18, 0);
    lounger.castShadow = true;
    group.add(lounger);

    // Lounger pillow
    const pillowGeo = new THREE.BoxGeometry(0.7, 0.15, 0.4);
    const pillow = new THREE.Mesh(pillowGeo, this.coolerMaterial);
    pillow.position.set(-0.6, 0.35, -0.7);
    group.add(pillow);

    return group;
  }

  private buildSurfboardStand(): THREE.Group {
    const group = new THREE.Group();
    // 2 Surfboards stuck upright in the sand at jaunty angles
    const colors = [0x0ea5e9, 0xf43f5e];
    for (let s = 0; s < 2; s++) {
      const bGeo = new THREE.BoxGeometry(0.38, 1.9, 0.05);
      const bMat = new THREE.MeshStandardMaterial({ color: colors[s], roughness: 0.3 });
      const board = new THREE.Mesh(bGeo, bMat);
      board.position.set(-0.35 + s * 0.7, 0.85, 0);
      board.rotation.y = (s === 0 ? 0.3 : -0.3);
      board.rotation.z = (s === 0 ? -0.15 : 0.15);
      board.castShadow = true;
      group.add(board);
    }

    // Beach bucket
    const bucketGeo = new THREE.CylinderGeometry(0.18, 0.12, 0.32, 8);
    const bucket = new THREE.Mesh(bucketGeo, this.sandcastleMaterial);
    bucket.position.set(0, 0.16, 0.5);
    group.add(bucket);

    return group;
  }

  private buildVolleyballNet(): THREE.Group {
    const group = new THREE.Group();
    // Two bamboo poles
    const poleGeo = new THREE.CylinderGeometry(0.06, 0.06, 2.4, 6);
    const pL = new THREE.Mesh(poleGeo, this.woodMaterial);
    pL.position.set(-2.8, 1.2, 0);
    pL.castShadow = true;
    group.add(pL);

    const pR = new THREE.Mesh(poleGeo, this.woodMaterial);
    pR.position.set(2.8, 1.2, 0);
    pR.castShadow = true;
    group.add(pR);

    // White net mesh
    const netGeo = new THREE.PlaneGeometry(5.5, 0.8);
    const netMat = new THREE.MeshBasicMaterial({ 
      color: 0xffffff, 
      wireframe: true, 
      side: THREE.DoubleSide 
    });
    const net = new THREE.Mesh(netGeo, netMat);
    net.position.set(0, 1.6, 0);
    group.add(net);

    // Volleyball on sand
    const ballGeo = new THREE.SphereGeometry(0.24, 8, 8);
    const ballMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.5 });
    const ball = new THREE.Mesh(ballGeo, ballMat);
    ball.position.set(0.6, 0.24, 0.4);
    group.add(ball);

    return group;
  }

  private buildBeachCooler(): THREE.Group {
    const group = new THREE.Group();
    // Insulated cooler chest
    const chestGeo = new THREE.BoxGeometry(0.95, 0.55, 0.65);
    const chest = new THREE.Mesh(chestGeo, this.coolerMaterial);
    chest.position.y = 0.28;
    chest.castShadow = true;
    group.add(chest);

    // White cooler lid
    const lidGeo = new THREE.BoxGeometry(1.0, 0.12, 0.7);
    const lid = new THREE.Mesh(lidGeo, this.pineSnowMaterial);
    lid.position.y = 0.6;
    chest.add(lid);

    return group;
  }

  // --- Natural Alpine & Coastal Builders ---

  private buildPineTree(): THREE.Group {
    const group = new THREE.Group();

    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.2, 0.32, 1.8, 6);
    const trunk = new THREE.Mesh(trunkGeo, this.woodMaterial);
    trunk.position.y = 0.9;
    trunk.castShadow = true;
    group.add(trunk);

    // 3 Tiers of Conical Foliage with Snow Caps
    const tiers = [
      { r: 1.4, h: 1.8, y: 2.2, snowR: 1.45 },
      { r: 1.1, h: 1.6, y: 3.2, snowR: 1.15 },
      { r: 0.75, h: 1.4, y: 4.1, snowR: 0.8 },
    ];

    tiers.forEach((tier) => {
      const coneGeo = new THREE.ConeGeometry(tier.r, tier.h, 7);
      const cone = new THREE.Mesh(coneGeo, this.pineFoliageMaterial);
      cone.position.y = tier.y;
      cone.castShadow = true;
      group.add(cone);

      const snowGeo = new THREE.ConeGeometry(tier.snowR, 0.45, 7);
      const snow = new THREE.Mesh(snowGeo, this.pineSnowMaterial);
      snow.position.y = tier.y - tier.h * 0.28;
      snow.castShadow = true;
      group.add(snow);
    });

    return group;
  }

  /**
   * Prominent, lush tropical palm tree exclusively used in Beach/Ocean mode (NO pine trees!)
   */
  public buildPalmTree(): THREE.Group {
    const group = new THREE.Group();

    // Curved tropical trunk in 3 stacked ringed segments
    const seg1 = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.32, 1.6, 7), this.palmBarkMaterial);
    seg1.position.y = 0.8;
    seg1.rotation.z = 0.05;
    seg1.castShadow = true;
    group.add(seg1);

    const seg2 = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.24, 1.5, 7), this.palmBarkMaterial);
    seg2.position.set(0.08, 2.2, 0);
    seg2.rotation.z = 0.12;
    seg2.castShadow = true;
    group.add(seg2);

    const seg3 = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.2, 1.4, 7), this.palmBarkMaterial);
    seg3.position.set(0.22, 3.5, 0);
    seg3.rotation.z = 0.18;
    seg3.castShadow = true;
    group.add(seg3);

    // Crown of cascading green palm fronds
    const crown = new THREE.Group();
    crown.position.set(0.32, 4.2, 0);

    const frondCount = 8;
    for (let i = 0; i < frondCount; i++) {
      const angle = (i * Math.PI * 2) / frondCount;
      const frondGeo = new THREE.ConeGeometry(0.65, 2.6, 5);
      frondGeo.rotateX(Math.PI / 2.3);
      const frond = new THREE.Mesh(frondGeo, this.palmFrondMaterial);
      frond.rotation.y = angle;
      frond.rotation.z = 0.45;
      frond.castShadow = true;
      crown.add(frond);
    }

    // Clustered brown coconuts
    for (let c = 0; c < 4; c++) {
      const ca = (c * Math.PI * 2) / 4 + 0.3;
      const nut = new THREE.Mesh(new THREE.SphereGeometry(0.16, 6, 6), this.coconutMaterial);
      nut.position.set(Math.cos(ca) * 0.25, -0.15, Math.sin(ca) * 0.25);
      crown.add(nut);
    }

    group.add(crown);
    return group;
  }

  private buildRock(): THREE.Group {
    const group = new THREE.Group();
    const rockGeo = new THREE.DodecahedronGeometry(1.0, 1);
    const rockMesh = new THREE.Mesh(rockGeo, this.rockMaterial);
    rockMesh.scale.set(1.1, 0.85, 1.2);
    rockMesh.position.y = 0.7;
    rockMesh.castShadow = true;
    rockMesh.receiveShadow = true;
    group.add(rockMesh);

    const capGeo = new THREE.ConeGeometry(0.85, 0.4, 6);
    const cap = new THREE.Mesh(capGeo, this.pineSnowMaterial);
    cap.position.y = 1.35;
    group.add(cap);

    return group;
  }

  private buildBeachRock(): THREE.Group {
    const group = new THREE.Group();
    const rockGeo = new THREE.DodecahedronGeometry(1.05, 1);
    const rockMesh = new THREE.Mesh(rockGeo, this.beachRockMaterial);
    rockMesh.scale.set(1.2, 0.8, 1.3);
    rockMesh.position.y = 0.65;
    rockMesh.castShadow = true;
    rockMesh.receiveShadow = true;
    group.add(rockMesh);
    return group;
  }

  private buildSnowman(): THREE.Group {
    const group = new THREE.Group();

    const base = new THREE.Mesh(new THREE.SphereGeometry(0.55, 8, 8), this.pineSnowMaterial);
    base.position.y = 0.55;
    base.castShadow = true;
    group.add(base);

    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.4, 8, 8), this.pineSnowMaterial);
    torso.position.y = 1.25;
    torso.castShadow = true;
    group.add(torso);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), this.pineSnowMaterial);
    head.position.y = 1.78;
    head.castShadow = true;
    group.add(head);

    const carrotGeo = new THREE.ConeGeometry(0.06, 0.25, 5);
    carrotGeo.rotateX(Math.PI / 2);
    const carrotMat = new THREE.MeshStandardMaterial({ color: 0xf97316 });
    const nose = new THREE.Mesh(carrotGeo, carrotMat);
    nose.position.set(0, 1.78, 0.32);
    group.add(nose);

    const hatGeo = new THREE.CylinderGeometry(0.2, 0.2, 0.28, 8);
    const hatMat = new THREE.MeshStandardMaterial({ color: 0x18181b });
    const hat = new THREE.Mesh(hatGeo, hatMat);
    hat.position.set(0, 2.1, 0);
    group.add(hat);

    const brimGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.04, 8);
    const brim = new THREE.Mesh(brimGeo, hatMat);
    brim.position.set(0, 1.98, 0);
    group.add(brim);

    return group;
  }

  private buildSandcastle(): THREE.Group {
    const group = new THREE.Group();
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.7, 1.2), this.sandcastleMaterial);
    base.position.y = 0.35;
    base.castShadow = true;
    group.add(base);

    const turretGeo = new THREE.CylinderGeometry(0.18, 0.22, 1.1, 8);
    const coneGeo = new THREE.ConeGeometry(0.22, 0.45, 8);
    const offsets = [
      [-0.5, -0.5],
      [0.5, -0.5],
      [-0.5, 0.5],
      [0.5, 0.5],
    ];
    offsets.forEach(([ox, oz]) => {
      const turret = new THREE.Mesh(turretGeo, this.sandcastleMaterial);
      turret.position.set(ox, 0.55, oz);
      turret.castShadow = true;
      group.add(turret);

      const roof = new THREE.Mesh(coneGeo, this.sandcastleMaterial);
      roof.position.set(ox, 1.25, oz);
      group.add(roof);
    });

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.7, 4), this.woodMaterial);
    pole.position.set(0, 1.05, 0);
    group.add(pole);

    const flag = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.18), new THREE.MeshStandardMaterial({ color: 0xef4444, side: THREE.DoubleSide }));
    flag.position.set(0.15, 1.3, 0);
    group.add(flag);

    return group;
  }

  private buildTikiTotem(): THREE.Group {
    const group = new THREE.Group();

    const raftGeo = new THREE.BoxGeometry(1.6, 0.25, 1.6);
    const raft = new THREE.Mesh(raftGeo, this.woodMaterial);
    raft.position.y = 0.12;
    raft.castShadow = true;
    group.add(raft);

    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.4, 2.0, 8), this.tikiWoodMaterial);
    pole.position.y = 1.15;
    pole.castShadow = true;
    group.add(pole);

    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.16, 0.3), this.tikiWoodMaterial);
    brow.position.set(0, 1.7, 0.25);
    group.add(brow);

    const teeth = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.14, 0.28), new THREE.MeshStandardMaterial({ color: 0xfef08a }));
    teeth.position.set(0, 1.3, 0.25);
    group.add(teeth);

    const flameGeo = new THREE.ConeGeometry(0.18, 0.5, 6);
    const flameMat = new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xf97316, emissiveIntensity: 0.9 });
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(0, 2.35, 0);
    group.add(flame);

    return group;
  }

  private buildLogRail(): THREE.Group {
    const group = new THREE.Group();
    const logGeo = new THREE.CylinderGeometry(0.22, 0.24, 7.5, 7);
    logGeo.rotateX(Math.PI / 2);
    const log = new THREE.Mesh(logGeo, this.woodMaterial);
    log.position.y = 0.4;
    log.castShadow = true;
    group.add(log);

    const topGeo = new THREE.BoxGeometry(0.26, 0.08, 7.3);
    const top = new THREE.Mesh(topGeo, this.pineSnowMaterial);
    top.position.y = 0.62;
    group.add(top);

    return group;
  }

  private buildDriftwoodRail(): THREE.Group {
    const group = new THREE.Group();
    const logGeo = new THREE.CylinderGeometry(0.24, 0.26, 7.5, 7);
    logGeo.rotateX(Math.PI / 2);
    const log = new THREE.Mesh(logGeo, this.woodMaterial);
    log.position.y = 0.25;
    log.castShadow = true;
    group.add(log);

    const foamGeo = new THREE.PlaneGeometry(0.7, 7.5);
    foamGeo.rotateX(-Math.PI / 2);
    const foamMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55 });
    const foam = new THREE.Mesh(foamGeo, foamMat);
    foam.position.y = 0.05;
    group.add(foam);

    return group;
  }

  private buildSlalomGate(isBlue: boolean): THREE.Group {
    const group = new THREE.Group();
    const gateColor = isBlue ? 0x0284c7 : 0xef4444;
    const gateMat = new THREE.MeshStandardMaterial({ color: gateColor, metalness: 0.4, roughness: 0.3 });

    const poleGeo = new THREE.CylinderGeometry(0.06, 0.06, 2.4, 6);
    const pL = new THREE.Mesh(poleGeo, gateMat);
    pL.position.set(-2.0, 1.2, 0);
    pL.castShadow = true;
    group.add(pL);

    const pR = new THREE.Mesh(poleGeo, gateMat);
    pR.position.set(2.0, 1.2, 0);
    pR.castShadow = true;
    group.add(pR);

    const bannerGeo = new THREE.PlaneGeometry(3.9, 0.6);
    const banner = new THREE.Mesh(bannerGeo, gateMat);
    banner.position.set(0, 1.8, 0);
    group.add(banner);

    return group;
  }

  private buildBeachSlalomGate(isBlue: boolean): THREE.Group {
    const group = new THREE.Group();
    const buoyColor = isBlue ? 0x0284c7 : 0xef4444;
    const buoyMat = new THREE.MeshStandardMaterial({ color: buoyColor, metalness: 0.5, roughness: 0.25 });
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });

    const buildBuoy = (offsetX: number) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(offsetX, 0, 0);

      const floatGeo = new THREE.CylinderGeometry(0.5, 0.4, 0.8, 10);
      const floatMesh = new THREE.Mesh(floatGeo, buoyMat);
      floatMesh.position.y = 0.4;
      floatMesh.castShadow = true;
      bGroup.add(floatMesh);

      const bandGeo = new THREE.CylinderGeometry(0.51, 0.51, 0.22, 10);
      const bandMesh = new THREE.Mesh(bandGeo, whiteMat);
      bandMesh.position.y = 0.4;
      bGroup.add(bandMesh);

      const mastGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.2, 6);
      const mastMesh = new THREE.Mesh(mastGeo, whiteMat);
      mastMesh.position.y = 1.5;
      bGroup.add(mastMesh);

      const beaconGeo = new THREE.SphereGeometry(0.12, 6, 6);
      const beaconMat = new THREE.MeshBasicMaterial({ color: isBlue ? 0x38bdf8 : 0xfca5a5 });
      const beacon = new THREE.Mesh(beaconGeo, beaconMat);
      beacon.position.y = 2.6;
      bGroup.add(beacon);

      const ringGeo = new THREE.RingGeometry(0.5, 0.85, 12);
      ringGeo.rotateX(-Math.PI / 2);
      const splash = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 }));
      splash.position.y = 0.05;
      bGroup.add(splash);

      return bGroup;
    };

    const bL = buildBuoy(-2.2);
    const bR = buildBuoy(2.2);
    group.add(bL);
    group.add(bR);

    const flagGeo = new THREE.PlaneGeometry(4.0, 0.45);
    const flagMat = new THREE.MeshStandardMaterial({ color: buoyColor, side: THREE.DoubleSide, metalness: 0.3 });
    const flagMesh = new THREE.Mesh(flagGeo, flagMat);
    flagMesh.position.set(0, 1.9, 0);
    group.add(flagMesh);

    return group;
  }

  private buildFallingIcicle(): THREE.Group {
    const group = new THREE.Group();
    const icicleGeo = new THREE.ConeGeometry(0.35, 2.4, 6);
    icicleGeo.rotateX(Math.PI);
    const icicleMat = new THREE.MeshStandardMaterial({
      color: 0xe0f2fe,
      opacity: 0.85,
      transparent: true,
      roughness: 0.1,
      metalness: 0.3,
    });
    const mesh = new THREE.Mesh(icicleGeo, icicleMat);
    mesh.castShadow = true;
    group.add(mesh);
    return group;
  }

  private buildRollingSnowball(): THREE.Group {
    const group = new THREE.Group();
    const ballGeo = new THREE.DodecahedronGeometry(1.3, 1);
    const ballMesh = new THREE.Mesh(ballGeo, this.pineSnowMaterial);
    ballMesh.castShadow = true;
    group.add(ballMesh);
    return group;
  }

  private buildRollingBarrel(): THREE.Group {
    const group = new THREE.Group();
    const barrelGeo = new THREE.CylinderGeometry(0.85, 0.85, 1.6, 10);
    barrelGeo.rotateZ(Math.PI / 2);
    const barrel = new THREE.Mesh(barrelGeo, this.woodMaterial);
    barrel.castShadow = true;
    group.add(barrel);

    const hoopGeo = new THREE.TorusGeometry(0.86, 0.04, 4, 12);
    hoopGeo.rotateY(Math.PI / 2);
    const hoopMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8 });
    const h1 = new THREE.Mesh(hoopGeo, hoopMat);
    h1.position.x = -0.5;
    barrel.add(h1);
    const h2 = new THREE.Mesh(hoopGeo, hoopMat);
    h2.position.x = 0.5;
    barrel.add(h2);

    return group;
  }

  private spawnCollectibleRibbon(zStart: number) {
    const lineCount = 2;
    for (let l = 0; l < lineCount; l++) {
      const coinRunCount = 10;
      const startX = (Math.random() - 0.5) * 16;
      const zOffset = zStart + 4 + l * 30;
      for (let c = 0; c < coinRunCount; c++) {
        const cz = zOffset + c * 2.5;
        const cx = startX + Math.sin(c * 0.45) * 3.0;
        const cy = this.getTerrainHeight(cx, cz) + 0.85;

        const isGem = Math.random() < 0.35;
        const colMesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
        colMesh.position.set(cx, cy, cz);
        this.root.add(colMesh);

        this.collectibles.push({
          id: this.nextCollectibleId++,
          type: isGem ? 'gem' : 'coin',
          mesh: colMesh,
          position: colMesh.position,
          baseY: cy,
          isCollected: false,
          radius: isGem ? 1.6 : 1.3,
        });
      }
    }
  }

  // --- WORLD 3: HALLOWEEN CEMETERY & MANSION FEATURE POPULATORS ---
  private populateCemeteryFeatures(zStart: number, zEnd: number) {
    // 1. Weathered Stone Tombstones with crosses and headstones
    for (let i = 0; i < 8; i++) {
      const x = (Math.random() - 0.5) * 26;
      const z = zStart + 12 + i * 13;
      const y = this.getTerrainHeight(x, z);
      const tombstone = this.buildTombstone();
      tombstone.position.set(x, y, z);
      this.root.add(tombstone);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'tombstone',
        mesh: tombstone,
        collider: { type: 'box', radius: 0.9, halfWidth: 0.8, halfLength: 0.5, height: 1.5 },
        position: tombstone.position,
        isActive: true,
      });
    }

    // 2. Glowing Jack-o'-Lantern Pumpkins (Smashable for bonus coins!)
    for (let i = 0; i < 7; i++) {
      const x = (Math.random() - 0.5) * 24;
      const z = zStart + 8 + i * 16;
      const y = this.getTerrainHeight(x, z);
      const pumpkin = this.buildPumpkin();
      pumpkin.position.set(x, y, z);
      this.root.add(pumpkin);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'pumpkin',
        mesh: pumpkin,
        collider: { type: 'sphere', radius: 0.7, height: 0.9 },
        position: pumpkin.position,
        isActive: true,
      });
    }

    // 3. Spooky Twisted Dead Trees
    for (let i = 0; i < 5; i++) {
      const x = (i % 2 === 0 ? -1 : 1) * (11 + Math.random() * 8);
      const z = zStart + 15 + i * 22;
      const y = this.getTerrainHeight(x, z);
      const tree = this.buildSpookyTree();
      tree.position.set(x, y, z);
      this.root.add(tree);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'spooky_tree',
        mesh: tree,
        collider: { type: 'cylinder', radius: 1.1, height: 4.2 },
        position: tree.position,
        isActive: true,
      });
    }

    // 4. Cemetery Jump Ramps with Coin/Gem Arcs
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 16;
      const rz = zStart + 45;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnIndoorJumpRamp(rx, ry, rz);
    }

    // 5. Coins & Powerups
    this.spawnCollectibleRibbon(zStart + 20);
  }

  private populateMansionFeatures(zStart: number, zEnd: number) {
    // 1. Bubbling Witch Cauldrons with Neon Green Slime
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 14 + i * 26;
      const y = this.getTerrainHeight(x, z);
      const cauldron = this.buildWitchCauldron();
      cauldron.position.set(x, y, z);
      this.root.add(cauldron);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'cauldron',
        mesh: cauldron,
        collider: { type: 'cylinder', radius: 1.0, height: 1.3 },
        position: cauldron.position,
        isActive: true,
      });
    }

    // 2. Towering Gothic Bookcases with Spellbooks
    for (let i = 0; i < 5; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (12 + Math.random() * 3);
      const z = zStart + 18 + i * 22;
      const y = this.getTerrainHeight(x, z);
      const bookcase = this.buildMansionBookcase();
      bookcase.position.set(x, y, z);
      this.root.add(bookcase);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'bookcase',
        mesh: bookcase,
        collider: { type: 'box', radius: 1.3, halfWidth: 1.2, halfLength: 0.6, height: 3.0 },
        position: bookcase.position,
        isActive: true,
      });
    }

    // 3. Fireplace Hearths
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 28 + i * 35;
      const y = this.getTerrainHeight(x, z);
      const fireplace = this.buildChaletFireplace();
      fireplace.position.set(x, y, z);
      this.root.add(fireplace);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'furniture_fireplace',
        mesh: fireplace,
        collider: { type: 'box', radius: 1.3, halfWidth: 1.4, halfLength: 0.8, height: 2.6 },
        position: fireplace.position,
        isActive: true,
      });
    }

    // 4. Smashable Vintage Chairs
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 10 + i * 20;
      const y = this.getTerrainHeight(x, z);
      const chair = this.buildChaletChair();
      chair.position.set(x, y, z);
      this.root.add(chair);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'furniture_chair',
        mesh: chair,
        collider: { type: 'cylinder', radius: 0.65, height: 1.2 },
        position: chair.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 25);
  }

  // --- WORLD 4: SCHOOL HALLWAY & CLASSROOM FEATURE POPULATORS ---
  private populateHallwayFeatures(zStart: number, zEnd: number) {
    // 1. Metal Lockers along Hallway banks
    for (let i = 0; i < 5; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * 14;
      const z = zStart + 12 + i * 22;
      const y = this.getTerrainHeight(x, z);
      const lockers = this.buildSchoolLockers(i % 2 === 0);
      lockers.position.set(x, y, z);
      this.root.add(lockers);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'locker_bank',
        mesh: lockers,
        collider: { type: 'box', radius: 1.4, halfWidth: 1.5, halfLength: 0.7, height: 2.8 },
        position: lockers.position,
        isActive: true,
      });
    }

    // 2. Wet Floor Caution Cones (Smashable!)
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 8 + i * 18;
      const y = this.getTerrainHeight(x, z);
      const cone = this.buildWetFloorCone();
      cone.position.set(x, y, z);
      this.root.add(cone);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'wet_floor_cone',
        mesh: cone,
        collider: { type: 'cone' as unknown as 'cylinder', radius: 0.6, height: 1.1 },
        position: cone.position,
        isActive: true,
      });
    }

    // 3. Fallen School Backpacks (Kickable/Smashable!)
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 15 + i * 19;
      const y = this.getTerrainHeight(x, z);
      const backpack = this.buildBackpackObstacle();
      backpack.position.set(x, y, z);
      this.root.add(backpack);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'backpack',
        mesh: backpack,
        collider: { type: 'box', radius: 0.65, halfWidth: 0.6, halfLength: 0.5, height: 0.7 },
        position: backpack.position,
        isActive: true,
      });
    }

    // 4. Vending Machines (Red soda & snack machines)
    for (let i = 0; i < 3; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (10 + Math.random() * 4);
      const z = zStart + 25 + i * 32;
      const y = this.getTerrainHeight(x, z);
      const vm = this.buildVendingMachine();
      vm.position.set(x, y, z);
      this.root.add(vm);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'vending_machine',
        mesh: vm,
        collider: { type: 'box', radius: 1.2, halfWidth: 1.1, halfLength: 0.7, height: 2.4 },
        position: vm.position,
        isActive: true,
      });
    }

    // 5. Janitor Mop Buckets (Smashable yellow rolling bucket with soap splash!)
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 10 + i * 24;
      const y = this.getTerrainHeight(x, z);
      const mop = this.buildMopBucket();
      mop.position.set(x, y, z);
      this.root.add(mop);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'mop_bucket',
        mesh: mop,
        collider: { type: 'cylinder', radius: 0.65, height: 1.2 },
        position: mop.position,
        isActive: true,
      });
    }

    // 6. Metal Waste Bins (Smashable!)
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 18 + i * 25;
      const y = this.getTerrainHeight(x, z);
      const bin = this.buildTrashBin();
      bin.position.set(x, y, z);
      this.root.add(bin);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'trash_bin',
        mesh: bin,
        collider: { type: 'cylinder', radius: 0.55, height: 1.0 },
        position: bin.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 22);
  }

  private populateClassroomFeatures(zStart: number, zEnd: number) {
    // 1. Student Desks with Attached Chairs
    for (let i = 0; i < 6; i++) {
      const x = (Math.random() - 0.5) * 24;
      const z = zStart + 12 + i * 16;
      const y = this.getTerrainHeight(x, z);
      const desk = this.buildStudentDesk();
      desk.position.set(x, y, z);
      this.root.add(desk);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'student_desk',
        mesh: desk,
        collider: { type: 'box', radius: 1.1, halfWidth: 1.0, halfLength: 0.8, height: 1.1 },
        position: desk.position,
        isActive: true,
      });
    }

    // 2. Green Slate Chalkboards
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 20 + i * 28;
      const y = this.getTerrainHeight(x, z);
      const board = this.buildChalkboard();
      board.position.set(x, y, z);
      this.root.add(board);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'chalkboard',
        mesh: board,
        collider: { type: 'box', radius: 1.4, halfWidth: 1.5, halfLength: 0.4, height: 2.2 },
        position: board.position,
        isActive: true,
      });
    }

    // 3. Brass Globe Stands
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 16 + i * 36;
      const y = this.getTerrainHeight(x, z);
      const globe = this.buildGlobeStand();
      globe.position.set(x, y, z);
      this.root.add(globe);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'globe_stand',
        mesh: globe,
        collider: { type: 'cylinder', radius: 0.7, height: 1.4 },
        position: globe.position,
        isActive: true,
      });
    }

    // 4. Gym Hurdles (Jump over or blast through!)
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 14 + i * 25;
      const y = this.getTerrainHeight(x, z);
      const hurdle = this.buildGymHurdle();
      hurdle.position.set(x, y, z);
      this.root.add(hurdle);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'gym_hurdle',
        mesh: hurdle,
        collider: { type: 'box', radius: 1.2, halfWidth: 1.4, halfLength: 0.4, height: 1.2 },
        position: hurdle.position,
        isActive: true,
      });
    }

    // 5. Chemistry Lab Tables with Glass Flasks
    for (let i = 0; i < 3; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (11 + Math.random() * 4);
      const z = zStart + 22 + i * 30;
      const y = this.getTerrainHeight(x, z);
      const lab = this.buildLabDesk();
      lab.position.set(x, y, z);
      this.root.add(lab);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'lab_desk',
        mesh: lab,
        collider: { type: 'box', radius: 1.3, halfWidth: 1.5, halfLength: 0.8, height: 1.4 },
        position: lab.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  // --- WORLD 5: NEON CYBER CITY FEATURE POPULATORS ---
  private populateCyberHighwayFeatures(zStart: number, zEnd: number) {
    // 1. Glowing Neon Cyber Pylons lining the lanes
    for (let i = 0; i < 8; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (12 + Math.random() * 6);
      const z = zStart + 10 + i * 13;
      const y = this.getTerrainHeight(x, z);
      const pylon = this.buildCyberPylon(i % 2 === 0);
      pylon.position.set(x, y, z);
      this.root.add(pylon);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'cyber_pylon',
        mesh: pylon,
        collider: { type: 'cylinder', radius: 0.8, height: 5.0 },
        position: pylon.position,
        isActive: true,
      });
    }

    // 2. Holographic Laser Guard Barriers
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 20 + i * 28;
      const y = this.getTerrainHeight(x, z);
      const barrier = this.buildHoloBarrier();
      barrier.position.set(x, y, z);
      this.root.add(barrier);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'holo_barrier',
        mesh: barrier,
        collider: { type: 'box', radius: 1.8, halfWidth: 2.2, halfLength: 0.4, height: 1.4 },
        position: barrier.position,
        isActive: true,
      });
    }

    // 3. Neon Traffic Cones (Smashable for +40 coins!)
    for (let i = 0; i < 6; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 8 + i * 18;
      const y = this.getTerrainHeight(x, z);
      const cone = this.buildNeonCone();
      cone.position.set(x, y, z);
      this.root.add(cone);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'neon_cone',
        mesh: cone,
        collider: { type: 'cylinder', radius: 0.55, height: 1.0 },
        position: cone.position,
        isActive: true,
      });
    }

    // 4. Floating Holographic Cyber Billboards
    for (let i = 0; i < 3; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (14 + Math.random() * 4);
      const z = zStart + 18 + i * 35;
      const y = this.getTerrainHeight(x, z) + 1.5;
      const board = this.buildHoloBillboard(i);
      board.position.set(x, y, z);
      this.root.add(board);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'holo_billboard',
        mesh: board,
        collider: { type: 'box', radius: 1.5, halfWidth: 2.0, halfLength: 0.5, height: 3.5 },
        position: board.position,
        isActive: true,
      });
    }

    // 5. High-Speed Mag-Lev Jump Ramps
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 16;
      const rz = zStart + 45;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnIndoorJumpRamp(rx, ry, rz);
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  private populateCyberArcadeFeatures(zStart: number, zEnd: number) {
    // 1. Retro-Futuristic Neon Arcade Cabinets
    for (let i = 0; i < 6; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (11 + Math.random() * 5);
      const z = zStart + 12 + i * 18;
      const y = this.getTerrainHeight(x, z);
      const cabinet = this.buildArcadeCabinet(i % 3);
      cabinet.position.set(x, y, z);
      this.root.add(cabinet);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'arcade_cabinet',
        mesh: cabinet,
        collider: { type: 'box', radius: 1.1, halfWidth: 1.0, halfLength: 0.8, height: 2.4 },
        position: cabinet.position,
        isActive: true,
      });
    }

    // 2. Pulsing Laser Grids
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 16 + i * 26;
      const y = this.getTerrainHeight(x, z);
      const laser = this.buildLaserGrid();
      laser.position.set(x, y, z);
      this.root.add(laser);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'laser_grid',
        mesh: laser,
        collider: { type: 'box', radius: 1.6, halfWidth: 2.0, halfLength: 0.3, height: 1.8 },
        position: laser.position,
        isActive: true,
      });
    }

    // 3. Floating Hologram DJ Booths
    for (let i = 0; i < 2; i++) {
      const x = (Math.random() - 0.5) * 14;
      const z = zStart + 35 + i * 45;
      const y = this.getTerrainHeight(x, z);
      const booth = this.buildDJBooth();
      booth.position.set(x, y, z);
      this.root.add(booth);
      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dj_booth',
        mesh: booth,
        collider: { type: 'box', radius: 1.8, halfWidth: 2.4, halfLength: 1.1, height: 2.2 },
        position: booth.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 22);
  }

  // --- WORLD 6: SPRING BLOSSOM COAST POPULATORS & BUILDERS ---
  private populateSpringCoastFeatures(zStart: number, zEnd: number) {
    // 1. Blooming Sakura Cherry Blossom Trees
    for (let i = 0; i < 14; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (10 + Math.random() * 12);
      const z = zStart + 8 + i * 8;
      const y = this.getTerrainHeight(x, z);

      const tree = this.buildSakuraTree();
      tree.position.set(x, y, z);
      this.root.add(tree);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'sakura_tree',
        mesh: tree,
        collider: { type: 'cylinder', radius: 0.85, height: 4.8 },
        position: tree.position,
        isActive: true,
      });
    }

    // 2. Festive Pastel Celebration Tents (pink, yellow, light blue)
    for (let i = 0; i < 4; i++) {
      const side = Math.random() > 0.5 ? 1 : -1;
      const x = side * (12 + Math.random() * 6);
      const z = zStart + 15 + i * 26;
      const y = this.getTerrainHeight(x, z);

      const tent = this.buildPastelTent(i % 3);
      tent.position.set(x, y, z);
      this.root.add(tent);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'pastel_tent',
        mesh: tent,
        collider: { type: 'box', radius: 1.8, halfWidth: 2.2, halfLength: 2.2, height: 3.2 },
        position: tent.position,
        isActive: true,
      });
    }

    // 3. Blooming Flower Garland Arches over Track
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 8;
      const z = zStart + 25 + i * 35;
      const y = this.getTerrainHeight(x, z);

      const arch = this.buildFlowerArch();
      arch.position.set(x, y, z);
      this.root.add(arch);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'flower_arch',
        mesh: arch,
        collider: { type: 'box', radius: 1.4, halfWidth: 2.6, halfLength: 0.6, height: 3.2 },
        position: arch.position,
        isActive: true,
      });
    }

    // 4. Wooden Park Benches & Bridge Hurdles
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 18 + i * 24;
      const y = this.getTerrainHeight(x, z);

      const bench = this.buildWoodenBench();
      bench.position.set(x, y, z);
      this.root.add(bench);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'wooden_bench',
        mesh: bench,
        collider: { type: 'box', radius: 1.0, halfWidth: 1.4, halfLength: 0.6, height: 1.0 },
        position: bench.position,
        isActive: true,
      });
    }

    // 5. Jump Ramps
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 14;
      const rz = zStart + 45;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnJumpRamp(rx, ry, rz);
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  private populateSpringSakuraFeatures(zStart: number, zEnd: number) {
    // Sakura Bloom Tunnel - Dense arching pink canopy overhead
    for (let i = 0; i < 18; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (7 + Math.random() * 8);
      const z = zStart + 6 + i * 6;
      const y = this.getTerrainHeight(x, z);

      const tree = this.buildSakuraTree(true); // Large tunnel arch canopy
      tree.position.set(x, y, z);
      this.root.add(tree);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'sakura_tree',
        mesh: tree,
        collider: { type: 'cylinder', radius: 0.9, height: 5.2 },
        position: tree.position,
        isActive: true,
      });
    }

    // Festive Flower Festival Tents & Benches
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 14 + i * 25;
      const y = this.getTerrainHeight(x, z);

      const bench = this.buildWoodenBench();
      bench.position.set(x, y, z);
      this.root.add(bench);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'wooden_bench',
        mesh: bench,
        collider: { type: 'box', radius: 1.0, halfWidth: 1.4, halfLength: 0.6, height: 1.0 },
        position: bench.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 22);
  }

  // --- WORLD 7: SUGAR CANDY KINGDOM POPULATORS & BUILDERS ---
  private populateCandyForestFeatures(zStart: number, zEnd: number) {
    // 1. Giant Red & White Peppermint Candy Canes
    for (let i = 0; i < 8; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * (8 + Math.random() * 12);
      const z = zStart + 10 + i * 12;
      const y = this.getTerrainHeight(x, z);

      const cane = this.buildGiantCandyCane();
      cane.position.set(x, y, z);
      this.root.add(cane);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'giant_candy_cane',
        mesh: cane,
        collider: { type: 'cylinder', radius: 0.75, height: 4.6 },
        position: cane.position,
        isActive: true,
      });
    }

    // 2. Swirl Rainbow Lollipops
    for (let i = 0; i < 7; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 14 + i * 14;
      const y = this.getTerrainHeight(x, z);

      const lollipop = this.buildLollipop();
      lollipop.position.set(x, y, z);
      this.root.add(lollipop);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'lollipop',
        mesh: lollipop,
        collider: { type: 'cylinder', radius: 0.9, height: 4.2 },
        position: lollipop.position,
        isActive: true,
      });
    }

    // 3. Translucent Colorful Gummy Drop Obstacles
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 16 + i * 20;
      const y = this.getTerrainHeight(x, z);

      const gummy = this.buildGummyDrop(i % 2 === 0 ? 'ruby' : 'emerald');
      gummy.position.set(x, y, z);
      this.root.add(gummy);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'gummy_drop',
        mesh: gummy,
        collider: { type: 'sphere', radius: 1.0, height: 1.4 },
        position: gummy.position,
        isActive: true,
      });
    }

    // 4. Peppermint Swirl Disks
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 22 + i * 25;
      const y = this.getTerrainHeight(x, z);

      const swirl = this.buildPeppermintSwirl();
      swirl.position.set(x, y, z);
      this.root.add(swirl);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'peppermint_swirl',
        mesh: swirl,
        collider: { type: 'cylinder', radius: 1.2, height: 1.0 },
        position: swirl.position,
        isActive: true,
      });
    }

    // 5. Fluffy Cotton Candy Cloud Trees
    for (let i = 0; i < 6; i++) {
      const side = Math.random() > 0.5 ? 1 : -1;
      const x = side * (14 + Math.random() * 8);
      const z = zStart + 12 + i * 16;
      const y = this.getTerrainHeight(x, z);

      const cottonTree = this.buildCottonCandyTree();
      cottonTree.position.set(x, y, z);
      this.root.add(cottonTree);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'cotton_candy_tree',
        mesh: cottonTree,
        collider: { type: 'cylinder', radius: 1.2, height: 4.8 },
        position: cottonTree.position,
        isActive: true,
      });
    }

    // 6. Jump Ramps
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 14;
      const rz = zStart + 45;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnJumpRamp(rx, ry, rz);
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  private populateCandyPalaceFeatures(zStart: number, zEnd: number) {
    // Gummy Bear Palace & Giant Chocolate Waterfall Features
    for (let i = 0; i < 8; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const x = side * 14;
      const z = zStart + 10 + i * 14;
      const y = this.getTerrainHeight(x, z);

      const cane = this.buildGiantCandyCane();
      cane.position.set(x, y, z);
      this.root.add(cane);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'giant_candy_cane',
        mesh: cane,
        collider: { type: 'cylinder', radius: 0.8, height: 4.6 },
        position: cane.position,
        isActive: true,
      });
    }

    for (let i = 0; i < 6; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 12 + i * 18;
      const y = this.getTerrainHeight(x, z);

      const gummy = this.buildGummyDrop(i % 2 === 0 ? 'ruby' : 'emerald');
      gummy.position.set(x, y, z);
      this.root.add(gummy);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'gummy_drop',
        mesh: gummy,
        collider: { type: 'sphere', radius: 1.1, height: 1.5 },
        position: gummy.position,
        isActive: true,
      });
    }

    this.spawnCollectibleRibbon(zStart + 22);
  }

  private populateUniverseFeatures(zStart: number, zEnd: number, subZone: number) {
    // 1. Tumbling Floating Asteroids
    for (let i = 0; i < 7; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 12 + i * 14;
      const y = this.getTerrainHeight(x, z);

      const asteroid = this.buildAsteroid();
      asteroid.position.set(x, y, z);
      this.root.add(asteroid);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'space_asteroid',
        mesh: asteroid,
        collider: { type: 'sphere', radius: 1.3, height: 2.2 },
        position: asteroid.position,
        isActive: true,
      });
    }

    // 2. Glowing Cosmic Crystal Clusters
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 16 + i * 19;
      const y = this.getTerrainHeight(x, z);

      const crystal = this.buildCosmicCrystal();
      crystal.position.set(x, y, z);
      this.root.add(crystal);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'space_crystal',
        mesh: crystal,
        collider: { type: 'cylinder', radius: 1.1, height: 2.2 },
        position: crystal.position,
        isActive: true,
      });
    }

    // 3. Satellite Relay Communication Beacons
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 20 + i * 24;
      const y = this.getTerrainHeight(x, z);

      const beacon = this.buildSatelliteBeacon();
      beacon.position.set(x, y, z);
      this.root.add(beacon);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'satellite_beacon',
        mesh: beacon,
        collider: { type: 'cylinder', radius: 1.2, height: 3.4 },
        position: beacon.position,
        isActive: true,
      });
    }

    // 4. Cosmic Energy Slalom Gates
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 12;
      const z = zStart + 26 + i * 30;
      const y = this.getTerrainHeight(x, z);

      const gate = this.buildCosmicEnergyGate();
      gate.position.set(x, y, z);
      this.root.add(gate);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'slalom_gate',
        mesh: gate,
        collider: { type: 'box', radius: 1.8, halfWidth: 2.5, halfLength: 0.4, height: 3.2 },
        position: gate.position,
        isActive: true,
        dynamic: { hasTriggered: false },
      });
    }

    // 5. Zero-G Anti-Gravity Jump Ramp
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 12;
      const rz = zStart + 42;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnJumpRamp(rx, ry, rz);
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  private buildAsteroid(): THREE.Group {
    const group = new THREE.Group();
    const geo = new THREE.DodecahedronGeometry(1.3, 1);
    const mesh = new THREE.Mesh(geo, this.asteroidMaterial);
    mesh.position.y = 1.3;
    mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
    mesh.castShadow = true;
    group.add(mesh);
    return group;
  }

  private buildCosmicCrystal(): THREE.Group {
    const group = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const h = 1.8 + i * 0.4;
      const geo = new THREE.ConeGeometry(0.35, h, 6);
      const mesh = new THREE.Mesh(geo, this.cosmicCrystalMaterial);
      mesh.position.set((i - 1) * 0.45, h * 0.5, (i % 2 === 0 ? 0.2 : -0.2));
      mesh.rotation.z = (i - 1) * 0.15;
      mesh.castShadow = true;
      group.add(mesh);
    }
    return group;
  }

  private buildSatelliteBeacon(): THREE.Group {
    const group = new THREE.Group();
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.22, 3.2, 6), this.quantumBeaconMaterial);
    mast.position.y = 1.6;
    mast.castShadow = true;
    group.add(mast);

    const dish = new THREE.Mesh(new THREE.SphereGeometry(0.65, 8, 8, 0, Math.PI), this.energyRingMaterial);
    dish.rotation.x = Math.PI / 4;
    dish.position.set(0, 3.1, 0);
    group.add(dish);

    const panelGeo = new THREE.BoxGeometry(1.5, 0.05, 0.55);
    const panelL = new THREE.Mesh(panelGeo, this.neonCyanMaterial);
    panelL.position.set(-1.0, 2.6, 0);
    group.add(panelL);
    const panelR = new THREE.Mesh(panelGeo, this.neonCyanMaterial);
    panelR.position.set(1.0, 2.6, 0);
    group.add(panelR);
    return group;
  }

  private buildCosmicEnergyGate(): THREE.Group {
    const group = new THREE.Group();
    const poleGeo = new THREE.CylinderGeometry(0.12, 0.18, 3.2, 8);
    const pL = new THREE.Mesh(poleGeo, this.quantumBeaconMaterial);
    pL.position.set(-2.5, 1.6, 0);
    group.add(pL);
    const pR = new THREE.Mesh(poleGeo, this.quantumBeaconMaterial);
    pR.position.set(2.5, 1.6, 0);
    group.add(pR);

    const beamGeo = new THREE.CylinderGeometry(0.08, 0.08, 5.0, 6);
    beamGeo.rotateZ(Math.PI / 2);
    const beam = new THREE.Mesh(beamGeo, this.energyRingMaterial);
    beam.position.set(0, 2.8, 0);
    group.add(beam);
    return group;
  }

  private populateForestFeatures(zStart: number, zEnd: number, subZone: number) {
    // 1. Giant Ancient Redwood Tree Trunks
    for (let i = 0; i < 7; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 10 + i * 14;
      const y = this.getTerrainHeight(x, z);

      const tree = this.buildRedwoodTrunk();
      tree.position.set(x, y, z);
      this.root.add(tree);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'redwood_trunk',
        mesh: tree,
        collider: { type: 'cylinder', radius: 1.1, height: 7.5 },
        position: tree.position,
        isActive: true,
      });
    }

    // 2. Mossy River Boulders
    for (let i = 0; i < 5; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 16 + i * 18;
      const y = this.getTerrainHeight(x, z);

      const boulder = this.buildMossyBoulder();
      boulder.position.set(x, y, z);
      this.root.add(boulder);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'mossy_boulder',
        mesh: boulder,
        collider: { type: 'sphere', radius: 1.3, height: 2.0 },
        position: boulder.position,
        isActive: true,
      });
    }

    // 3. Fairytale Forest Mushroom Clusters (Kickable / smashable for coins!)
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 22 + i * 22;
      const y = this.getTerrainHeight(x, z);

      const shroom = this.buildForestMushroomCluster();
      shroom.position.set(x, y, z);
      this.root.add(shroom);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'forest_mushroom',
        mesh: shroom,
        collider: { type: 'cylinder', radius: 1.0, height: 1.5 },
        position: shroom.position,
        isActive: true,
      });
    }

    // 4. Ancient Runed Spirit Totems
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 12;
      const z = zStart + 28 + i * 28;
      const y = this.getTerrainHeight(x, z);

      const totem = this.buildSpiritTotem();
      totem.position.set(x, y, z);
      this.root.add(totem);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'spirit_totem',
        mesh: totem,
        collider: { type: 'cylinder', radius: 1.2, height: 3.8 },
        position: totem.position,
        isActive: true,
      });
    }

    // 5. Wooden Mossy Jump Ramps
    if (Math.random() > 0.3) {
      const rx = (Math.random() - 0.5) * 12;
      const rz = zStart + 42;
      const ry = this.getTerrainHeight(rx, rz);
      this.spawnJumpRamp(rx, ry, rz);
    }

    this.spawnCollectibleRibbon(zStart + 20);
  }

  private buildRedwoodTrunk(): THREE.Group {
    const group = new THREE.Group();
    const trunkGeo = new THREE.CylinderGeometry(0.7, 1.1, 7.5, 8);
    const trunk = new THREE.Mesh(trunkGeo, this.redwoodBarkMaterial);
    trunk.position.y = 3.75;
    trunk.castShadow = true;
    group.add(trunk);

    // Deep pine foliage crown
    const leafGeo = new THREE.ConeGeometry(2.4, 4.5, 7);
    const leaves = new THREE.Mesh(leafGeo, this.pineFoliageMaterial);
    leaves.position.y = 7.0;
    leaves.castShadow = true;
    group.add(leaves);
    return group;
  }

  private buildMossyBoulder(): THREE.Group {
    const group = new THREE.Group();
    const geo = new THREE.DodecahedronGeometry(1.3, 1);
    const mesh = new THREE.Mesh(geo, this.mossyRockMaterial);
    mesh.position.y = 1.1;
    mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
    mesh.castShadow = true;
    group.add(mesh);
    return group;
  }

  private buildForestMushroomCluster(): THREE.Group {
    const group = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const stem = new THREE.Mesh(
        new THREE.CylinderGeometry(0.12, 0.16, 0.8 + i * 0.2, 6),
        new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.8 })
      );
      stem.position.set((i - 1) * 0.45, (0.8 + i * 0.2) * 0.5, (i % 2 === 0 ? 0.2 : -0.2));
      group.add(stem);

      const cap = new THREE.Mesh(
        new THREE.SphereGeometry(0.4 + i * 0.1, 8, 8, 0, Math.PI * 2, 0, Math.PI * 0.5),
        this.mushroomCapMaterial
      );
      cap.position.set((i - 1) * 0.45, 0.8 + i * 0.2, (i % 2 === 0 ? 0.2 : -0.2));
      group.add(cap);
    }
    return group;
  }

  private buildSpiritTotem(): THREE.Group {
    const group = new THREE.Group();
    const log = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.55, 3.8, 8), this.totemWoodMaterial);
    log.position.y = 1.9;
    log.castShadow = true;
    group.add(log);

    // Glowing carved runic antlers atop totem
    const antlerGeo = new THREE.TorusGeometry(0.65, 0.08, 6, 12, Math.PI);
    const antler = new THREE.Mesh(antlerGeo, this.energyRingMaterial);
    antler.position.set(0, 3.8, 0);
    antler.rotation.z = Math.PI;
    group.add(antler);
    return group;
  }

  // --- PROCEDURAL BUILDERS FOR SPRING & CANDY ---
  private buildSakuraTree(isTunnelArch = false): THREE.Group {
    const group = new THREE.Group();
    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.25, 0.42, 3.8, 8);
    if (isTunnelArch) {
      trunkGeo.rotateZ(0.25);
    }
    const trunk = new THREE.Mesh(trunkGeo, this.sakuraBarkMaterial);
    trunk.position.y = 1.9;
    trunk.castShadow = true;
    group.add(trunk);

    // Lush Pink Sakura Blossom Canopy
    const foliageMat = this.sakuraFoliageMaterial;
    const crown1 = new THREE.Mesh(new THREE.SphereGeometry(1.8, 8, 8), foliageMat);
    crown1.position.set(0, 3.8, 0);
    crown1.castShadow = true;
    group.add(crown1);

    const crown2 = new THREE.Mesh(new THREE.SphereGeometry(1.3, 7, 7), foliageMat);
    crown2.position.set(0.9, 3.4, 0.5);
    crown2.castShadow = true;
    group.add(crown2);

    const crown3 = new THREE.Mesh(new THREE.SphereGeometry(1.3, 7, 7), foliageMat);
    crown3.position.set(-0.8, 3.5, -0.4);
    crown3.castShadow = true;
    group.add(crown3);

    return group;
  }

  private buildPastelTent(colorIdx = 0): THREE.Group {
    const group = new THREE.Group();
    const tentMat = colorIdx === 0 
      ? this.tentPastelPinkMaterial 
      : colorIdx === 1 
      ? this.tentPastelYellowMaterial 
      : this.tentPastelBlueMaterial;

    // 4 Corner Poles
    const poleMat = this.springBenchWoodMaterial;
    const poleGeo = new THREE.CylinderGeometry(0.06, 0.06, 2.4, 6);
    const corners = [[-1.4, -1.4], [1.4, -1.4], [-1.4, 1.4], [1.4, 1.4]];
    for (const [cx, cz] of corners) {
      const pole = new THREE.Mesh(poleGeo, poleMat);
      pole.position.set(cx, 1.2, cz);
      group.add(pole);
    }

    // Pyramid Canopy
    const roofGeo = new THREE.ConeGeometry(2.3, 1.4, 4);
    roofGeo.rotateY(Math.PI / 4);
    const roof = new THREE.Mesh(roofGeo, tentMat);
    roof.position.y = 3.1;
    roof.castShadow = true;
    group.add(roof);

    // Pennant Flag on top
    const flagGeo = new THREE.ConeGeometry(0.12, 0.45, 3);
    const flag = new THREE.Mesh(flagGeo, this.tentPastelPinkMaterial);
    flag.position.set(0, 3.9, 0);
    group.add(flag);

    return group;
  }

  private buildFlowerArch(): THREE.Group {
    const group = new THREE.Group();
    // Wooden arch posts
    const postGeo = new THREE.CylinderGeometry(0.12, 0.12, 3.2, 6);
    const leftPost = new THREE.Mesh(postGeo, this.springBenchWoodMaterial);
    leftPost.position.set(-2.2, 1.6, 0);
    group.add(leftPost);

    const rightPost = new THREE.Mesh(postGeo, this.springBenchWoodMaterial);
    rightPost.position.set(2.2, 1.6, 0);
    group.add(rightPost);

    // Arch beam
    const lintelGeo = new THREE.BoxGeometry(4.8, 0.22, 0.22);
    const lintel = new THREE.Mesh(lintelGeo, this.springBenchWoodMaterial);
    lintel.position.set(0, 3.2, 0);
    group.add(lintel);

    // Garland Flower Clusters along top
    const flowerMats = [this.sakuraFoliageMaterial, this.tentPastelYellowMaterial, this.tentPastelPinkMaterial];
    for (let i = 0; i < 9; i++) {
      const f = new THREE.Mesh(new THREE.SphereGeometry(0.24, 6, 6), flowerMats[i % flowerMats.length]);
      f.position.set(-2.0 + i * 0.5, 3.35, (i % 2 === 0 ? 0.08 : -0.08));
      group.add(f);
    }

    return group;
  }

  private buildWoodenBench(): THREE.Group {
    const group = new THREE.Group();
    const woodMat = this.springBenchWoodMaterial;

    // Bench Seat Plank
    const seat = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.1, 0.7), woodMat);
    seat.position.y = 0.5;
    seat.castShadow = true;
    group.add(seat);

    // Backrest
    const back = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.45, 0.08), woodMat);
    back.position.set(0, 0.85, -0.32);
    group.add(back);

    // Legs
    const legGeo = new THREE.BoxGeometry(0.08, 0.5, 0.6);
    const leftLeg = new THREE.Mesh(legGeo, woodMat);
    leftLeg.position.set(-0.9, 0.25, 0);
    group.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, woodMat);
    rightLeg.position.set(0.9, 0.25, 0);
    group.add(rightLeg);

    return group;
  }

  private buildGiantCandyCane(): THREE.Group {
    const group = new THREE.Group();
    // Straight candy pole
    const poleGeo = new THREE.CylinderGeometry(0.2, 0.22, 3.6, 12);
    const pole = new THREE.Mesh(poleGeo, this.candyCaneMaterial);
    pole.position.y = 1.8;
    pole.castShadow = true;
    group.add(pole);

    // Hook curve on top
    const hookGeo = new THREE.TorusGeometry(0.6, 0.2, 8, 16, Math.PI);
    const hook = new THREE.Mesh(hookGeo, this.candyCaneMaterial);
    hook.position.set(0.6, 3.6, 0);
    group.add(hook);

    // White candy stripes wrapped around
    const whiteBandMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
    for (let y = 0.4; y < 3.4; y += 0.6) {
      const band = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.16, 12), whiteBandMat);
      band.position.y = y;
      group.add(band);
    }

    return group;
  }

  private buildLollipop(): THREE.Group {
    const group = new THREE.Group();
    // White lollipop plastic stick
    const stickMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 3.2, 8), stickMat);
    stick.position.y = 1.6;
    stick.castShadow = true;
    group.add(stick);

    // Large flat circular lollipop candy head
    const headGeo = new THREE.CylinderGeometry(1.2, 1.2, 0.26, 16);
    headGeo.rotateX(Math.PI / 2);
    const head = new THREE.Mesh(headGeo, this.lollipopSwirlMaterial);
    head.position.y = 3.6;
    head.castShadow = true;
    group.add(head);

    // Rainbow candy concentric ring
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.08, 6, 16), ringMat);
    ring.position.y = 3.6;
    group.add(ring);

    return group;
  }

  private buildGummyDrop(color: 'ruby' | 'emerald'): THREE.Group {
    const group = new THREE.Group();
    const gummyMat = color === 'ruby' ? this.gummyRubyMaterial : this.gummyEmeraldMaterial;

    // Translucent gummy dome
    const domeGeo = new THREE.CylinderGeometry(0.65, 0.95, 1.2, 12);
    const dome = new THREE.Mesh(domeGeo, gummyMat);
    dome.position.y = 0.6;
    dome.castShadow = true;
    group.add(dome);

    const topCap = new THREE.Mesh(new THREE.SphereGeometry(0.65, 12, 8), gummyMat);
    topCap.position.y = 1.2;
    group.add(topCap);

    return group;
  }

  private buildPeppermintSwirl(): THREE.Group {
    const group = new THREE.Group();
    // Swirl wheel disk
    const wheelGeo = new THREE.CylinderGeometry(1.0, 1.0, 0.35, 16);
    const wheel = new THREE.Mesh(wheelGeo, this.peppermintSwirlMaterial);
    wheel.position.y = 0.6;
    wheel.castShadow = true;
    group.add(wheel);

    // Red candy swirl quadrants
    const redMat = this.candyCaneMaterial;
    for (let i = 0; i < 4; i++) {
      const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.36, 1.0), redMat);
      spoke.position.y = 0.6;
      spoke.rotation.y = (i * Math.PI) / 4;
      group.add(spoke);
    }

    return group;
  }

  private buildCottonCandyTree(): THREE.Group {
    const group = new THREE.Group();
    // Sugar cone stem
    const stemMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.5 });
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 3.2, 8), stemMat);
    stem.position.y = 1.6;
    stem.castShadow = true;
    group.add(stem);

    // Puffy cloud masses
    const cloudMat = this.cottonCandyMaterial;
    const c1 = new THREE.Mesh(new THREE.SphereGeometry(1.3, 8, 8), cloudMat);
    c1.position.set(0, 3.4, 0);
    c1.castShadow = true;
    group.add(c1);

    const c2 = new THREE.Mesh(new THREE.SphereGeometry(0.9, 7, 7), cloudMat);
    c2.position.set(0.7, 3.1, 0.4);
    group.add(c2);

    const c3 = new THREE.Mesh(new THREE.SphereGeometry(0.9, 7, 7), cloudMat);
    c3.position.set(-0.6, 3.2, -0.4);
    group.add(c3);

    return group;
  }

  // --- PROCEDURAL BUILDERS FOR HALLOWEEN & SCHOOL OBSTACLES ---
  private buildTombstone(): THREE.Group {
    const group = new THREE.Group();
    // Base plinth
    const base = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.25, 0.6), this.tombstoneMaterial);
    base.position.y = 0.125;
    base.castShadow = true;
    group.add(base);

    // Vertical stone slab
    const slab = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.2, 0.25), this.tombstoneMaterial);
    slab.position.y = 0.85;
    slab.castShadow = true;
    group.add(slab);

    // Arched crown
    const arch = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.25, 8), this.tombstoneMaterial);
    arch.rotation.x = Math.PI / 2;
    arch.position.y = 1.45;
    arch.castShadow = true;
    group.add(arch);

    // Cross motif on slab
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.5, 0.05), this.cemeteryGroundMaterial);
    crossV.position.set(0, 0.95, 0.13);
    group.add(crossV);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.12, 0.05), this.cemeteryGroundMaterial);
    crossH.position.set(0, 1.05, 0.13);
    group.add(crossH);

    return group;
  }

  private buildPumpkin(): THREE.Group {
    const group = new THREE.Group();
    // Squashed ribbed pumpkin
    const body = new THREE.Mesh(new THREE.SphereGeometry(0.65, 8, 8), this.pumpkinMaterial);
    body.scale.set(1.15, 0.85, 1.15);
    body.position.y = 0.55;
    body.castShadow = true;
    group.add(body);

    // Green twisted stem
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, 0.35, 6), this.palmFrondMaterial);
    stem.position.set(0, 1.15, 0);
    stem.rotation.z = 0.2;
    group.add(stem);

    // Glowing carved eyes
    const eyeL = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.1, 3), this.pumpkinGlowMaterial);
    eyeL.position.set(-0.2, 0.65, 0.62);
    eyeL.rotation.x = Math.PI / 2;
    group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.1, 3), this.pumpkinGlowMaterial);
    eyeR.position.set(0.2, 0.65, 0.62);
    eyeR.rotation.x = Math.PI / 2;
    group.add(eyeR);

    // Jagged smile mouth
    const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.12, 0.08), this.pumpkinGlowMaterial);
    mouth.position.set(0, 0.42, 0.65);
    group.add(mouth);

    return group;
  }

  private buildSpookyTree(): THREE.Group {
    const group = new THREE.Group();
    // Gnarled crooked trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.75, 4.2, 6), this.spookyBarkMaterial);
    trunk.position.y = 2.1;
    trunk.rotation.z = (Math.random() - 0.5) * 0.25;
    trunk.castShadow = true;
    group.add(trunk);

    // 3 Crooked bare branches
    for (let i = 0; i < 3; i++) {
      const angle = (i * Math.PI * 2) / 3;
      const branch = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.25, 2.4, 5), this.spookyBarkMaterial);
      branch.position.set(Math.cos(angle) * 0.7, 3.4 + i * 0.4, Math.sin(angle) * 0.7);
      branch.rotation.z = Math.cos(angle) * 0.8;
      branch.rotation.x = Math.sin(angle) * 0.8;
      branch.castShadow = true;
      group.add(branch);
    }
    return group;
  }

  private buildWitchCauldron(): THREE.Group {
    const group = new THREE.Group();
    // Cast iron pot
    const pot = new THREE.Mesh(new THREE.SphereGeometry(0.85, 10, 8), this.cauldronMaterial);
    pot.scale.set(1.0, 0.8, 1.0);
    pot.position.y = 0.75;
    pot.castShadow = true;
    group.add(pot);

    // Flared pot rim
    const rim = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.1, 6, 16), this.cauldronMaterial);
    rim.rotation.x = Math.PI / 2;
    rim.position.y = 1.35;
    group.add(rim);

    // Bubbling glowing green potion fluid
    const slime = new THREE.Mesh(new THREE.CircleGeometry(0.72, 12), this.potionMaterial);
    slime.rotation.x = -Math.PI / 2;
    slime.position.y = 1.32;
    group.add(slime);

    // Steam bubbles
    const bubble1 = new THREE.Mesh(new THREE.SphereGeometry(0.14, 6, 6), this.potionMaterial);
    bubble1.position.set(0.2, 1.45, 0.15);
    group.add(bubble1);
    const bubble2 = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), this.potionMaterial);
    bubble2.position.set(-0.25, 1.48, -0.2);
    group.add(bubble2);

    return group;
  }

  private buildMansionBookcase(): THREE.Group {
    const group = new THREE.Group();
    const frame = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.2, 0.7), this.chaletWallMaterial);
    frame.position.y = 1.6;
    frame.castShadow = true;
    group.add(frame);

    // Shelves with books
    for (let s = 0; s < 3; s++) {
      const shelfY = 0.8 + s * 0.8;
      const bookBlock = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.55, 0.45), this.furnitureWoodMaterial);
      bookBlock.position.set(0, shelfY, 0.15);
      group.add(bookBlock);
    }
    return group;
  }

  private buildSchoolLockers(isBlue = true): THREE.Group {
    const group = new THREE.Group();
    const mat = isBlue ? this.lockerBlueMaterial : this.lockerOrangeMaterial;
    // 3 Lockers in a unit
    const lockers = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.8, 0.8), mat);
    lockers.position.y = 1.4;
    lockers.castShadow = true;
    group.add(lockers);

    // Top vent slats
    for (let k = 0; k < 3; k++) {
      const xOffset = -0.7 + k * 0.7;
      const vent = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.15, 0.05), this.furnitureWoodMaterial);
      vent.position.set(xOffset, 2.4, 0.42);
      group.add(vent);
    }
    return group;
  }

  private buildWetFloorCone(): THREE.Group {
    const group = new THREE.Group();
    // Tall yellow hazard cone
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.42, 1.05, 4), this.coneHazardMaterial);
    cone.position.y = 0.525;
    cone.castShadow = true;
    group.add(cone);

    const base = new THREE.Mesh(new THREE.BoxGeometry(0.75, 0.06, 0.75), this.coneHazardMaterial);
    base.position.y = 0.03;
    group.add(base);
    return group;
  }

  private buildBackpackObstacle(): THREE.Group {
    const group = new THREE.Group();
    // Backpack body
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.8, 0.55), this.lockerBlueMaterial);
    body.position.y = 0.4;
    body.castShadow = true;
    group.add(body);

    // Front zipper pocket
    const pocket = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.45, 0.18), this.coolerMaterial);
    pocket.position.set(0, 0.32, 0.32);
    group.add(pocket);
    return group;
  }

  private buildStudentDesk(): THREE.Group {
    const group = new THREE.Group();
    // Wooden desktop
    const top = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.08, 0.85), this.deskWoodMaterial);
    top.position.y = 0.85;
    top.castShadow = true;
    group.add(top);

    // Metal legs
    const legGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.85, 6);
    const legMat = this.chandelierIronMaterial;
    for (let lx of [-0.5, 0.5]) {
      for (let lz of [-0.35, 0.35]) {
        const leg = new THREE.Mesh(legGeo, legMat);
        leg.position.set(lx, 0.425, lz);
        group.add(leg);
      }
    }

    // Attached plastic chair
    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.06, 0.6), this.lockerBlueMaterial);
    seat.position.set(0, 0.5, -0.65);
    group.add(seat);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.5, 0.06), this.lockerBlueMaterial);
    back.position.set(0, 0.8, -0.92);
    group.add(back);

    return group;
  }

  private buildChalkboard(): THREE.Group {
    const group = new THREE.Group();
    // Board surface
    const board = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.7, 0.08), this.chalkboardMaterial);
    board.position.y = 1.45;
    board.castShadow = true;
    group.add(board);

    // Wooden border
    const frame = new THREE.Mesh(new THREE.BoxGeometry(2.75, 1.85, 0.06), this.deskWoodMaterial);
    frame.position.y = 1.45;
    frame.position.z = -0.02;
    group.add(frame);

    // Standing A-frame legs
    const legGeo = new THREE.CylinderGeometry(0.04, 0.04, 2.3, 6);
    const legL = new THREE.Mesh(legGeo, this.deskWoodMaterial);
    legL.position.set(-1.2, 1.15, 0);
    group.add(legL);
    const legR = new THREE.Mesh(legGeo, this.deskWoodMaterial);
    legR.position.set(1.2, 1.15, 0);
    group.add(legR);

    return group;
  }

  private buildGlobeStand(): THREE.Group {
    const group = new THREE.Group();
    // Stand
    const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.25, 1.0, 8), this.coinMaterial);
    stand.position.y = 0.5;
    stand.castShadow = true;
    group.add(stand);

    // Spinning globe sphere
    const globe = new THREE.Mesh(new THREE.SphereGeometry(0.42, 10, 8), this.oceanMaterial);
    globe.position.y = 1.25;
    globe.castShadow = true;
    group.add(globe);

    // Brass meridian ring
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.04, 6, 16), this.coinMaterial);
    ring.rotation.y = Math.PI / 4;
    ring.position.y = 1.25;
    group.add(ring);

    return group;
  }

  // --- NEW SCHOOL OBSTACLE BUILDERS ---
  private buildVendingMachine(): THREE.Group {
    const group = new THREE.Group();
    // Red metal cabinet body
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.5, 0.9), this.vendingRedMaterial);
    body.position.y = 1.25;
    body.castShadow = true;
    group.add(body);

    // Front glass product window
    const glass = new THREE.Mesh(new THREE.BoxGeometry(1.2, 1.4, 0.06), this.icePatchMaterial);
    glass.position.set(0, 1.45, 0.46);
    group.add(glass);

    // Bottom pickup dispenser slot
    const slot = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.4, 0.06), this.cyberMetalMaterial);
    slot.position.set(0, 0.4, 0.46);
    group.add(slot);
    return group;
  }

  private buildMopBucket(): THREE.Group {
    const group = new THREE.Group();
    // Yellow bucket
    const bucket = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.3, 0.55, 8), this.mopYellowMaterial);
    bucket.position.y = 0.32;
    bucket.castShadow = true;
    group.add(bucket);

    // Mop wringer press
    const press = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.25, 0.3), this.coneHazardMaterial);
    press.position.set(0, 0.65, 0);
    group.add(press);

    // Leaning mop stick
    const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 1.4, 6), this.metalHurdleMaterial);
    stick.rotation.z = 0.25;
    stick.position.set(0.15, 0.8, 0);
    group.add(stick);
    return group;
  }

  private buildGymHurdle(): THREE.Group {
    const group = new THREE.Group();
    // Top crossbar
    const bar = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.14, 0.06), this.coneHazardMaterial);
    bar.position.y = 1.0;
    bar.castShadow = true;
    group.add(bar);

    // Metal uprights
    const legGeo = new THREE.CylinderGeometry(0.035, 0.035, 1.0, 6);
    const legL = new THREE.Mesh(legGeo, this.metalHurdleMaterial);
    legL.position.set(-0.8, 0.5, 0);
    group.add(legL);

    const legR = new THREE.Mesh(legGeo, this.metalHurdleMaterial);
    legR.position.set(0.8, 0.5, 0);
    group.add(legR);

    // Feet
    const footGeo = new THREE.BoxGeometry(0.06, 0.04, 0.6);
    const footL = new THREE.Mesh(footGeo, this.metalHurdleMaterial);
    footL.position.set(-0.8, 0.02, 0);
    group.add(footL);
    const footR = new THREE.Mesh(footGeo, this.metalHurdleMaterial);
    footR.position.set(0.8, 0.02, 0);
    group.add(footR);
    return group;
  }

  private buildLabDesk(): THREE.Group {
    const group = new THREE.Group();
    // Lab bench top
    const top = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.12, 1.1), this.cyberMetalMaterial);
    top.position.y = 0.95;
    top.castShadow = true;
    group.add(top);

    // 4 legs
    const legGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.9, 6);
    for (const lx of [-0.95, 0.95]) {
      for (const lz of [-0.42, 0.42]) {
        const leg = new THREE.Mesh(legGeo, this.metalHurdleMaterial);
        leg.position.set(lx, 0.45, lz);
        group.add(leg);
      }
    }

    // Glass chemical flasks
    const flask1 = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.28, 8), this.potionMaterial);
    flask1.position.set(-0.5, 1.12, 0);
    group.add(flask1);

    const flask2 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), this.gemMaterial);
    flask2.position.set(0.4, 1.1, 0.1);
    group.add(flask2);
    return group;
  }

  private buildTrashBin(): THREE.Group {
    const group = new THREE.Group();
    const can = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.28, 0.85, 10), this.metalHurdleMaterial);
    can.position.y = 0.425;
    can.castShadow = true;
    group.add(can);

    const lid = new THREE.Mesh(new THREE.SphereGeometry(0.33, 8, 6, 0, Math.PI * 2, 0, Math.PI / 2), this.cyberMetalMaterial);
    lid.position.y = 0.85;
    group.add(lid);
    return group;
  }

  // --- CYBER CITY OBSTACLE BUILDERS ---
  private buildCyberPylon(isCyan = true): THREE.Group {
    const group = new THREE.Group();
    // Central hexagonal obsidian pillar
    const pylon = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 4.6, 6), this.cyberMetalMaterial);
    pylon.position.y = 2.3;
    pylon.castShadow = true;
    group.add(pylon);

    // Glowing neon rings
    const ringMat = isCyan ? this.neonCyanMaterial : this.neonPinkMaterial;
    for (let k = 0; k < 3; k++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.05, 6, 12), ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 1.0 + k * 1.3;
      group.add(ring);
    }

    // Glowing top beacon
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), isCyan ? this.neonCyanMaterial : this.neonYellowMaterial);
    beacon.position.y = 4.7;
    group.add(beacon);
    return group;
  }

  private buildHoloBarrier(): THREE.Group {
    const group = new THREE.Group();
    // Left & right generator posts
    const postGeo = new THREE.CylinderGeometry(0.12, 0.16, 1.4, 6);
    const postL = new THREE.Mesh(postGeo, this.cyberMetalMaterial);
    postL.position.set(-1.8, 0.7, 0);
    group.add(postL);

    const postR = new THREE.Mesh(postGeo, this.cyberMetalMaterial);
    postR.position.set(1.8, 0.7, 0);
    group.add(postR);

    // Glowing laser beam field
    const laser = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.8, 0.04), this.neonCyanMaterial);
    laser.position.y = 0.75;
    group.add(laser);
    return group;
  }

  private buildNeonCone(): THREE.Group {
    const group = new THREE.Group();
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.95, 6), this.neonPinkMaterial);
    cone.position.y = 0.475;
    group.add(cone);

    const base = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 0.7), this.cyberMetalMaterial);
    base.position.y = 0.03;
    group.add(base);
    return group;
  }

  private buildLaserGrid(): THREE.Group {
    const group = new THREE.Group();
    // 2 side posts
    const postL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 1.8, 6), this.cyberMetalMaterial);
    postL.position.set(-1.6, 0.9, 0);
    group.add(postL);

    const postR = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 1.8, 6), this.cyberMetalMaterial);
    postR.position.set(1.6, 0.9, 0);
    group.add(postR);

    // 2 horizontal red lasers
    for (let i = 0; i < 2; i++) {
      const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 3.2, 6), this.neonPinkMaterial);
      beam.rotation.z = Math.PI / 2;
      beam.position.set(0, 0.5 + i * 0.7, 0);
      group.add(beam);
    }
    return group;
  }

  private buildHoloBillboard(variant = 0): THREE.Group {
    const group = new THREE.Group();
    // Metal mounting column
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.18, 3.6, 6), this.cyberMetalMaterial);
    pole.position.y = 1.8;
    group.add(pole);

    // Floating cyber screen
    const screenMat = variant % 2 === 0 ? this.neonCyanMaterial : this.neonPinkMaterial;
    const screen = new THREE.Mesh(new THREE.BoxGeometry(3.0, 1.6, 0.12), screenMat);
    screen.position.set(0, 3.2, 0);
    group.add(screen);

    // Frame bezel
    const bezel = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.8, 0.08), this.cyberMetalMaterial);
    bezel.position.set(0, 3.2, -0.04);
    group.add(bezel);
    return group;
  }

  private buildArcadeCabinet(variant = 0): THREE.Group {
    const group = new THREE.Group();
    // Cabinet chassis
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.2, 2.3, 0.9), this.cyberMetalMaterial);
    body.position.y = 1.15;
    body.castShadow = true;
    group.add(body);

    // Glowing CRT display screen
    const screenMat = variant === 0 ? this.neonCyanMaterial : variant === 1 ? this.neonPinkMaterial : this.neonYellowMaterial;
    const screen = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.75, 0.05), screenMat);
    screen.position.set(0, 1.45, 0.44);
    group.add(screen);

    // Marquee sign at top
    const marquee = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.3, 0.06), this.neonYellowMaterial);
    marquee.position.set(0, 2.15, 0.43);
    group.add(marquee);
    return group;
  }

  private buildDJBooth(): THREE.Group {
    const group = new THREE.Group();
    // Floating console desk
    const desk = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.8, 1.1), this.cyberMetalMaterial);
    desk.position.y = 0.9;
    desk.castShadow = true;
    group.add(desk);

    // Dual neon vinyl turntables
    const tt1 = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.06, 12), this.neonCyanMaterial);
    tt1.position.set(-0.65, 1.34, 0);
    group.add(tt1);

    const tt2 = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.06, 12), this.neonPinkMaterial);
    tt2.position.set(0.65, 1.34, 0);
    group.add(tt2);

    // Equalizer panel on front
    const eq = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.35, 0.04), this.neonCyanMaterial);
    eq.position.set(0, 0.9, 0.57);
    group.add(eq);
    return group;
  }

  private buildCoinMesh(): THREE.Group {
    const group = new THREE.Group();
    const coinGeo = new THREE.CylinderGeometry(0.35, 0.35, 0.08, 8);
    coinGeo.rotateX(Math.PI / 2);
    const coin = new THREE.Mesh(coinGeo, this.coinMaterial);
    coin.castShadow = true;
    group.add(coin);
    return group;
  }

  private buildGemMesh(): THREE.Group {
    const group = new THREE.Group();
    const gemGeo = new THREE.OctahedronGeometry(0.4, 0);
    const gem = new THREE.Mesh(gemGeo, this.gemMaterial);
    gem.castShadow = true;
    group.add(gem);
    return group;
  }

  private buildPowerUpMesh(type: PowerUpType): THREE.Group {
    const group = new THREE.Group();
    const mat = this.powerUpMaterials[type];

    if (type === 'star') {
      const starShape = new THREE.Shape();
      const points = 5;
      const outerR = 0.58;
      const innerR = 0.25;
      for (let i = 0; i < points * 2; i++) {
        const r = i % 2 === 0 ? outerR : innerR;
        const a = (i * Math.PI) / points - Math.PI / 2;
        const x = Math.cos(a) * r;
        const y = Math.sin(a) * r;
        if (i === 0) starShape.moveTo(x, y);
        else starShape.lineTo(x, y);
      }
      starShape.closePath();

      const starGeo = new THREE.ExtrudeGeometry(starShape, {
        depth: 0.18,
        bevelEnabled: true,
        bevelThickness: 0.06,
        bevelSize: 0.04,
        bevelSegments: 2,
      });
      starGeo.center();

      const starMesh = new THREE.Mesh(starGeo, mat);
      starMesh.castShadow = true;
      group.add(starMesh);

      const coreLight = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.2, 0),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      group.add(coreLight);

      const ringGeo = new THREE.TorusGeometry(0.72, 0.035, 6, 24);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
      const ring1 = new THREE.Mesh(ringGeo, ringMat);
      ring1.rotation.x = Math.PI / 3;
      group.add(ring1);

      const ring2 = new THREE.Mesh(ringGeo, ringMat);
      ring2.rotation.y = Math.PI / 3;
      group.add(ring2);

      return group;
    }

    const coreGeo = new THREE.IcosahedronGeometry(0.45, 0);
    const core = new THREE.Mesh(coreGeo, mat);
    core.castShadow = true;
    group.add(core);

    const ringGeo = new THREE.TorusGeometry(0.65, 0.04, 6, 16);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    group.add(ring);
    return group;
  }

  private spawnJumpRamp(x: number, y: number, z: number) {
    const width = 6.0;
    const length = 7.0;
    const height = 1.6;

    const shape = new THREE.Shape();
    shape.moveTo(-length / 2, 0);
    shape.lineTo(length / 2, height);
    shape.lineTo(length / 2, 0);
    shape.closePath();

    const rampGeo = new THREE.ExtrudeGeometry(shape, { depth: width, bevelEnabled: false });
    rampGeo.rotateY(Math.PI / 2);
    rampGeo.translate(-width / 2, 0, 0);

    const rampMesh = new THREE.Mesh(rampGeo, this.pineSnowMaterial);
    rampMesh.position.set(x, y, z);
    rampMesh.castShadow = true;
    rampMesh.receiveShadow = true;
    this.root.add(rampMesh);

    this.ramps.push({ position: rampMesh.position, width, length, height, mesh: rampMesh });

    for (let i = 0; i < 5; i++) {
      const acz = z + length * 0.5 + i * 5.0;
      const acx = x;
      const acy = this.getTerrainHeight(acx, acz) + height + 2.2 + Math.sin((i / 4) * Math.PI) * 2.8;
      const isGem = i === 2;
      const mesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
      mesh.position.set(acx, acy, acz);
      this.root.add(mesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: isGem ? 'gem' : 'coin',
        mesh,
        position: mesh.position,
        baseY: acy,
        isCollected: false,
        radius: 1.6,
      });
    }
  }

  private spawnBeachJumpRamp(x: number, y: number, z: number) {
    const width = 6.0;
    const length = 7.0;
    const height = 1.6;

    const shape = new THREE.Shape();
    shape.moveTo(-length / 2, 0);
    shape.lineTo(length / 2, height);
    shape.lineTo(length / 2, 0);
    shape.closePath();

    const rampGeo = new THREE.ExtrudeGeometry(shape, { depth: width, bevelEnabled: false });
    rampGeo.rotateY(Math.PI / 2);
    rampGeo.translate(-width / 2, 0, 0);

    const rampMesh = new THREE.Mesh(rampGeo, this.woodMaterial);
    rampMesh.position.set(x, y, z);
    rampMesh.castShadow = true;
    rampMesh.receiveShadow = true;
    this.root.add(rampMesh);

    const floatMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, roughness: 0.3, metalness: 0.2 });
    const floatGeo = new THREE.CylinderGeometry(0.55, 0.55, length * 0.9, 8);
    floatGeo.rotateX(Math.PI / 2);

    const fLeft = new THREE.Mesh(floatGeo, floatMat);
    fLeft.position.set(-width * 0.4, -0.2, 0);
    rampMesh.add(fLeft);

    const fRight = new THREE.Mesh(floatGeo, floatMat);
    fRight.position.set(width * 0.4, -0.2, 0);
    rampMesh.add(fRight);

    this.ramps.push({ position: rampMesh.position, width, length, height, mesh: rampMesh });

    for (let i = 0; i < 5; i++) {
      const acz = z + length * 0.5 + i * 5.0;
      const acx = x;
      const acy = this.getTerrainHeight(acx, acz) + height + 2.2 + Math.sin((i / 4) * Math.PI) * 2.8;
      const isGem = i === 2;
      const mesh = isGem ? this.buildGemMesh() : this.buildCoinMesh();
      mesh.position.set(acx, acy, acz);
      this.root.add(mesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: isGem ? 'gem' : 'coin',
        mesh,
        position: mesh.position,
        baseY: acy,
        isCollected: false,
        radius: isGem ? 1.6 : 1.3,
      });
    }
  }

  /**
   * Updates dynamic hazards, spins collectibles, and recycles distant chunks behind player
   */
  public update(dt: number, playerZ: number, isFrozen: boolean) {
    const simDt = isFrozen ? dt * 0.4 : dt;

    // 1. Recycle terrain chunks
    const recycleThreshold = playerZ - 80;
    for (let i = this.terrainChunks.length - 1; i >= 0; i--) {
      const chunk = this.terrainChunks[i];
      if (chunk.zEnd < recycleThreshold) {
        this.root.remove(chunk.mesh);
        chunk.mesh.geometry.dispose();
        if (chunk.oceanLeft) {
          this.root.remove(chunk.oceanLeft);
          chunk.oceanLeft.geometry.dispose();
        }
        if (chunk.oceanRight) {
          this.root.remove(chunk.oceanRight);
          chunk.oceanRight.geometry.dispose();
        }
        if (chunk.chaletProps) {
          this.root.remove(chunk.chaletProps);
        }
        this.terrainChunks.splice(i, 1);

        // Spawn new chunk ahead with current active subzone
        const lastChunk = this.terrainChunks[this.terrainChunks.length - 1];
        const nextZ = lastChunk ? lastChunk.zEnd : playerZ;
        this.spawnChunk(nextZ);
      }
    }

    // 2. Clean up behind obstacles & collectibles
    this.obstacles = this.obstacles.filter((obs) => {
      if (obs.position.z < recycleThreshold) {
        this.root.remove(obs.mesh);
        if (obs.dynamic?.warningCircle) {
          this.root.remove(obs.dynamic.warningCircle);
        }
        return false;
      }
      return true;
    });

    this.collectibles = this.collectibles.filter((col) => {
      if (col.position.z < recycleThreshold) {
        this.root.remove(col.mesh);
        return false;
      }
      return true;
    });

    // 3. Update Dynamic Hazards
    this.obstacles.forEach((obs) => {
      if (!obs.isActive) return;

      if ((obs.type === 'icicle' || obs.type === 'coconut') && obs.dynamic) {
        const distZ = obs.position.z - playerZ;
        if (distZ < 45 && !obs.dynamic.hasTriggered) {
          obs.dynamic.hasTriggered = true;
        }
        if (obs.dynamic.hasTriggered) {
          obs.dynamic.vy = (obs.dynamic.vy || 0) - 24 * simDt;
          obs.position.y += obs.dynamic.vy * simDt;

          const groundY = this.getTerrainHeight(obs.position.x, obs.position.z);
          if (obs.position.y <= groundY) {
            obs.position.y = groundY;
            obs.isActive = false;
            obs.mesh.visible = false;
            if (obs.dynamic.warningCircle) {
              obs.dynamic.warningCircle.visible = false;
            }
          }
        }
      } else if (obs.type === 'rolling_snowball' && obs.dynamic) {
        const distZ = obs.position.z - playerZ;
        if (distZ < 70) {
          obs.position.x += (obs.dynamic.vx || 0) * simDt;
          obs.position.z += (obs.dynamic.vz || 0) * simDt;
          obs.position.y = this.getTerrainHeight(obs.position.x, obs.position.z) + 1.2;
          obs.mesh.rotation.x += 4 * simDt;
          obs.mesh.rotation.z += 3 * simDt;
        }
      }
    });

    // 4. Spin Collectibles (Optimized: only animate items within active camera range)
    const now = performance.now() * 0.003;
    const colCount = this.collectibles.length;
    for (let i = 0; i < colCount; i++) {
      const col = this.collectibles[i];
      if (!col.isCollected && Math.abs(col.position.z - playerZ) < 80) {
        col.mesh.rotation.y += 3.0 * dt;
        col.position.y = col.baseY + Math.sin(now + col.id) * 0.18;
      }
    }
  }

  public reset() {
    this.obstacles.forEach((o) => {
      this.root.remove(o.mesh);
      if (o.dynamic?.warningCircle) this.root.remove(o.dynamic.warningCircle);
    });
    this.obstacles = [];

    this.collectibles.forEach((c) => this.root.remove(c.mesh));
    this.collectibles = [];

    this.ramps.forEach((r) => this.root.remove(r.mesh));
    this.ramps = [];

    this.terrainChunks.forEach((c) => {
      this.root.remove(c.mesh);
      c.mesh.geometry.dispose();
      if (c.oceanLeft) {
        this.root.remove(c.oceanLeft);
        c.oceanLeft.geometry.dispose();
      }
      if (c.oceanRight) {
        this.root.remove(c.oceanRight);
        c.oceanRight.geometry.dispose();
      }
      if (c.chaletProps) {
        this.root.remove(c.chaletProps);
      }
    });
    this.terrainChunks = [];

    for (let i = -1; i < this.activeChunkCount - 1; i++) {
      this.spawnChunk(i * this.chunkLength);
    }
  }

  /**
   * World 10: Dinner Time Banquet Procedural Features
   */
  private populateDinnerTimeFeatures(zStart: number, zEnd: number, subZone: number) {
    // 1. Giant Porcelain Dinner Plates (Dodge the tableware!)
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 12 + i * 24;
      const y = this.getTerrainHeight(x, z);

      const plate = this.buildDinnerPlate();
      plate.position.set(x, y, z);
      this.root.add(plate);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_plate',
        mesh: plate,
        collider: { type: 'cylinder', radius: 1.8, height: 0.8 },
        position: plate.position,
        isActive: true,
      });
    }

    // 2. Upright Silver Stainless Dinner Forks
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 18 + i * 22;
      const y = this.getTerrainHeight(x, z);

      const fork = this.buildDinnerFork();
      fork.position.set(x, y, z);
      this.root.add(fork);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_fork',
        mesh: fork,
        collider: { type: 'box', radius: 1.0, halfWidth: 0.8, halfLength: 0.8, height: 3.2 },
        position: fork.position,
        isActive: true,
      });
    }

    // 3. Upright Silver Carving Knives
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 24 + i * 28;
      const y = this.getTerrainHeight(x, z);

      const knife = this.buildDinnerKnife();
      knife.position.set(x, y, z);
      this.root.add(knife);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_knife',
        mesh: knife,
        collider: { type: 'box', radius: 0.9, halfWidth: 0.7, halfLength: 0.7, height: 3.4 },
        position: knife.position,
        isActive: true,
      });
    }

    // 4. Towering Double Cheeseburgers
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 15 + i * 25;
      const y = this.getTerrainHeight(x, z);

      const burger = this.buildDinnerBurger();
      burger.position.set(x, y, z);
      this.root.add(burger);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_burger',
        mesh: burger,
        collider: { type: 'cylinder', radius: 1.5, height: 2.2 },
        position: burger.position,
        isActive: true,
      });
    }

    // 5. Giant Cheesy Pepperoni Pizza Slices
    for (let i = 0; i < 4; i++) {
      const x = (Math.random() - 0.5) * 20;
      const z = zStart + 20 + i * 23;
      const y = this.getTerrainHeight(x, z);

      const pizza = this.buildDinnerPizza();
      pizza.position.set(x, y, z);
      this.root.add(pizza);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_pizza',
        mesh: pizza,
        collider: { type: 'box', radius: 1.4, halfWidth: 1.3, halfLength: 1.4, height: 1.2 },
        position: pizza.position,
        isActive: true,
      });
    }

    // 6. Roasted Turkey Platter
    for (let i = 0; i < 2; i++) {
      const x = (Math.random() - 0.5) * 16;
      const z = zStart + 35 + i * 42;
      const y = this.getTerrainHeight(x, z);

      const turkey = this.buildDinnerRoastTurkey();
      turkey.position.set(x, y, z);
      this.root.add(turkey);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_roast_turkey',
        mesh: turkey,
        collider: { type: 'box', radius: 1.6, halfWidth: 1.7, halfLength: 1.5, height: 2.0 },
        position: turkey.position,
        isActive: true,
      });
    }

    // 7. Ketchup & Mustard Condiment Bottles
    for (let i = 0; i < 3; i++) {
      const isMustard = i % 2 === 1;
      const x = (Math.random() - 0.5) * 22;
      const z = zStart + 14 + i * 30;
      const y = this.getTerrainHeight(x, z);

      const bottle = isMustard ? this.buildDinnerMustard() : this.buildDinnerKetchup();
      bottle.position.set(x, y, z);
      this.root.add(bottle);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: isMustard ? 'dinner_mustard' : 'dinner_ketchup',
        mesh: bottle,
        collider: { type: 'cylinder', radius: 0.9, height: 2.8 },
        position: bottle.position,
        isActive: true,
      });
    }

    // 8. Frosted Strawberry Rainbow Donuts
    for (let i = 0; i < 3; i++) {
      const x = (Math.random() - 0.5) * 18;
      const z = zStart + 26 + i * 27;
      const y = this.getTerrainHeight(x, z);

      const donut = this.buildDinnerDonut();
      donut.position.set(x, y, z);
      this.root.add(donut);

      this.obstacles.push({
        id: this.nextObstacleId++,
        type: 'dinner_donut',
        mesh: donut,
        collider: { type: 'cylinder', radius: 1.3, height: 1.6 },
        position: donut.position,
        isActive: true,
      });
    }

    // 9. Tablecloth Banquet Collectible Coins & Star Powers
    for (let i = 0; i < 18; i++) {
      const lane = ((i % 3) - 1) * 3.5;
      const z = zStart + 8 + i * 5;
      const y = this.getTerrainHeight(lane, z) + 0.65;
      const coinMesh = this.buildCoinMesh();
      coinMesh.position.set(lane, y, z);
      this.root.add(coinMesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: 'coin',
        mesh: coinMesh,
        position: coinMesh.position,
        baseY: y,
        isCollected: false,
        radius: 1.6,
      });
    }
    if (Math.random() < 0.6) {
      const z = zStart + 45;
      const x = (Math.random() - 0.5) * 10;
      const y = this.getTerrainHeight(x, z) + 0.9;
      const gemMesh = this.buildGemMesh();
      gemMesh.position.set(x, y, z);
      this.root.add(gemMesh);
      this.collectibles.push({
        id: this.nextCollectibleId++,
        type: 'gem',
        mesh: gemMesh,
        position: gemMesh.position,
        baseY: y,
        isCollected: false,
        radius: 1.8,
      });
    }
  }

  // --- 3D FOOD BUILDERS FOR DINNER TIME ---

  private buildDinnerPlate(): THREE.Group {
    const group = new THREE.Group();
    // Wide ceramic porcelain plate
    const basePlate = new THREE.Mesh(
      new THREE.CylinderGeometry(1.9, 1.6, 0.22, 24),
      this.dinnerPlateMaterial
    );
    basePlate.castShadow = true;
    basePlate.receiveShadow = true;
    group.add(basePlate);

    // Golden decorative rim trim
    const rimMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.2 });
    const rim = new THREE.Mesh(new THREE.TorusGeometry(1.85, 0.05, 8, 24), rimMat);
    rim.rotation.x = Math.PI / 2;
    rim.position.y = 0.12;
    group.add(rim);

    // Blue decorative inner ring
    const blueRingMat = new THREE.MeshStandardMaterial({ color: 0x2563eb, roughness: 0.3 });
    const blueRing = new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.03, 6, 24), blueRingMat);
    blueRing.rotation.x = Math.PI / 2;
    blueRing.position.y = 0.12;
    group.add(blueRing);

    return group;
  }

  private buildDinnerFork(): THREE.Group {
    const group = new THREE.Group();
    // Fork handle standing tilted in napkin or upright
    const handle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.08, 0.12, 2.6, 8),
      this.dinnerSteelMaterial
    );
    handle.position.y = 1.3;
    handle.rotation.z = 0.15;
    handle.castShadow = true;
    group.add(handle);

    // Base collar
    const collar = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.15, 0.1),
      this.dinnerSteelMaterial
    );
    collar.position.set(0.2, 2.5, 0);
    collar.rotation.z = 0.15;
    group.add(collar);

    // 4 Silver Prongs / Tines
    for (let t = -1.5; t <= 1.5; t += 1.0) {
      const tine = new THREE.Mesh(
        new THREE.CylinderGeometry(0.035, 0.035, 0.85, 6),
        this.dinnerSteelMaterial
      );
      tine.position.set(0.2 + t * 0.12, 2.9, 0);
      tine.rotation.z = 0.15;
      group.add(tine);
    }
    return group;
  }

  private buildDinnerKnife(): THREE.Group {
    const group = new THREE.Group();
    // Stainless steel knife handle
    const handle = new THREE.Mesh(
      new THREE.BoxGeometry(0.22, 1.4, 0.28),
      new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.6 })
    );
    handle.position.y = 0.7;
    handle.castShadow = true;
    group.add(handle);

    // Gleaming blade
    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(0.1, 1.8, 0.35),
      this.dinnerSteelMaterial
    );
    blade.position.y = 2.1;
    blade.castShadow = true;
    group.add(blade);

    return group;
  }

  private buildDinnerBurger(): THREE.Group {
    const group = new THREE.Group();
    // Bottom golden bun
    const bottomBun = new THREE.Mesh(
      new THREE.CylinderGeometry(1.35, 1.25, 0.35, 16),
      this.dinnerBunMaterial
    );
    bottomBun.position.y = 0.18;
    bottomBun.castShadow = true;
    group.add(bottomBun);

    // Grilled beef patty 1
    const patty1 = new THREE.Mesh(
      new THREE.CylinderGeometry(1.4, 1.4, 0.3, 16),
      this.dinnerPattyMaterial
    );
    patty1.position.y = 0.48;
    patty1.castShadow = true;
    group.add(patty1);

    // Melted yellow cheddar cheese slice (drooping corners)
    const cheese = new THREE.Mesh(
      new THREE.BoxGeometry(1.9, 0.08, 1.9),
      this.dinnerCheeseMaterial
    );
    cheese.position.y = 0.65;
    cheese.rotation.y = Math.PI / 4;
    group.add(cheese);

    // Crispy green lettuce leaves
    const lettuce = new THREE.Mesh(
      new THREE.CylinderGeometry(1.5, 1.45, 0.1, 12),
      this.dinnerLettuceMaterial
    );
    lettuce.position.y = 0.74;
    group.add(lettuce);

    // Grilled beef patty 2
    const patty2 = new THREE.Mesh(
      new THREE.CylinderGeometry(1.4, 1.4, 0.3, 16),
      this.dinnerPattyMaterial
    );
    patty2.position.y = 0.94;
    patty2.castShadow = true;
    group.add(patty2);

    // Top toasted sesame bun dome
    const topBunGeo = new THREE.SphereGeometry(1.38, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2);
    const topBun = new THREE.Mesh(topBunGeo, this.dinnerBunMaterial);
    topBun.position.y = 1.05;
    topBun.scale.set(1.0, 0.65, 1.0);
    topBun.castShadow = true;
    group.add(topBun);

    // Sesame seeds on top
    const seedMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });
    for (let s = 0; s < 14; s++) {
      const angle = (s / 14) * Math.PI * 2;
      const r = 0.4 + (s % 3) * 0.25;
      const seed = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.08), seedMat);
      seed.position.set(Math.cos(angle) * r, 1.58, Math.sin(angle) * r);
      group.add(seed);
    }
    return group;
  }

  private buildDinnerPizza(): THREE.Group {
    const group = new THREE.Group();
    // Triangular pizza slice (wedge geometry)
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(-1.1, 2.2);
    shape.lineTo(1.1, 2.2);
    shape.closePath();

    const extrudeSettings = { depth: 0.22, bevelEnabled: true, bevelSegments: 2, steps: 1, bevelSize: 0.05, bevelThickness: 0.05 };
    const pizzaGeo = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    pizzaGeo.rotateX(-Math.PI / 2);

    const slice = new THREE.Mesh(pizzaGeo, this.dinnerPizzaMaterial);
    slice.castShadow = true;
    group.add(slice);

    // Puffed crust at back
    const crustMat = new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.7 });
    const crust = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 2.3, 10), crustMat);
    crust.rotation.z = Math.PI / 2;
    crust.position.set(0, 0.2, -2.2);
    group.add(crust);

    // Pepperoni slices
    for (let p = 0; p < 4; p++) {
      const peppy = new THREE.Mesh(
        new THREE.CylinderGeometry(0.28, 0.28, 0.04, 12),
        this.dinnerPepperoniMaterial
      );
      peppy.position.set((p % 2 === 0 ? -0.4 : 0.4) * (p > 1 ? 1.5 : 0.7), 0.25, -(0.8 + p * 0.4));
      group.add(peppy);
    }
    return group;
  }

  private buildDinnerRoastTurkey(): THREE.Group {
    const group = new THREE.Group();
    // Silver banquet platter
    const platter = new THREE.Mesh(
      new THREE.CylinderGeometry(1.8, 1.5, 0.15, 20),
      this.dinnerSteelMaterial
    );
    platter.scale.set(1.4, 1.0, 1.0);
    platter.position.y = 0.08;
    platter.castShadow = true;
    group.add(platter);

    // Plump roasted turkey body
    const bodyGeo = new THREE.SphereGeometry(1.0, 14, 12);
    const body = new THREE.Mesh(bodyGeo, this.dinnerTurkeyMaterial);
    body.scale.set(1.3, 0.9, 0.95);
    body.position.set(0, 0.85, 0);
    body.castShadow = true;
    group.add(body);

    // 2 Drumsticks
    for (let side of [-1, 1]) {
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.22, 0.35, 0.9, 8),
        this.dinnerTurkeyMaterial
      );
      leg.position.set(side * 0.85, 0.8, 0.4);
      leg.rotation.z = side * 0.6;
      group.add(leg);

      // White chef paper frill on bone
      const frill = new THREE.Mesh(
        new THREE.CylinderGeometry(0.16, 0.16, 0.25, 8),
        new THREE.MeshBasicMaterial({ color: 0xffffff })
      );
      frill.position.set(side * 1.15, 1.1, 0.5);
      group.add(frill);
    }
    return group;
  }

  private buildDinnerKetchup(): THREE.Group {
    const group = new THREE.Group();
    // Tall red squeeze bottle
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.48, 0.55, 2.0, 16),
      this.dinnerKetchupMaterial
    );
    body.position.y = 1.0;
    body.castShadow = true;
    group.add(body);

    // White label
    const label = new THREE.Mesh(
      new THREE.CylinderGeometry(0.49, 0.52, 0.9, 16),
      new THREE.MeshBasicMaterial({ color: 0xffffff })
    );
    label.position.y = 1.0;
    group.add(label);

    // Dispenser nozzle cone
    const nozzle = new THREE.Mesh(
      new THREE.ConeGeometry(0.2, 0.6, 12),
      this.dinnerKetchupMaterial
    );
    nozzle.position.y = 2.25;
    group.add(nozzle);

    return group;
  }

  private buildDinnerMustard(): THREE.Group {
    const group = new THREE.Group();
    // Tall yellow mustard squeeze bottle
    const body = new THREE.Mesh(
      new THREE.CylinderGeometry(0.48, 0.55, 2.0, 16),
      this.dinnerMustardMaterial
    );
    body.position.y = 1.0;
    body.castShadow = true;
    group.add(body);

    // Label band
    const label = new THREE.Mesh(
      new THREE.CylinderGeometry(0.49, 0.52, 0.9, 16),
      new THREE.MeshBasicMaterial({ color: 0x1e3a8a })
    );
    label.position.y = 1.0;
    group.add(label);

    // Dispenser cone
    const nozzle = new THREE.Mesh(
      new THREE.ConeGeometry(0.2, 0.6, 12),
      this.dinnerMustardMaterial
    );
    nozzle.position.y = 2.25;
    group.add(nozzle);

    return group;
  }

  private buildDinnerDonut(): THREE.Group {
    const group = new THREE.Group();
    // Baked dough torus
    const doughMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.65 });
    const dough = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.38, 12, 24), doughMat);
    dough.rotation.x = Math.PI / 2;
    dough.position.y = 0.45;
    dough.castShadow = true;
    group.add(dough);

    // Sweet pink strawberry frosting
    const frosting = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.36, 10, 24), this.dinnerDonutMaterial);
    frosting.rotation.x = Math.PI / 2;
    frosting.position.y = 0.52;
    group.add(frosting);

    // Rainbow sprinkles
    const sprinkleColors = [0x38bdf8, 0xfacc15, 0x4ade80, 0xffffff];
    for (let s = 0; s < 16; s++) {
      const angle = (s / 16) * Math.PI * 2;
      const sprinkle = new THREE.Mesh(
        new THREE.BoxGeometry(0.06, 0.04, 0.12),
        new THREE.MeshBasicMaterial({ color: sprinkleColors[s % sprinkleColors.length] })
      );
      sprinkle.position.set(Math.cos(angle) * 0.9, 0.72, Math.sin(angle) * 0.9);
      sprinkle.rotation.y = angle + 0.5;
      group.add(sprinkle);
    }
    return group;
  }

  public dispose() {
    this.reset();
    this.snowMaterial.dispose();
    this.icePatchMaterial.dispose();
    this.woodMaterial.dispose();
    this.pineFoliageMaterial.dispose();
    this.pineSnowMaterial.dispose();
    this.rockMaterial.dispose();
    this.chaletFloorMaterial.dispose();
    this.chaletWallMaterial.dispose();
    this.furnitureWoodMaterial.dispose();
    this.furnitureCushionMaterial.dispose();
    this.stoneBrickMaterial.dispose();
    this.fireGlowMaterial.dispose();
    this.chandelierIronMaterial.dispose();
    this.lanternGlassMaterial.dispose();
    this.sandMaterial.dispose();
    this.oceanMaterial.dispose();
    this.palmBarkMaterial.dispose();
    this.palmFrondMaterial.dispose();
    this.coconutMaterial.dispose();
    this.beachRockMaterial.dispose();
    this.sandcastleMaterial.dispose();
    this.tikiWoodMaterial.dispose();
    this.tidePoolMaterial.dispose();
    this.umbrellaCanopyMaterial.dispose();
    this.coolerMaterial.dispose();
    this.cemeteryGroundMaterial.dispose();
    this.tombstoneMaterial.dispose();
    this.pumpkinMaterial.dispose();
    this.pumpkinGlowMaterial.dispose();
    this.spookyBarkMaterial.dispose();
    this.cauldronMaterial.dispose();
    this.potionMaterial.dispose();
    this.schoolHallwayFloorMaterial.dispose();
    this.lockerBlueMaterial.dispose();
    this.lockerOrangeMaterial.dispose();
    this.deskWoodMaterial.dispose();
    this.chalkboardMaterial.dispose();
    this.coneHazardMaterial.dispose();
    this.springRoadFloorMaterial.dispose();
    this.springSakuraFloorMaterial.dispose();
    this.sakuraBarkMaterial.dispose();
    this.sakuraFoliageMaterial.dispose();
    this.tentPastelPinkMaterial.dispose();
    this.tentPastelYellowMaterial.dispose();
    this.tentPastelBlueMaterial.dispose();
    this.springBenchWoodMaterial.dispose();
    this.candyFloorMaterial.dispose();
    this.candyPalaceFloorMaterial.dispose();
    this.candyCaneMaterial.dispose();
    this.lollipopSwirlMaterial.dispose();
    this.gummyRubyMaterial.dispose();
    this.gummyEmeraldMaterial.dispose();
    this.peppermintSwirlMaterial.dispose();
    this.cottonCandyMaterial.dispose();
    this.universeRoadMaterial.dispose();
    this.universePlanetMaterial.dispose();
    this.asteroidMaterial.dispose();
    this.cosmicCrystalMaterial.dispose();
    this.energyRingMaterial.dispose();
    this.quantumBeaconMaterial.dispose();
    this.forestMossMaterial.dispose();
    this.forestGladeMaterial.dispose();
    this.redwoodBarkMaterial.dispose();
    this.mossyRockMaterial.dispose();
    this.mushroomCapMaterial.dispose();
    this.totemWoodMaterial.dispose();
    this.dinnerTableclothMaterial.dispose();
    this.dinnerGoldClothMaterial.dispose();
    this.dinnerPlateMaterial.dispose();
    this.dinnerSteelMaterial.dispose();
    this.dinnerBunMaterial.dispose();
    this.dinnerPattyMaterial.dispose();
    this.dinnerCheeseMaterial.dispose();
    this.dinnerLettuceMaterial.dispose();
    this.dinnerPizzaMaterial.dispose();
    this.dinnerPepperoniMaterial.dispose();
    this.dinnerTurkeyMaterial.dispose();
    this.dinnerKetchupMaterial.dispose();
    this.dinnerMustardMaterial.dispose();
    this.dinnerDonutMaterial.dispose();
    this.coinMaterial.dispose();
    this.gemMaterial.dispose();
    this.warningMaterial.dispose();
    Object.values(this.powerUpMaterials).forEach((m) => m.dispose());
  }
}
