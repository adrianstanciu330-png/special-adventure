import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { 
  CharacterDef, 
  CharacterCustomization, 
  GameStatus, 
  RunStats, 
  ActivePowerUp, 
  PowerUpType, 
  TrickEvent,
  WeatherInfo,
  WeatherType,
  MapTheme,
  DifficultyLevel,
  PlayerProgress,
  GameModeId
} from '../types/game';
import { CharacterRig, createCharacterMesh } from './characterMesh';
import { MountainTrack } from './mountain';
import { ParticleSystem } from './particles';
import { WeatherSystem } from './weather';
import { SkiTracksSystem } from './skiTracks';
import { sound } from './audio';
import { updateDailyChallengeProgress } from './dailyChallenges';

// Pre-allocated math objects to avoid garbage collection
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();

export interface GameEngineCallbacks {
  onStatsUpdate: (stats: RunStats) => void;
  onPowerUpsUpdate: (powerUps: ActivePowerUp[]) => void;
  onTrick: (trick: TrickEvent) => void;
  onWeatherUpdate: (weather: WeatherInfo) => void;
  onGameOver: (finalStats: RunStats) => void;
  onNearMiss: () => void;
  onGatePassed: () => void;
  onShieldLost: () => void;
}

export class GameEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  public isSoftwareGl: boolean;

  private container: HTMLElement;
  private animFrameId: number = 0;
  private isDestroyed: boolean = false;
  private callbacks: GameEngineCallbacks;

  // Subsystems
  public track: MountainTrack;
  public particles: ParticleSystem;
  public weather: WeatherSystem;
  public skiTracks: SkiTracksSystem;
  public playerRig: CharacterRig | null = null;
  private auraLight: THREE.PointLight | null = null;

  // Game Status & Difficulty
  public status: GameStatus = 'title';
  public difficulty: DifficultyLevel = 'normal';
  private characterDef: CharacterDef;
  private customization: CharacterCustomization;

  // Physics & Kinematics
  private playerPos = new THREE.Vector3(0, 0, 0);
  private forwardSpeed = 0; // m/s
  private lateralSpeed = 0; // m/s
  private verticalSpeed = 0; // m/s
  private carveAngle = 0; // -1 to +1
  private isAirborne = false;
  private airtimeTimer = 0;
  private coyoteTimer = 0;
  private jumpBuffered = false;

  // Tricks & Rotations in Air
  private airRotation = { pitch: 0, yaw: 0, roll: 0 };
  private totalRotations = { pitch: 0, yaw: 0, roll: 0 };
  private currentTrickName: string | null = null;

  // PowerUps & Abilities
  private activePowerUps: Map<PowerUpType, { duration: number; maxDuration: number }> = new Map();
  private armorCharges = 0;
  private boostEnergy = 100; // 0 to 100
  private isBoosting = false;

  // Hitstop & Camera Shake
  private hitstopTimer = 0;
  private cameraShake = 0;

  // VIP Membership
  public isVip: boolean = false;

  // The Deep Forest Sacred Deer Chase
  private sacredDeerMesh: THREE.Group | null = null;
  private deerLight: THREE.PointLight | null = null;
  private isDeerChasing: boolean = false;
  private forestDeerTimer: number = 0;

  // Dynamic Shadow Sunlight
  private sunLight: THREE.DirectionalLight | null = null;

  // Permanent Upgrades & Equippable Gear
  public magnetLevel: number = 1;
  public extraShieldCharges: number = 0;
  public doubleCoinsPerma: boolean = false;
  public gliderWings: boolean = false;
  public nitroRechargeLevel: number = 1;
  public iceBreaker: boolean = false;
  public alpineGrips: boolean = false;
  public diamondMiner: boolean = false;
  public forestCloak: boolean = false;
  public cosmicEngine: boolean = false;
  public luckyCharm: boolean = false;
  public doubleGemsPerma: boolean = false;
  public starlightThruster: boolean = false;
  public selectedAuraTrail: string = 'none';

  // Player Lives: STRICTLY 1 LIFE IN ALL MODES!
  public lives: number = 1;
  public maxLives: number = 1;
  private invulnerableTimer: number = 0;

  // 10 Game Modes System
  public gameMode: GameModeId = 'classic';
  public botRank: number = 1;
  public packageIntegrity: number = 100;
  public packagesDelivered: number = 0;
  public timeRemaining: number = 35.0;
  public slalomStreak: number = 0;

  // Stats
  private stats: RunStats = {
    distance: 0,
    speed: 0,
    topSpeed: 0,
    score: 0,
    multiplier: 1,
    coinsCollected: 0,
    gemsCollected: 0,
    gatesPassed: 0,
    tricksLanded: 0,
    airtimeTotal: 0,
    nearMisses: 0,
  };

  // Input states
  private keysHeld: Record<string, boolean> = {};
  public mapTheme: MapTheme = 'snow';
  public invertSteering: boolean = false;
  private had10Points = false;
  private currentScoreZoneIndex = 0;

  // World Pursuers (Halloween Witch & School Teacher)
  private witchPursuer: THREE.Group | null = null;
  private teacherPursuer: THREE.Group | null = null;

  public setInvertSteering(invert: boolean) {
    this.invertSteering = invert;
  }

  constructor(
    container: HTMLElement,
    characterDef: CharacterDef,
    customization: CharacterCustomization,
    callbacks: GameEngineCallbacks,
    initialTheme: MapTheme = 'snow'
  ) {
    this.container = container;
    this.characterDef = characterDef;
    this.customization = customization;
    this.callbacks = callbacks;
    this.mapTheme = initialTheme;

    // Clear any previous canvas/elements in container from prior mounts
    while (this.container.firstChild) {
      this.container.removeChild(this.container.firstChild);
    }

    // 1. Scene & Atmosphere
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xa5d8ff); // Crisp alpine morning sky
    this.scene.fog = new THREE.FogExp2(0xa5d8ff, 0.006);

    // 2. Camera
    const aspect = Math.max(0.1, (container.clientWidth || 800) / (container.clientHeight || 600));
    this.camera = new THREE.PerspectiveCamera(60, aspect, 0.1, 800);
    this.camera.position.set(0, 2.5, -5.8);

    // 3. Renderer with robust fallback
    let rendererInstance: THREE.WebGLRenderer | null = null;
    const rendererOptions: THREE.WebGLRendererParameters[] = [
      { antialias: false, powerPreference: 'default', precision: 'mediump', failIfMajorPerformanceCaveat: false },
      { antialias: false, powerPreference: 'low-power', precision: 'lowp', failIfMajorPerformanceCaveat: false },
    ];

    for (const opt of rendererOptions) {
      try {
        rendererInstance = new THREE.WebGLRenderer(opt);
        if (rendererInstance && rendererInstance.getContext()) {
          break;
        }
      } catch (err) {
        console.warn('WebGL init attempt failed, trying fallback option...', err);
      }
    }

    if (!rendererInstance) {
      throw new Error('WebGL context could not be created. Please reload to restore graphics.');
    }

    this.renderer = rendererInstance;

    // Handle context loss gracefully without triggering browser security block
    this.renderer.domElement.addEventListener('webglcontextlost', (e) => {
      e.preventDefault();
      console.warn('WebGL context lost - preventDefault invoked');
    }, false);

    this.isSoftwareGl = false;

    const width = container.clientWidth || window.innerWidth || 800;
    const height = container.clientHeight || window.innerHeight || 600;
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    // Enable high-fidelity dynamic shadow mapping
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. Studio Environment Reflections
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Lighting Rig with Dynamic Shadows
    this.sunLight = new THREE.DirectionalLight(0xffedd5, 2.0);
    this.sunLight.position.set(22, 38, 15);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 1024;
    this.sunLight.shadow.mapSize.height = 1024;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 120;
    this.sunLight.shadow.camera.left = -28;
    this.sunLight.shadow.camera.right = 28;
    this.sunLight.shadow.camera.top = 28;
    this.sunLight.shadow.camera.bottom = -28;
    this.sunLight.shadow.bias = -0.0004;
    this.sunLight.shadow.normalBias = 0.02;
    this.scene.add(this.sunLight);
    this.scene.add(this.sunLight.target);

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x1e293b, 1.2);
    this.scene.add(hemiLight);

    // 6. Subsystems initialized with theme
    this.track = new MountainTrack(this.mapTheme);
    this.scene.add(this.track.root);

    this.particles = new ParticleSystem();
    this.particles.setTheme(this.mapTheme);
    this.scene.add(this.particles.root);

    this.skiTracks = new SkiTracksSystem();
    this.skiTracks.setTheme(this.mapTheme);
    this.scene.add(this.skiTracks.root);

    this.weather = new WeatherSystem(this.scene, this.sunLight, hemiLight, this.scene.fog as THREE.FogExp2);
    this.weather.setTheme(this.mapTheme);

    // 7. Load Player Character Mesh dressed for map
    this.loadCharacter(characterDef, customization, this.mapTheme);

    // 8. Bind Events
    this.bindInputs();
    window.addEventListener('resize', this.handleResize);

    // Start simulation loop
    this.lastTime = performance.now();
    this.startLoop();
  }

  public setMapTheme(theme: MapTheme) {
    this.mapTheme = theme;

    let skyColor = 0xa5d8ff;
    let fogDensity = 0.006;
    if (theme === 'beach') {
      skyColor = 0x67e8f9;
      fogDensity = 0.004;
    } else if (theme === 'halloween') {
      skyColor = 0x0f0728; // Spooky midnight violet
      fogDensity = 0.009;
    } else if (theme === 'school') {
      skyColor = 0xdbeafe; // Bright school hall
      fogDensity = 0.003;
    } else if (theme === 'cyber') {
      skyColor = 0x070719; // Deep synthwave neon violet-night
      fogDensity = 0.006;
    } else if (theme === 'spring') {
      skyColor = 0xbbf7d0; // Fresh spring pastel sky
      fogDensity = 0.004;
    } else if (theme === 'candy') {
      skyColor = 0xfbcfe8; // Sweet pink strawberry frosting sky
      fogDensity = 0.005;
    } else if (theme === 'forest') {
      skyColor = 0x062817; // Deep mystical redwood forest emerald
      fogDensity = 0.007;
    } else if (theme === 'universe') {
      skyColor = 0x03030c; // Deep outer space cosmos
      fogDensity = 0.003;
    } else if (theme === 'dinner_time') {
      skyColor = 0x3b1406; // Warm cozy candlelight dinner banquet hall
      fogDensity = 0.004;
    }

    this.scene.background = new THREE.Color(skyColor);
    if (this.scene.fog) {
      (this.scene.fog as THREE.FogExp2).color.set(skyColor);
      (this.scene.fog as THREE.FogExp2).density = fogDensity;
    }

    this.track.setMapTheme(theme);
    this.particles.setTheme(theme);
    this.skiTracks.setTheme(theme);
    this.weather.setTheme(theme);
    if (this.playerRig) {
      this.playerRig.setMapTheme(theme);
    }
  }

  public loadCharacter(def: CharacterDef, custom: CharacterCustomization, theme?: MapTheme) {
    if (this.playerRig) {
      this.scene.remove(this.playerRig.root);
      this.playerRig.dispose();
    }
    this.characterDef = def;
    this.customization = custom;
    const activeTheme = theme || this.mapTheme;
    this.playerRig = createCharacterMesh(def, custom, activeTheme);
    this.scene.add(this.playerRig.root);

    // Special ability traits
    if (def.id === 'glacier_guardian') {
      this.armorCharges = 1;
    } else {
      this.armorCharges = 0;
    }
  }

  public updateCustomization(custom: CharacterCustomization) {
    this.customization = custom;
    if (this.playerRig) {
      this.playerRig.updateCustomization(custom);
    }
  }

  public syncGear(progress: Partial<PlayerProgress>) {
    if (progress.selectedDifficulty) {
      this.difficulty = progress.selectedDifficulty;
    }
    if (progress.isVip !== undefined) {
      this.isVip = progress.isVip;
    }
    if (progress.magnetLevel !== undefined) {
      this.magnetLevel = progress.magnetLevel;
    }
    if (progress.shieldCharges !== undefined) {
      this.extraShieldCharges = progress.shieldCharges;
    }
    if (progress.doubleCoinsPerma !== undefined) {
      this.doubleCoinsPerma = progress.doubleCoinsPerma;
    }
    if (progress.gliderWings !== undefined) {
      this.gliderWings = progress.gliderWings;
    }
    if (progress.iceBreaker !== undefined) {
      this.iceBreaker = progress.iceBreaker;
    }
    if (progress.alpineGrips !== undefined) {
      this.alpineGrips = progress.alpineGrips;
    }
    if (progress.diamondMiner !== undefined) {
      this.diamondMiner = progress.diamondMiner;
    }
    if (progress.forestCloak !== undefined) {
      this.forestCloak = progress.forestCloak;
    }
    if (progress.cosmicEngine !== undefined) {
      this.cosmicEngine = progress.cosmicEngine;
    }
    if (progress.luckyCharm !== undefined) {
      this.luckyCharm = progress.luckyCharm;
    }
    if (progress.doubleGemsPerma !== undefined) {
      this.doubleGemsPerma = progress.doubleGemsPerma;
    }
    if (progress.starlightThruster !== undefined) {
      this.starlightThruster = progress.starlightThruster;
    }
    if (progress.selectedAuraTrail) {
      this.selectedAuraTrail = progress.selectedAuraTrail;
    }
  }

  public setDifficulty(level: DifficultyLevel) {
    this.difficulty = level;
    if (this.track) {
      this.track.setDifficulty(level);
    }
  }

  public setGameMode(mode: GameModeId) {
    this.gameMode = mode;
  }

  public getDifficultySpeedMultiplier(): number {
    switch (this.difficulty) {
      case 'easy': return 0.85;
      case 'normal': return 1.0;
      case 'hard': return 1.25;
      case 'insane': return 1.5;
      case 'impossible': return 1.8;
      default: return 1.0;
    }
  }

  public getDifficultyScoreMultiplier(): number {
    switch (this.difficulty) {
      case 'easy': return 1.0;
      case 'normal': return 1.5;
      case 'hard': return 2.5;
      case 'insane': return 4.0;
      case 'impossible': return 6.5;
      default: return 1.5;
    }
  }

  public syncUpgrades(progress: Partial<PlayerProgress>) {
    if (progress.isVip !== undefined) this.isVip = !!progress.isVip;
    if (progress.selectedDifficulty) this.setDifficulty(progress.selectedDifficulty);
    if (progress.magnetLevel !== undefined) this.magnetLevel = progress.magnetLevel;
    if (progress.shieldCharges !== undefined) this.extraShieldCharges = progress.shieldCharges;
    if (progress.doubleCoinsPerma !== undefined) this.doubleCoinsPerma = !!progress.doubleCoinsPerma;
    if (progress.gliderWings !== undefined) this.gliderWings = !!progress.gliderWings;
    if (progress.nitroRechargeLevel !== undefined) this.nitroRechargeLevel = progress.nitroRechargeLevel;
    if (progress.iceBreaker !== undefined) this.iceBreaker = !!progress.iceBreaker;
    if (progress.alpineGrips !== undefined) this.alpineGrips = !!progress.alpineGrips;
    if (progress.diamondMiner !== undefined) this.diamondMiner = !!progress.diamondMiner;
    if (progress.forestCloak !== undefined) this.forestCloak = !!progress.forestCloak;
    if (progress.cosmicEngine !== undefined) this.cosmicEngine = !!progress.cosmicEngine;
    if (progress.luckyCharm !== undefined) this.luckyCharm = !!progress.luckyCharm;
    if (progress.doubleGemsPerma !== undefined) this.doubleGemsPerma = !!progress.doubleGemsPerma;
    if (progress.starlightThruster !== undefined) this.starlightThruster = !!progress.starlightThruster;
    if (progress.selectedAuraTrail !== undefined) this.selectedAuraTrail = progress.selectedAuraTrail;
  }

  public setVip(vip: boolean) {
    this.isVip = vip;
  }

  // Sacred Deer 3D Entity Creation & Animation for The Deep Forest Chase
  private spawnSacredDeer() {
    if (this.sacredDeerMesh) return;
    const deerGroup = new THREE.Group();
    deerGroup.name = 'sacred_deer';

    // Body (Graceful stag torso)
    const bodyGeo = new THREE.CapsuleGeometry(0.48, 1.4, 6, 10);
    bodyGeo.rotateX(Math.PI / 2);
    const deerMat = new THREE.MeshStandardMaterial({
      color: 0x15803d, // Emerald / forest gold
      emissive: 0x166534,
      emissiveIntensity: 0.6,
      roughness: 0.35,
      metalness: 0.2,
    });
    const body = new THREE.Mesh(bodyGeo, deerMat);
    body.position.y = 1.35;
    body.castShadow = true;
    deerGroup.add(body);

    // Neck & Head
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.35, 0.9, 8), deerMat);
    neck.position.set(0, 1.85, 0.65);
    neck.rotation.x = -0.4;
    deerGroup.add(neck);

    const head = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.35, 0.55), deerMat);
    head.position.set(0, 2.3, 0.95);
    deerGroup.add(head);

    // Glowing Antlers
    const antlerMat = new THREE.MeshBasicMaterial({ color: 0x4ade80 });
    const antlerGeo = new THREE.TorusGeometry(0.55, 0.06, 6, 12, Math.PI);
    const antler = new THREE.Mesh(antlerGeo, antlerMat);
    antler.position.set(0, 2.7, 0.85);
    antler.rotation.z = Math.PI;
    deerGroup.add(antler);

    // 4 Animated Galloping Legs
    const legGeo = new THREE.CylinderGeometry(0.09, 0.07, 1.2, 6);
    const legMat = new THREE.MeshStandardMaterial({ color: 0x14532d, roughness: 0.5 });

    const legFL = new THREE.Mesh(legGeo, legMat);
    legFL.name = 'leg_fl';
    legFL.position.set(-0.35, 0.6, 0.55);
    deerGroup.add(legFL);

    const legFR = new THREE.Mesh(legGeo, legMat);
    legFR.name = 'leg_fr';
    legFR.position.set(0.35, 0.6, 0.55);
    deerGroup.add(legFR);

    const legBL = new THREE.Mesh(legGeo, legMat);
    legBL.name = 'leg_bl';
    legBL.position.set(-0.35, 0.6, -0.55);
    deerGroup.add(legBL);

    const legBR = new THREE.Mesh(legGeo, legMat);
    legBR.name = 'leg_br';
    legBR.position.set(0.35, 0.6, -0.55);
    deerGroup.add(legBR);

    this.deerLight = new THREE.PointLight(0x4ade80, 2.5, 9.0);
    this.deerLight.position.set(0, 2.5, 0);
    deerGroup.add(this.deerLight);

    this.sacredDeerMesh = deerGroup;
    this.scene.add(deerGroup);
    this.isDeerChasing = true;
  }

  private updateSacredDeer(dt: number) {
    if (!this.sacredDeerMesh) return;
    const simTime = performance.now() * 0.001;

    // Gallop right behind the player with agile lateral weaving
    const targetX = this.playerPos.x + Math.sin(simTime * 2.5) * 1.5;
    const targetZ = this.playerPos.z - 2.4;
    const targetY = this.track.getTerrainHeight(targetX, targetZ);

    this.sacredDeerMesh.position.x = THREE.MathUtils.damp(this.sacredDeerMesh.position.x, targetX, 8, dt);
    this.sacredDeerMesh.position.z = THREE.MathUtils.damp(this.sacredDeerMesh.position.z, targetZ, 8, dt);
    this.sacredDeerMesh.position.y = targetY;

    // Deer catch collision: if deer reaches player, player gets caught!
    const dz = Math.abs(this.playerPos.z - this.sacredDeerMesh.position.z);
    const dx = Math.abs(this.playerPos.x - this.sacredDeerMesh.position.x);
    if (dz < 1.3 && dx < 1.3) {
      this.lives = 0;
      this.stats.lives = 0;
      this.triggerCrash('The Sacred Forest Deer caught you!');
      return;
    }

    // Galloping leg swinging animation
    const gallop = Math.sin(simTime * 14);
    const legFL = this.sacredDeerMesh.getObjectByName('leg_fl');
    const legFR = this.sacredDeerMesh.getObjectByName('leg_fr');
    const legBL = this.sacredDeerMesh.getObjectByName('leg_bl');
    const legBR = this.sacredDeerMesh.getObjectByName('leg_br');
    if (legFL) legFL.rotation.x = gallop * 0.55;
    if (legFR) legFR.rotation.x = -gallop * 0.55;
    if (legBL) legBL.rotation.x = -gallop * 0.55;
    if (legBR) legBR.rotation.x = gallop * 0.55;

    // Emit magical emerald forest hoof sparkles
    if (Math.random() < 0.4) {
      this.particles.emitSparkles(this.sacredDeerMesh.position, 0x4ade80, 5);
    }
  }

  private despawnSacredDeer() {
    if (this.sacredDeerMesh) {
      this.particles.emitSparkles(this.sacredDeerMesh.position, 0x4ade80, 45);
      this.scene.remove(this.sacredDeerMesh);
      this.sacredDeerMesh = null;
      this.isDeerChasing = false;
    }
  }

  private bindInputs() {
    window.addEventListener('keydown', (e) => {
      this.keysHeld[e.code] = true;
      if (e.key) this.keysHeld[e.key.toLowerCase()] = true;
      if (e.code === 'Space' || e.key === ' ') {
        this.jumpBuffered = true;
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keysHeld[e.code] = false;
      if (e.key) this.keysHeld[e.key.toLowerCase()] = false;
    });

    window.addEventListener('blur', () => {
      this.keysHeld = {};
    });
  }

  // Virtual Controls for Mobile / Touch
  public setVirtualSteer(val: number) {
    // -1 = full left, +1 = full right, 0 = neutral
    this.virtualSteer = val;
  }
  public triggerVirtualJump() {
    this.jumpBuffered = true;
  }
  public setVirtualBoost(active: boolean) {
    this.virtualBoost = active;
  }
  private virtualSteer = 0;
  private virtualBoost = false;

  private handleResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  public startGame(progress?: Partial<PlayerProgress>) {
    if (progress) {
      this.syncGear(progress);
    }
    this.status = 'playing';
    this.resetState();
    sound.startAtmosphericMusic();
  }

  public revivePlayer() {
    this.status = 'playing';
    this.lives = this.maxLives;
    this.stats.lives = this.lives;
    this.invulnerableTimer = 3.0; // 3s invulnerability frames after revive
    this.activePowerUps.set('shield', { duration: 4.5, maxDuration: 4.5 });
    this.forwardSpeed = 16;
    this.verticalSpeed = 0;
    this.lateralSpeed = 0;
    this.isAirborne = false;
    this.hitstopTimer = 0;
    this.cameraShake = 0.25;
    this.lastTime = performance.now();
    if (this.playerRig) {
      this.playerRig.root.visible = true;
    }

    // Clear obstacles in front of player so they have a clean runway
    const pZ = this.playerPos.z;
    for (const obs of this.track.obstacles) {
      if (obs.position.z >= pZ - 6 && obs.position.z <= pZ + 45) {
        obs.isActive = false;
        obs.mesh.visible = false;
      }
    }

    sound.playPowerUp();
    sound.playStarChime();
    this.particles.emitSparkles(this.playerPos, 0x38bdf8, 50);
    sound.startAtmosphericMusic();
    this.callbacks.onStatsUpdate(this.stats);
  }

  public pauseGame() {
    if (this.status === 'playing') {
      this.status = 'paused';
    }
  }

  public resumeGame() {
    if (this.status === 'paused') {
      this.status = 'playing';
      this.lastTime = performance.now();
    }
  }

  public setStatus(newStatus: GameStatus) {
    this.status = newStatus;
    if (newStatus === 'customize') {
      // Behind character is a vibrant, clear serene blue sky
      this.scene.background = new THREE.Color(0x38bdf8);
      if (this.scene.fog) {
        (this.scene.fog as THREE.FogExp2).color.set(0x7dd3fc);
      }
      this.resetState();
    } else if (newStatus === 'title' || newStatus === 'playing') {
      const defaultSky = this.mapTheme === 'beach' ? 0x67e8f9 : 0xa5d8ff;
      this.scene.background = new THREE.Color(defaultSky);
      if (this.scene.fog) {
        (this.scene.fog as THREE.FogExp2).color.set(defaultSky);
      }
      if (newStatus === 'title') {
        this.resetState();
      }
    }
  }

  private resetState() {
    const startY = this.track.getTerrainHeight(0, 0) + 0.05;
    this.playerPos.set(0, startY, 0);
    if (this.playerRig) {
      this.playerRig.root.rotation.set(0, 0, 0);
      this.playerRig.root.position.copy(this.playerPos);
    }
    this.camera.position.set(0, startY + 2.5, -5.8);
    this.camera.lookAt(0, startY + 0.3, 10.0);
    this.forwardSpeed = 8;
    this.lateralSpeed = 0;
    this.verticalSpeed = 0;
    this.carveAngle = 0;
    this.isAirborne = false;
    this.airtimeTimer = 0;
    this.airRotation = { pitch: 0, yaw: 0, roll: 0 };
    this.totalRotations = { pitch: 0, yaw: 0, roll: 0 };
    this.currentTrickName = null;
    this.activePowerUps.clear();
    this.boostEnergy = 100;
    this.isBoosting = false;
    this.cameraShake = 0;
    this.hitstopTimer = 0;

    if (this.characterDef.id === 'glacier_guardian') {
      this.armorCharges = 1;
    } else {
      this.armorCharges = 0;
    }

    this.had10Points = false;
    this.currentScoreZoneIndex = 0;
    this.track.setSubZone(0);

    // Strictly 1 Life in all modes! (No starter shield, instant crash on impact)
    this.maxLives = 1;
    this.lives = 1;
    this.invulnerableTimer = 0;
    this.activePowerUps.clear(); // NO starter shield!
    if (this.playerRig) {
      this.playerRig.root.visible = true;
    }

    // Reset game mode stats
    this.botRank = 1;
    this.packageIntegrity = 100;
    this.packagesDelivered = 0;
    this.timeRemaining = 35.0;
    this.slalomStreak = 0;

    let initialZone = 'Alpine Snow Mountain';
    if (this.mapTheme === 'beach') initialZone = 'Ocean Surf Rapids';
    else if (this.mapTheme === 'halloween') initialZone = 'Spooky Cemetery';
    else if (this.mapTheme === 'school') initialZone = 'School Hallway';
    else if (this.mapTheme === 'cyber') initialZone = 'Neon Cyber Highway';
    else if (this.mapTheme === 'spring') initialZone = 'Green Hills & Sakura Coast';
    else if (this.mapTheme === 'candy') initialZone = 'Pink Frosting Candy Highway';
    else if (this.mapTheme === 'forest') initialZone = 'Whispering Redwood Glade';
    else if (this.mapTheme === 'universe') initialZone = 'Earth Orbit & Lunar Base';
    else initialZone = this.mapTheme.toUpperCase().replace('_', ' ');

    this.stats = {
      distance: 0,
      speed: 0,
      topSpeed: 0,
      score: 0,
      multiplier: 1,
      coinsCollected: 0,
      gemsCollected: 0,
      gatesPassed: 0,
      tricksLanded: 0,
      airtimeTotal: 0,
      nearMisses: 0,
      isDoubleCoinsActive: false,
      currentZoneName: initialZone,
      zoneIndex: 0,
      lives: 1,
      maxLives: 1,
      mode: this.gameMode,
      botRank: 1,
      packageIntegrity: 100,
      packagesDelivered: 0,
      timeRemaining: 35.0,
      slalomStreak: 0,
    };

    this.track.reset();
    this.skiTracks.reset();
  }

  private lastTime = 0;

  private startLoop() {
    const tick = () => {
      if (this.isDestroyed) return;

      const now = performance.now();
      const rawDt = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const dt = Math.min(rawDt, 0.05); // clamp frame delta time

      if (this.status === 'playing') {
        this.updateSimulation(dt);
      } else if (this.status === 'title' || this.status === 'customize') {
        this.updatePreviewMode(dt);
      }

      this.renderer.render(this.scene, this.camera);
      this.animFrameId = requestAnimationFrame(tick);
    };

    this.animFrameId = requestAnimationFrame(tick);
  }

  // --- Title & Customizer Turntable Preview ---
  private previewTime = 0;
  private updatePreviewMode(dt: number) {
    this.previewTime += dt;
    if (this.playerRig) {
      if (this.status === 'customize') {
        // Character stays framed on the LEFT side of the screen as requested
        const charLeftX = -1.15;
        this.playerRig.root.position.set(charLeftX, 0, 0);
        this.playerRig.root.rotation.y = this.previewTime * 0.7;

        const camRadius = 3.2;
        this.camera.position.set(
          charLeftX + Math.sin(this.previewTime * 0.22) * camRadius,
          1.35,
          Math.cos(this.previewTime * 0.22) * camRadius
        );
        this.camera.lookAt(charLeftX, 0.75, 0);
      } else {
        // Title Screen: Epic cinematic live camera pan on peak
        this.playerRig.root.position.set(0, 0, 0);
        this.playerRig.root.rotation.y = 0.2;

        const camRadius = 5.5;
        this.camera.position.set(
          Math.sin(this.previewTime * 0.35) * camRadius,
          2.6 + Math.sin(this.previewTime * 0.5) * 0.6,
          Math.cos(this.previewTime * 0.35) * camRadius
        );
        this.camera.lookAt(0, 0.8, 0);
      }

      this.playerRig.animate(
        this.previewTime,
        15,
        0,
        false,
        { pitch: 0, yaw: 0, roll: 0 },
        false,
        false,
        false
      );
    }

    // Update dynamic weather & mountain vista in preview
    this.weather.update(dt, this.camera.position);
    this.particles.update(
      dt, 
      this.camera.position, 
      0, 
      false, 
      this.weather.currentConfig.windSpeed, 
      this.weather.currentConfig.snowDensity
    );
  }

  // --- 60fps Active Racing Simulation ---
  private updateSimulation(dt: number) {
    // Hitstop freeze for visceral impact feel
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    // Update invulnerability frames & visual flashing
    if (this.invulnerableTimer > 0) {
      this.invulnerableTimer = Math.max(0, this.invulnerableTimer - dt);
      if (this.playerRig) {
        // High-visibility arcade invulnerability flicker
        this.playerRig.root.visible = Math.floor(performance.now() / 70) % 2 === 0;
      }
    } else if (this.playerRig && !this.playerRig.root.visible) {
      this.playerRig.root.visible = true;
    }

    const simTime = performance.now() * 0.001;

    // 1. Process Active Power-Ups
    let isFrozen = false;
    let scoreMultiplier = 1;
    let hasShield = false;
    let hasMagnet = false;
    let hasStar = false;

    this.activePowerUps.forEach((pu, type) => {
      pu.duration -= dt;
      if (pu.duration <= 0) {
        this.activePowerUps.delete(type);
      } else {
        if (type === 'freeze') isFrozen = true;
        if (type === 'multiplier') scoreMultiplier = 2.5;
        if (type === 'shield') hasShield = true;
        if (type === 'magnet') hasMagnet = true;
        if (type === 'star') {
          hasStar = true;
          hasMagnet = true;
        }
      }
    });

    // Notify UI of active powerup states
    const activeList: ActivePowerUp[] = Array.from(this.activePowerUps.entries()).map(([t, p]) => ({
      type: t,
      duration: p.duration,
      maxDuration: p.maxDuration,
    }));
    this.callbacks.onPowerUpsUpdate(activeList);

    // 2. Input Handling (A = left, D = right, W = speed boost, Space = jump)
    const steerLeft = this.keysHeld['KeyA'] || this.keysHeld['a'] || this.keysHeld['ArrowLeft'] || this.virtualSteer < -0.2;
    const steerRight = this.keysHeld['KeyD'] || this.keysHeld['d'] || this.keysHeld['ArrowRight'] || this.virtualSteer > 0.2;
    const boostKey = this.keysHeld['ShiftLeft'] || this.keysHeld['KeyW'] || this.keysHeld['w'] || this.keysHeld['ArrowUp'] || this.virtualBoost;
    const jumpKey = this.keysHeld['Space'] || this.keysHeld[' '] || this.jumpBuffered;
    this.jumpBuffered = false;

    // Boost Logic
    this.isBoosting = false;
    if (boostKey && this.boostEnergy > 2) {
      this.isBoosting = true;
      this.boostEnergy = Math.max(0, this.boostEnergy - 22 * dt);
      sound.playBoost();
    } else {
      // Faster boost regen for high-action gameplay (amplified by nitroRechargeLevel and starlightThruster)
      const rechargeMult = (1 + (this.nitroRechargeLevel - 1) * 0.35) * (this.starlightThruster ? 2.0 : 1.0);
      this.boostEnergy = Math.min(100, this.boostEnergy + (this.characterDef.stats.boost * 3.2 * rechargeMult) * dt);
    }

    // Top Speed & Forward Acceleration (Holding W gives active speed push even if boost is recharging)
    const baseTopSpeed = 24 + this.characterDef.stats.speed * 2.4; // ~38 to 48 m/s (up to 170 km/h)
    const boostBonus = this.isBoosting ? 20 : (boostKey ? 9 : 0);
    const nitroBonus = this.activePowerUps.has('nitro') ? 22 : 0;
    const slipstreamBonus = this.characterDef.id === 'alpine_blitz' ? 4 : 0;
    const maxForward = (baseTopSpeed + boostBonus + nitroBonus + slipstreamBonus) * this.getDifficultySpeedMultiplier();

    const accelRate = (12 + this.characterDef.stats.speed * 1.5) * (boostKey ? 1.6 : 1.0);
    if (this.forwardSpeed < maxForward) {
      this.forwardSpeed += accelRate * dt;
    } else {
      this.forwardSpeed = THREE.MathUtils.damp(this.forwardSpeed, maxForward, 4, dt);
    }

    // 3. Lateral Steering & Carving (A steers Left, D steers Right; supports invert option & alpine grips)
    const handling = (1.0 + (this.characterDef.stats.carving - 5) * 0.12) * (this.alpineGrips ? 1.25 : 1.0);
    let targetCarve = 0;
    if (this.invertSteering) {
      if (steerLeft) targetCarve = -1.0;
      if (steerRight) targetCarve = 1.0;
      if (this.virtualSteer !== 0) targetCarve = this.virtualSteer;
    } else {
      if (steerLeft) targetCarve = 1.0;
      if (steerRight) targetCarve = -1.0;
      if (this.virtualSteer !== 0) targetCarve = -this.virtualSteer;
    }

    this.carveAngle = THREE.MathUtils.damp(this.carveAngle, targetCarve, 14 * handling, dt);
    this.lateralSpeed = this.carveAngle * (24 * handling);

    // 4. Ground Collision & Jump Mechanics (Tuned for snappy, controlled alpine airtime)
    const currentGroundY = this.track.getTerrainHeight(this.playerPos.x, this.playerPos.z);

    if (this.isAirborne) {
      this.airtimeTimer += dt;
      this.stats.airtimeTotal += dt;
      const effectiveGravity = this.gliderWings ? 24 : 33;
      this.verticalSpeed -= effectiveGravity * dt; // gravity
      this.playerPos.y += this.verticalSpeed * dt;

      // Air tricks rotation
      const rotSpeed = 4.2 * (this.characterDef.id === 'frost_maverick' ? 1.5 : 1.0);
      if (this.keysHeld['KeyA'] || this.keysHeld['ArrowLeft']) {
        this.airRotation.yaw += rotSpeed * dt;
        this.totalRotations.yaw += rotSpeed * dt;
      }
      if (this.keysHeld['KeyD'] || this.keysHeld['ArrowRight']) {
        this.airRotation.yaw -= rotSpeed * dt;
        this.totalRotations.yaw -= rotSpeed * dt;
      }
      if (this.keysHeld['KeyW'] || this.keysHeld['ArrowUp']) {
        this.airRotation.pitch += rotSpeed * dt;
        this.totalRotations.pitch += rotSpeed * dt;
      }
      if (this.keysHeld['KeyS'] || this.keysHeld['ArrowDown']) {
        this.airRotation.pitch -= rotSpeed * dt;
        this.totalRotations.pitch -= rotSpeed * dt;
      }

      // Check trick detection
      const totalTurns = Math.floor(Math.abs(this.totalRotations.yaw) / (Math.PI * 2));
      const totalFlips = Math.floor(Math.abs(this.totalRotations.pitch) / (Math.PI * 2));

      if (totalTurns > 0 || totalFlips > 0) {
        let trickTitle = '';
        if (totalFlips > 0) trickTitle = totalFlips === 1 ? 'Backflip' : 'Double Backflip';
        if (totalTurns > 0) {
          const deg = totalTurns * 360;
          trickTitle = trickTitle ? `${trickTitle} + ${deg}° Rodeo` : `${deg}° Spin`;
        }
        if (trickTitle !== this.currentTrickName) {
          this.currentTrickName = trickTitle;
          const trickPts = (totalTurns * 250 + totalFlips * 400) * (this.characterDef.id === 'frost_maverick' ? 2 : 1);
          sound.playTrick(this.stats.multiplier);
          this.callbacks.onTrick({
            name: trickTitle,
            points: trickPts,
            timestamp: Date.now(),
          });
          const vipScoreMult = this.isVip ? 2 : 1;
          const vipCoinMult = this.isVip ? 2 : 1;
          this.stats.score += trickPts * scoreMultiplier * vipScoreMult * this.getDifficultyScoreMultiplier();
          this.stats.multiplier = Math.min(10, this.stats.multiplier + 0.5);
          // Skill reward: Huge coin bonuses on stunts!
          const bonusCoins = (totalTurns * 15 + totalFlips * 25) * (this.activePowerUps.has('multiplier') ? 2 : 1) * vipCoinMult;
          this.stats.coinsCollected += bonusCoins;
          this.particles.emitSparkles(this.playerPos, 0xfbbf24, 15);
        }
      }

      // Touchdown Check
      if (this.playerPos.y <= currentGroundY) {
        this.playerPos.y = currentGroundY;
        this.isAirborne = false;
        sound.playLand(Math.min(1.5, Math.abs(this.verticalSpeed) / 12));

        // Landing angle check: pitch/yaw within ±45 deg of normal
        const pitchErr = Math.abs(this.airRotation.pitch % (Math.PI * 2));
        const isCleanLanding = pitchErr < 0.6 || pitchErr > (Math.PI * 2 - 0.6);

        if (isCleanLanding && this.airtimeTimer > 0.3) {
          this.stats.tricksLanded++;
          updateDailyChallengeProgress('tricks', 1, true);
          // Perfect landing boost & bonus coins!
          this.boostEnergy = Math.min(100, this.boostEnergy + 30);
          this.stats.coinsCollected += 10;
          this.particles.emitSparkles(this.playerPos, 0x38bdf8, 20);
        } else if (!isCleanLanding && this.airtimeTimer > 0.5) {
          // Hard wipeout on crooked landing!
          this.triggerCrash('Bad landing angle');
          return;
        }

        // Reset air state
        this.airRotation = { pitch: 0, yaw: 0, roll: 0 };
        this.totalRotations = { pitch: 0, yaw: 0, roll: 0 };
        this.currentTrickName = null;
        this.airtimeTimer = 0;
      }
    } else {
      // Grounded
      this.playerPos.y = currentGroundY;
      this.coyoteTimer = 0.15; // 150ms coyote time window

      // Launch off ramp or jump key - Tuned so user does not jump too high!
      let hitRamp = false;
      for (const ramp of this.track.ramps) {
        const dx = Math.abs(this.playerPos.x - ramp.position.x);
        const dz = this.playerPos.z - ramp.position.z;
        if (dx < ramp.width * 0.5 && dz >= 0 && dz < ramp.length) {
          hitRamp = true;
          this.verticalSpeed = 7.8 + this.characterDef.stats.airtime * 0.42;
          this.isAirborne = true;
          sound.playJump();
          this.particles.emitSnowSpray(this.playerPos, 1.0, this.forwardSpeed, 10);
          break;
        }
      }

      if (!hitRamp && jumpKey) {
        const jumpPower = 5.2 + this.characterDef.stats.airtime * 0.32;
        this.verticalSpeed = jumpPower;
        this.isAirborne = true;
        sound.playJump();
        this.particles.emitSnowSpray(this.playerPos, this.carveAngle, this.forwardSpeed, 6);
      }
    }

    // 5. Update Position (with weather wind deflection)
    const lateralWindPush = this.weather.currentConfig.windSpeed * 0.35;
    this.playerPos.x += (this.lateralSpeed + lateralWindPush) * dt;
    this.playerPos.z += this.forwardSpeed * dt;

    // Clamp lateral bounds so racer stays within mountain valley
    this.playerPos.x = THREE.MathUtils.clamp(this.playerPos.x, -21, 21);

    // 6. Update Character Mesh Position & Orientation
    if (this.playerRig) {
      this.playerRig.root.position.copy(this.playerPos);

      // Equippable Aura Particle Trails & Dynamic Glow
      if (this.selectedAuraTrail && this.selectedAuraTrail !== 'none') {
        this.particles.emitAuraTrail(this.playerPos, this.selectedAuraTrail, this.forwardSpeed, 4);

        if (!this.auraLight) {
          this.auraLight = new THREE.PointLight(0x38bdf8, 2.0, 7.0);
          this.scene.add(this.auraLight);
        }
        this.auraLight.visible = true;
        this.auraLight.position.set(this.playerPos.x, this.playerPos.y + 0.6, this.playerPos.z - 0.4);

        if (this.selectedAuraTrail === 'fire') this.auraLight.color.setHex(0xf97316);
        else if (this.selectedAuraTrail === 'neon') this.auraLight.color.setHex(0x06b6d4);
        else if (this.selectedAuraTrail === 'golden') this.auraLight.color.setHex(0xfacc15);
        else if (this.selectedAuraTrail === 'cosmic') this.auraLight.color.setHex(0xd946ef);
        else if (this.selectedAuraTrail === 'sakura') this.auraLight.color.setHex(0xf472b6);
        else if (this.selectedAuraTrail === 'ghost') this.auraLight.color.setHex(0x22c55e);
        else if (this.selectedAuraTrail === 'thunder') this.auraLight.color.setHex(0x38bdf8);
        else if (this.selectedAuraTrail === 'diamond') this.auraLight.color.setHex(0xe0f2fe);
        else if (this.selectedAuraTrail === 'candy') this.auraLight.color.setHex(0xf43f5e);
        else this.auraLight.color.setHex(0x38bdf8);
      } else if (this.auraLight) {
        this.auraLight.visible = false;
      }

      // Skis carve snow spray
      if (!this.isAirborne && (Math.abs(this.carveAngle) > 0.15 || this.isBoosting)) {
        this.particles.emitSnowSpray(
          this.playerPos,
          this.carveAngle,
          this.forwardSpeed,
          this.isBoosting ? 5 : 2
        );
      }

      const speedKmh = this.forwardSpeed * 3.6;
      this.playerRig.animate(
        simTime,
        speedKmh,
        this.carveAngle,
        this.isAirborne,
        this.airRotation,
        !this.isAirborne && this.forwardSpeed > 30,
        hasShield || this.armorCharges > 0,
        this.isBoosting || this.activePowerUps.has('nitro')
      );

      // Sound update
      sound.updateMotion(speedKmh, this.isAirborne, this.carveAngle, this.isBoosting);
    }

    // 7. Track & Collectibles Collision Detection
    this.checkCollisions(dt, scoreMultiplier, hasShield, hasMagnet);

    // 8. Update Dynamic Weather, Track Chunks, Ski Tracks & Storm Particles
    this.weather.update(dt, this.playerPos);
    this.track.update(dt, this.playerPos.z, isFrozen);

    // Realistic carved tracks in snow or white water wake in beach mode
    this.skiTracks.addTrackPoint(
      this.playerPos,
      this.carveAngle,
      this.isAirborne,
      this.mapTheme === 'beach' ? 'snowboard' : this.characterDef.vehicleType,
      currentGroundY
    );
    this.skiTracks.update(this.playerPos.z);

    this.particles.update(
      dt,
      this.playerPos,
      this.forwardSpeed * 3.6,
      this.isBoosting || this.activePowerUps.has('nitro'),
      this.weather.currentConfig.windSpeed,
      this.weather.currentConfig.snowDensity
    );

    // Notify UI of weather status
    this.callbacks.onWeatherUpdate({
      type: this.weather.currentConfig.type,
      name: this.weather.currentConfig.name,
      icon: this.weather.currentConfig.icon,
      frostVignette: this.weather.currentConfig.frostVignette,
      windSpeed: this.weather.currentConfig.windSpeed,
    });

    this.stats.distance = Math.floor(this.playerPos.z);
    this.stats.speed = Math.floor(this.forwardSpeed * 3.6);
    this.stats.topSpeed = Math.max(this.stats.topSpeed, this.stats.speed);
    const vipScoreMult = this.isVip ? 2 : 1;
    this.stats.score += Math.floor(this.forwardSpeed * dt * 2.5 * scoreMultiplier * this.stats.multiplier * vipScoreMult * this.getDifficultyScoreMultiplier());

    // Zone Transition Check: Every 10,000 score player enters a new place from that mode
    const targetZone = Math.floor(this.stats.score / 10000);
    if (targetZone !== this.currentScoreZoneIndex) {
      this.currentScoreZoneIndex = targetZone;
      const subZone = targetZone % 2;
      this.track.setSubZone(subZone);

      sound.playZoneTransition();
      this.particles.emitSparkles(this.playerPos, 0xfacc15, 60);

      let zoneTitle = '';
      if (this.mapTheme === 'beach') {
        zoneTitle = subZone === 1 ? '🏖️ SUNNY BEACH SHORELINE' : '🌊 OCEAN SURF RAPIDS';
      } else if (this.mapTheme === 'halloween') {
        zoneTitle = subZone === 1 ? '🏰 HAUNTED MANSION (WITCH CHASE!)' : '🪦 SPOOKY CEMETERY';
      } else if (this.mapTheme === 'school') {
        zoneTitle = subZone === 1 ? '📚 CLASSROOM DASH (TEACHER CHASE!)' : '🏫 SCHOOL HALLWAY';
      } else if (this.mapTheme === 'cyber') {
        zoneTitle = subZone === 1 ? '🕹️ NEO UNDERGROUND ARCADE' : '🏙️ NEON CYBER HIGHWAY';
      } else if (this.mapTheme === 'spring') {
        zoneTitle = subZone === 1 ? '🌸 SAKURA BLOOM TUNNEL & FESTIVAL' : '🌱 GREEN HILLS & SAKURA COAST';
      } else if (this.mapTheme === 'candy') {
        zoneTitle = subZone === 1 ? '🍭 GUMMY BEAR PALACE & CHOCOLATE FALLS' : '🍬 PINK FROSTING CANDY HIGHWAY';
      } else if (this.mapTheme === 'universe') {
        const universePlanets = [
          '🌍 PLANET 1: EARTH ORBIT & MOON BASE',
          '🔴 PLANET 2: MARS CRIMSON DUST DUNES',
          '🪐 PLANET 3: SATURN ICE RINGS & ASTEROIDS',
          '⚡ PLANET 4: JUPITER GREAT RED SPOT STORM',
          '💎 PLANET 5: NEPTUNE FROZEN CRYOSPHERE',
          '✨ PLANET 6: CYBER NEBULA & STARDUST NURSERY',
          '☀️ PLANET 7: SOLAR CORONA SUPERNOVA PEAKS',
          '🕳️ PLANET 8: EVENT HORIZON & SINGULARITY',
        ];
        zoneTitle = universePlanets[targetZone % universePlanets.length];
        const planetSkies = [0x050212, 0x220808, 0x1a1205, 0x250e04, 0x031424, 0x1f0729, 0x2a1a00, 0x130225];
        const skyCol = planetSkies[targetZone % planetSkies.length];
        this.scene.background = new THREE.Color(skyCol);
        if (this.scene.fog) (this.scene.fog as THREE.FogExp2).color.set(skyCol);
      } else if (this.mapTheme === 'forest') {
        zoneTitle = subZone === 1 ? '🦌 SACRED REDWOOD GLADE (THE DEER IS CHASING YOU!)' : '🌲 ANCIENT MOSS PINE CANOPY';
      } else {
        zoneTitle = subZone === 1 ? '🏡 COZY WOODEN CHALET LODGE' : '🏔️ ALPINE SNOW MOUNTAIN';
      }

      this.callbacks.onTrick({
        name: `ENTERING ${zoneTitle}!`,
        points: 1000,
        timestamp: Date.now(),
      });
      this.stats.score += 1000;
    }

    const currentSub = this.currentScoreZoneIndex % 2;
    this.stats.zoneIndex = this.currentScoreZoneIndex;
    if (this.mapTheme === 'beach') {
      this.stats.currentZoneName = currentSub === 1 ? 'Sunny Beach Shoreline' : 'Ocean Surf Rapids';
    } else if (this.mapTheme === 'halloween') {
      this.stats.currentZoneName = currentSub === 1 ? 'Haunted Mansion' : 'Spooky Cemetery';
    } else if (this.mapTheme === 'school') {
      this.stats.currentZoneName = currentSub === 1 ? 'Classroom Dash' : 'School Hallway';
    } else if (this.mapTheme === 'cyber') {
      this.stats.currentZoneName = currentSub === 1 ? 'Neo Underground Arcade' : 'Neon Cyber Highway';
    } else if (this.mapTheme === 'spring') {
      this.stats.currentZoneName = currentSub === 1 ? 'Sakura Bloom Tunnel & Festival' : 'Green Hills & Sakura Coast';
    } else if (this.mapTheme === 'candy') {
      this.stats.currentZoneName = currentSub === 1 ? 'Gummy Bear Palace' : 'Pink Frosting Candy Highway';
    } else if (this.mapTheme === 'universe') {
      const planetNames = [
        'Earth Orbit & Moon Base',
        'Mars Crimson Dust Dunes',
        'Saturn Rings & Asteroid Belt',
        'Jupiter Great Red Spot',
        'Neptune Frozen Cryosphere',
        'Cyber Nebula & Stardust',
        'Solar Corona Supernova',
        'Black Hole Event Horizon',
      ];
      this.stats.currentZoneName = planetNames[this.currentScoreZoneIndex % planetNames.length];
    } else if (this.mapTheme === 'forest') {
      this.stats.currentZoneName = currentSub === 1 ? 'Sacred Redwood Glade (Deer Run)' : 'Ancient Moss Pine Trails';
    } else if (this.mapTheme === 'dinner_time') {
      this.stats.currentZoneName = currentSub === 1 ? 'Dessert Platter & Cutlery Alley' : 'Banquet Tablecloth Highway';
    } else {
      this.stats.currentZoneName = currentSub === 1 ? 'Wooden Chalet Lodge' : 'Alpine Snow Mountain';
    }

    // Dynamic Shadow Tracking: The sunlight smoothly moves with player for realistic real-time shadows
    if (this.sunLight) {
      this.sunLight.position.set(this.playerPos.x + 22, this.playerPos.y + 38, this.playerPos.z - 12);
      this.sunLight.target.position.set(this.playerPos.x, this.playerPos.y, this.playerPos.z + 10);
      this.sunLight.target.updateMatrixWorld();
    }

    // Dynamic Pursuer Chase Animations
    if (this.mapTheme === 'forest') {
      this.forestDeerTimer += dt;
      // Periodic Sacred Deer chase: in the deep forest map, deer periodically tries to catch the player!
      const isDeerPeriod = (this.forestDeerTimer % 30) > 16 || currentSub === 1;
      if (isDeerPeriod) {
        if (!this.sacredDeerMesh) {
          this.spawnSacredDeer();
        }
        this.isDeerChasing = true;
        if (this.sacredDeerMesh) {
          this.sacredDeerMesh.visible = true;
          this.updateSacredDeer(dt);
        }
      } else if (this.sacredDeerMesh) {
        this.despawnSacredDeer();
      }
    } else if (this.sacredDeerMesh) {
      this.despawnSacredDeer();
    }
    if (this.mapTheme === 'halloween' && currentSub === 1) {
      // Witch pursuing behind player on flying broomstick!
      if (!this.witchPursuer) {
        this.witchPursuer = this.createWitchMesh();
        this.scene.add(this.witchPursuer);
      }
      this.witchPursuer.visible = true;
      const targetZ = this.playerPos.z - 4.2;
      const targetX = THREE.MathUtils.lerp(this.witchPursuer.position.x, this.playerPos.x + Math.sin(simTime * 2.5) * 1.6, 0.08);
      const targetY = this.playerPos.y + 1.6 + Math.sin(simTime * 3.5) * 0.35;
      this.witchPursuer.position.set(targetX, targetY, targetZ);
      this.witchPursuer.rotation.z = Math.sin(simTime * 3.0) * 0.15;
      this.particles.emitSparkles(this.witchPursuer.position, 0xa855f7, 2);
    } else if (this.witchPursuer) {
      this.witchPursuer.visible = false;
    }

    if (this.mapTheme === 'school' && currentSub === 1) {
      // Strict Teacher chasing player with ruler in classroom!
      if (!this.teacherPursuer) {
        this.teacherPursuer = this.createTeacherMesh();
        this.scene.add(this.teacherPursuer);
      }
      this.teacherPursuer.visible = true;
      const targetZ = this.playerPos.z - 3.8;
      const targetX = THREE.MathUtils.lerp(this.teacherPursuer.position.x, this.playerPos.x, 0.08);
      const targetY = this.track.getTerrainHeight(targetX, targetZ);
      this.teacherPursuer.position.set(targetX, targetY, targetZ);
      this.particles.emitSparkles(this.teacherPursuer.position, 0xf8fafc, 2);
    } else if (this.teacherPursuer) {
      this.teacherPursuer.visible = false;
    }

    // Double Coins activation check (user requested: I WILL GET DOUBLE COINS WHEN I HIT 10 POINTS)
    if (this.stats.score >= 10) {
      if (!this.had10Points) {
        this.had10Points = true;
        sound.playDoubleCoins();
        this.particles.emitSparkles(this.playerPos, 0xfacc15, 30);
      }
      this.stats.isDoubleCoinsActive = true;
    } else {
      this.stats.isDoubleCoinsActive = false;
    }

    this.stats.lives = 1;
    this.stats.maxLives = 1;

    updateDailyChallengeProgress('distance', this.stats.distance, false);
    updateDailyChallengeProgress('score', this.stats.score, false);

    this.callbacks.onStatsUpdate(this.stats);

    // 10. Normal Static Chase Camera (Rock-solid, upright, centered directly behind the player)
    this.camera.position.x = this.playerPos.x;
    this.camera.position.y = this.playerPos.y + 2.5;
    this.camera.position.z = this.playerPos.z - 5.8;

    this.camera.up.set(0, 1, 0);
    const lookTarget = _vec3A.set(
      this.playerPos.x,
      this.playerPos.y + 0.35,
      this.playerPos.z + 10.0
    );
    this.camera.lookAt(lookTarget);
    this.camera.fov = 60;
    this.camera.updateProjectionMatrix();
  }

  // --- Collision Detection ---
  private checkCollisions(
    dt: number,
    scoreMultiplier: number,
    hasShield: boolean,
    hasMagnet: boolean
  ) {
    const pX = this.playerPos.x;
    const pY = this.playerPos.y;
    const pZ = this.playerPos.z;

    // 1. Collectibles (Shining Star Super Magnet & Coin Farming)
    const hasStar = this.activePowerUps.has('star');
    const baseMagnetRange = 9.0 + (this.magnetLevel - 1) * 7.0;
    // When Magnet or Shining Star is active: Coins accelerate towards player
    const magnetRadius = hasStar ? 250.0 : (hasMagnet ? 55.0 : baseMagnetRange);
    const suctionSpeed = hasStar ? 38.0 : (hasMagnet ? 28.0 : 18.0);
    const scoreDoubleBonus = this.stats.score >= 10 ? 2 : 1;
    const vipCoinMult = this.isVip ? 2 : 1;
    const permaCoinMult = this.doubleCoinsPerma ? 2 : 1;
    const coinMultiplier = (this.activePowerUps.has('multiplier') ? 2 : 1) * 
      (this.characterDef.id === 'frost_maverick' ? 2 : 1) * 
      scoreDoubleBonus * 
      vipCoinMult *
      permaCoinMult;

    if (hasStar && Math.random() < 0.25) {
      this.particles.emitSparkles(this.playerPos, 0xfde047, 4);
    }

    const collectibles = this.track.collectibles;
    const colCount = collectibles.length;
    for (let i = 0; i < colCount; i++) {
      const col = collectibles[i];
      if (col.isCollected) continue;

      const dz = pZ - col.position.z;
      // Fast bounding box reject: if Z distance alone exceeds magnet radius, skip
      if (Math.abs(dz) > magnetRadius) continue;

      const dx = pX - col.position.x;
      const dy = pY - col.position.y;
      const distSq = dx * dx + dy * dy + dz * dz;
      const magnetRadiusSq = magnetRadius * magnetRadius;

      // Vacuum suction pull effect directly into player (every coin comes to you when star active!)
      if (distSq < magnetRadiusSq) {
        col.position.x += (pX - col.position.x) * suctionSpeed * dt;
        col.position.y += (pY - col.position.y) * suctionSpeed * dt;
        col.position.z += (pZ - col.position.z) * suctionSpeed * dt;
      }

      const touchRadius = col.radius + 1.8;
      if (distSq < touchRadius * touchRadius) {
        col.isCollected = true;
        col.mesh.visible = false;

        if (col.type === 'coin') {
          sound.playCoin();
          const earned = 1 * coinMultiplier;
          this.stats.coinsCollected += earned;
          this.stats.score += 50 * scoreMultiplier;
          this.particles.emitSparkles(col.position, hasStar ? 0xfef08a : 0xfbbf24, 12);
          updateDailyChallengeProgress('coins', earned, true);
        } else if (col.type === 'gem') {
          sound.playGem();
          this.stats.gemsCollected++;
          const gemCoins = 5 * coinMultiplier;
          this.stats.coinsCollected += gemCoins; // Gems grant bonus coins directly!
          this.stats.score += 300 * scoreMultiplier;
          this.particles.emitSparkles(col.position, 0x06b6d4, 20);
          updateDailyChallengeProgress('coins', gemCoins, true);
        } else if (col.type === 'powerup' && col.powerUpType) {
          if (col.powerUpType === 'star') {
            sound.playStarChime();
            const duration = 12;
            this.activePowerUps.set('star', { duration, maxDuration: duration });
            this.stats.coinsCollected += (10 * coinMultiplier);
            this.particles.emitSparkles(col.position, 0xfde047, 45);
            updateDailyChallengeProgress('star', 1, true);
          } else {
            sound.playPowerUp();
            const duration = col.powerUpType === 'freeze' ? 7 : 10;
            this.activePowerUps.set(col.powerUpType, { duration, maxDuration: duration });
            this.stats.coinsCollected += (3 * coinMultiplier);
            this.particles.emitSparkles(col.position, 0xec4899, 25);
          }
        }
      }
    }

    // 2. Obstacles (Trees, Rocks, Snowmen, Slalom Gates, Dynamic Hazards)
    for (const obs of this.track.obstacles) {
      if (!obs.isActive) continue;

      const dx = Math.abs(pX - obs.position.x);
      const dz = pZ - obs.position.z;
      const dy = Math.abs(pY - obs.position.y);

      // A. Slalom Gates Check (Awards bonus coins + boost!)
      if (obs.type === 'slalom_gate') {
        if (!obs.dynamic?.isPassed && Math.abs(dz) < 1.2 && dx < 2.5 && dy < 3.2) {
          obs.dynamic!.isPassed = true;
          sound.playGate();
          this.stats.gatesPassed++;
          this.slalomStreak++;
          this.stats.slalomStreak = this.slalomStreak;
          if (this.gameMode === 'time_attack') {
            this.timeRemaining = Math.min(60, this.timeRemaining + 5.0);
            this.stats.timeRemaining = this.timeRemaining;
          }
          updateDailyChallengeProgress('gates', 1, true);
          const bonusCoins = (this.gameMode === 'coin_rush' ? 45 : 15) * scoreDoubleBonus;
          this.stats.coinsCollected += bonusCoins;
          const gateBaseScore = this.gameMode === 'slalom_gp' ? 300 : 150;
          this.stats.score += gateBaseScore * scoreMultiplier * (1 + Math.min(10, this.slalomStreak) * 0.1);
          this.stats.multiplier = Math.min(10, this.stats.multiplier + 0.5);
          this.boostEnergy = Math.min(100, this.boostEnergy + 25);
          this.callbacks.onGatePassed();
          this.particles.emitSparkles(obs.position, 0x0284c7, 16);
        }
        continue;
      }

      // B. Thin Ice Patch (low friction drift)
      if (obs.type === 'thin_ice') {
        if (dx < (obs.collider.halfWidth || 3.0) && Math.abs(dz) < (obs.collider.halfLength || 4.0)) {
          // Steer carve reduced friction
          this.lateralSpeed *= 1.08;
          this.particles.emitSnowSpray(this.playerPos, 0.8, this.forwardSpeed, 4);
        }
        continue;
      }

      // C. Near-Miss Detection (giving adrenaline points and bonus coins!)
      const dangerDist = Math.sqrt(dx * dx + dz * dz);
      if (dangerDist > obs.collider.radius && dangerDist < obs.collider.radius + 1.8 && Math.abs(dz) < 1.5) {
        if (!obs.dynamic?.hasTriggered) {
          obs.dynamic = { ...(obs.dynamic || {}), hasTriggered: true };
          this.stats.nearMisses++;
          this.stats.coinsCollected += 5; // +5 bonus coins on close brush!
          this.stats.score += 100 * scoreMultiplier;
          if (this.characterDef.id === 'vortex_valkyrie') {
            this.boostEnergy = Math.min(100, this.boostEnergy + 15);
          }
          this.callbacks.onNearMiss();
        }
      }

      // D. Direct Collision
      const hitRadius = obs.collider.radius || 1.1;
      const hitHeight = obs.collider.height || 4.2;
      const maxZStep = Math.max(1.6, this.forwardSpeed * dt * 0.95);
      const isHit = dx < hitRadius && Math.abs(dz) < maxZStep && dy < hitHeight;

      if (isHit) {
        // If invulnerable from recent hit, skip collision damage
        if (this.invulnerableTimer > 0) {
          continue;
        }
        // Can Yeti smash small rocks?
        if (this.characterDef.id === 'yeti_rider' && obs.type === 'rock') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playCrash();
          this.particles.emitExplosion(obs.position, 30);
          this.stats.coinsCollected += 20;
          this.stats.score += 500;
          this.cameraShake = 0.4;
          continue;
        }

        // Snowmen explode delightfully and reward coins!
        if (obs.type === 'snowman') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.8);
          this.particles.emitExplosion(obs.position, 35);
          this.stats.coinsCollected += 20;
          this.stats.score += 200;
          this.cameraShake = 0.25;
          continue;
        }

        // Smashable furniture chair or beach cooler box!
        if (obs.type === 'furniture_chair' || obs.type === 'beach_cooler') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.8);
          this.particles.emitExplosion(obs.position, 35);
          this.stats.coinsCollected += 30;
          this.stats.score += 300 * scoreMultiplier;
          this.cameraShake = 0.25;
          continue;
        }

        // Carved glowing pumpkins explode into pumpkin chunks!
        if (obs.type === 'pumpkin') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.8);
          this.particles.emitExplosion(obs.position, 35);
          this.stats.coinsCollected += 35;
          this.stats.score += 350 * scoreMultiplier;
          this.cameraShake = 0.25;
          continue;
        }

        // Wet floor hazard cones & backpacks kick aside!
        if (obs.type === 'wet_floor_cone' || obs.type === 'backpack') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.4);
          this.particles.emitExplosion(obs.position, 25);
          this.stats.coinsCollected += 25;
          this.stats.score += 250 * scoreMultiplier;
          this.cameraShake = 0.2;
          continue;
        }

        // Janitor mop buckets & trash bins (smashable!)
        if (obs.type === 'mop_bucket' || obs.type === 'trash_bin') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.5);
          this.particles.emitExplosion(obs.position, 30);
          this.stats.coinsCollected += 30;
          this.stats.score += 300 * scoreMultiplier;
          this.cameraShake = 0.2;
          continue;
        }

        // Cyber neon cones (smashable neon spark burst!)
        if (obs.type === 'neon_cone') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playGate();
          this.particles.emitSparkles(obs.position, 0xec4899, 35);
          this.stats.coinsCollected += 40;
          this.stats.score += 400 * scoreMultiplier;
          this.cameraShake = 0.15;
          continue;
        }

        // Gym hurdles (can be leaped over when airborne)
        if (obs.type === 'gym_hurdle' && this.isAirborne && this.playerPos.y > obs.position.y + 0.8) {
          this.stats.coinsCollected += 35;
          this.stats.score += 350 * scoreMultiplier;
          sound.playGate();
          this.particles.emitSparkles(this.playerPos, 0x38bdf8, 12);
          continue;
        }

        // Grind on fallen log rail
        if (obs.type === 'log_rail') {
          if (this.isAirborne && this.verticalSpeed <= 0) {
            // Rail grind success!
            this.isAirborne = false;
            this.playerPos.y = obs.position.y + 0.35;
            this.stats.coinsCollected += 25;
            this.stats.score += 350 * scoreMultiplier;
            this.particles.emitSparkles(this.playerPos, 0xffffff, 8);
            continue;
          }
        }

        // Nitro blast through obstacle
        if (this.activePowerUps.has('nitro')) {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playCrash();
          this.particles.emitExplosion(obs.position, 40);
          this.cameraShake = 0.5;
          continue;
        }

        // Forest mushrooms kick aside with bonus points!
        if (obs.type === 'forest_mushroom') {
          obs.isActive = false;
          obs.mesh.visible = false;
          sound.playLand(1.4);
          this.particles.emitSparkles(obs.position, 0x4ade80, 25);
          this.stats.coinsCollected += 30;
          this.stats.score += 300 * scoreMultiplier;
          this.cameraShake = 0.2;
          continue;
        }

        // STRICTLY 1 LIFE: Any obstacle collision is INSTANT WIPEOUT for EVERY character!
        // No shields, no 4-hit survival, no armor charges! First touch = immediate death!
        this.lives = 0;
        this.stats.lives = 0;
        this.triggerCrash(`Hit ${obs.type}`);
        return;
      }
    }
  }

  private triggerCrash(reason: string) {
    this.status = 'gameover';
    this.hitstopTimer = 0.08; // 80ms hitstop
    this.cameraShake = 0.8;
    sound.playCrash();
    sound.stopAtmosphericMusic();

    this.particles.emitExplosion(this.playerPos, 60);

    // Call game over
    this.callbacks.onGameOver(this.stats);
  }

  public cycleWeather() {
    this.weather.nextWeather();
  }

  public setWeather(type: WeatherType) {
    this.weather.setWeather(type);
  }

  private createWitchMesh(): THREE.Group {
    const group = new THREE.Group();
    // Flying broomstick shaft
    const broomShaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.08, 3.2, 6),
      new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 })
    );
    broomShaft.rotation.x = Math.PI / 2;
    group.add(broomShaft);

    // Straw broom bristles
    const bristles = new THREE.Mesh(
      new THREE.ConeGeometry(0.32, 0.9, 6),
      new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.9 })
    );
    bristles.rotation.x = -Math.PI / 2;
    bristles.position.set(0, 0, -1.6);
    group.add(bristles);

    // Witch body & robes (purple & black)
    const robes = new THREE.Mesh(
      new THREE.ConeGeometry(0.55, 1.4, 8),
      new THREE.MeshStandardMaterial({ color: 0x3b0764, roughness: 0.6 })
    );
    robes.position.set(0, 0.7, -0.1);
    group.add(robes);

    // Witch head
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0x86efac, roughness: 0.8 }) // Spooky green skin
    );
    head.position.set(0, 1.45, 0);
    group.add(head);

    // Witch hat (brim + cone)
    const brim = new THREE.Mesh(
      new THREE.CylinderGeometry(0.7, 0.7, 0.05, 12),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 })
    );
    brim.position.set(0, 1.6, 0);
    group.add(brim);

    const hatCone = new THREE.Mesh(
      new THREE.ConeGeometry(0.35, 1.0, 8),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 })
    );
    hatCone.position.set(0, 2.05, 0.05);
    hatCone.rotation.x = -0.2;
    group.add(hatCone);

    // Glowing purple magic aura
    const aura = new THREE.Mesh(
      new THREE.SphereGeometry(0.85, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xa855f7, transparent: true, opacity: 0.25, wireframe: true })
    );
    aura.position.set(0, 1.0, 0);
    group.add(aura);

    return group;
  }

  private createTeacherMesh(): THREE.Group {
    const group = new THREE.Group();
    // Body / Tweed Blazer
    const body = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 1.2, 0.45),
      new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.8 })
    );
    body.position.y = 1.2;
    group.add(body);

    // Head
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.28, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0xfde047, roughness: 0.6 })
    );
    head.position.y = 1.95;
    group.add(head);

    // Spectacles / Glasses
    const glasses = new THREE.Mesh(
      new THREE.BoxGeometry(0.35, 0.08, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.8 })
    );
    glasses.position.set(0, 1.98, 0.28);
    group.add(glasses);

    // Long Pointer Ruler held high
    const ruler = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 1.2, 0.03),
      new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 })
    );
    ruler.position.set(0.65, 1.7, 0.4);
    ruler.rotation.x = 0.5;
    group.add(ruler);

    // Hall Pass Clipboard held in left hand
    const clipboard = new THREE.Mesh(
      new THREE.BoxGeometry(0.35, 0.5, 0.04),
      new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 })
    );
    clipboard.position.set(-0.55, 1.2, 0.3);
    group.add(clipboard);

    // Legs
    const legMat = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.7 });
    const legL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.9, 6), legMat);
    legL.position.set(-0.2, 0.45, 0);
    group.add(legL);
    const legR = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.9, 6), legMat);
    legR.position.set(0.2, 0.45, 0);
    group.add(legR);

    return group;
  }

  public getMapTheme(): MapTheme {
    return this.mapTheme;
  }


  public dispose() {
    this.isDestroyed = true;
    window.removeEventListener('resize', this.handleResize);
    cancelAnimationFrame(this.animFrameId);
    clearTimeout(this.animFrameId);

    sound.stopAtmosphericMusic();

    if (this.playerRig) this.playerRig.dispose();
    if (this.auraLight) this.scene.remove(this.auraLight);
    if (this.witchPursuer) this.scene.remove(this.witchPursuer);
    if (this.teacherPursuer) this.scene.remove(this.teacherPursuer);
    this.skiTracks.dispose();
    this.weather.dispose();
    this.track.dispose();
    this.particles.dispose();
    if (this.renderer) {
      try {
        const gl = this.renderer.getContext();
        const loseCtx = gl?.getExtension('WEBGL_lose_context');
        if (loseCtx) {
          loseCtx.loseContext();
        }
      } catch (e) {
        console.warn('Error releasing WebGL context:', e);
      }
      if (this.renderer.domElement && this.renderer.domElement.parentNode) {
        this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
      }
      this.renderer.dispose();
    }
  }
}
