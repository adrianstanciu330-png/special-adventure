import * as THREE from 'three';
import { VehicleType, MapTheme } from '../types/game';

const MAX_POINTS = 300;

export class SkiTracksSystem {
  public root: THREE.Group;
  private trackMesh: THREE.Mesh;
  private geometry: THREE.BufferGeometry;
  private positions: Float32Array;
  private opacities: Float32Array;
  private pointCount = 0;
  private lastRecordedZ = -999;
  private material: THREE.MeshStandardMaterial;

  constructor() {
    this.root = new THREE.Group();
    this.root.name = 'ski_tracks_system';

    // 2 triangles (4 vertices) per segment for left trail + right trail
    // Total vertices = MAX_POINTS * 8
    this.positions = new Float32Array(MAX_POINTS * 8 * 3);
    this.opacities = new Float32Array(MAX_POINTS * 8);

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.geometry.setAttribute('alpha', new THREE.BufferAttribute(this.opacities, 1));

    // Realistic packed carved snow groove material
    this.material = new THREE.MeshStandardMaterial({
      color: 0x94a3b8, // Packed ice shadow tone
      roughness: 0.6,
      metalness: 0.25,
      transparent: true,
      opacity: 0.75,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -2,
      polygonOffsetUnits: -2,
      side: THREE.DoubleSide,
    });

    // Custom shader injection for fading out distance
    this.material.onBeforeCompile = (shader) => {
      shader.vertexShader = `
        attribute float alpha;
        varying float vAlpha;
        ${shader.vertexShader}
      `.replace(
        '#include <begin_vertex>',
        `
        #include <begin_vertex>
        vAlpha = alpha;
        `
      );

      shader.fragmentShader = `
        varying float vAlpha;
        ${shader.fragmentShader}
      `.replace(
        '#include <dithering_fragment>',
        `
        #include <dithering_fragment>
        gl_FragColor.a *= vAlpha;
        `
      );
    };

    // Indices for quads
    const indices: number[] = [];
    for (let i = 0; i < MAX_POINTS - 1; i++) {
      const b = i * 8;
      // Left ski / side track quad
      indices.push(b, b + 1, b + 8);
      indices.push(b + 1, b + 9, b + 8);
      // Right ski / side track quad
      indices.push(b + 2, b + 3, b + 10);
      indices.push(b + 3, b + 11, b + 10);
    }
    this.geometry.setIndex(indices);

    this.trackMesh = new THREE.Mesh(this.geometry, this.material);
    this.trackMesh.frustumCulled = false;
    this.trackMesh.receiveShadow = true;
    this.root.add(this.trackMesh);
  }

  /**
   * Records athlete's contact points on snow to lay down realistic carving tracks
   */
  public addTrackPoint(
    playerPos: THREE.Vector3,
    carveAngle: number,
    isAirborne: boolean,
    vehicleType: VehicleType,
    terrainHeight: number
  ) {
    if (isAirborne) return;

    // Record point every ~0.8m of forward motion
    if (playerPos.z - this.lastRecordedZ < 0.7) return;
    this.lastRecordedZ = playerPos.z;

    const idx = (this.pointCount % MAX_POINTS) * 8;
    const p3 = idx * 3;

    const y = terrainHeight + 0.025;
    const isSkis = vehicleType === 'skis';

    // Width and spacing
    const trackWidth = isSkis ? 0.09 : 0.28;
    const spacing = isSkis ? 0.16 : 0.0;

    // Normal to movement direction
    const cosA = Math.cos(carveAngle * 0.4);
    const sinA = Math.sin(carveAngle * 0.4);

    if (isSkis) {
      // Left ski track (inner/outer edge)
      const lx = playerPos.x - spacing * cosA;
      const lz = playerPos.z + spacing * sinA;
      this.positions[p3] = lx - trackWidth * cosA;
      this.positions[p3 + 1] = y;
      this.positions[p3 + 2] = lz + trackWidth * sinA;

      this.positions[p3 + 3] = lx + trackWidth * cosA;
      this.positions[p3 + 4] = y;
      this.positions[p3 + 5] = lz - trackWidth * sinA;

      // Right ski track (inner/outer edge)
      const rx = playerPos.x + spacing * cosA;
      const rz = playerPos.z - spacing * sinA;
      this.positions[p3 + 6] = rx - trackWidth * cosA;
      this.positions[p3 + 7] = y;
      this.positions[p3 + 8] = rz + trackWidth * sinA;

      this.positions[p3 + 9] = rx + trackWidth * cosA;
      this.positions[p3 + 10] = y;
      this.positions[p3 + 11] = rz - trackWidth * sinA;
    } else {
      // Snowboard single carved swath
      const cx = playerPos.x;
      const cz = playerPos.z;
      this.positions[p3] = cx - trackWidth * cosA;
      this.positions[p3 + 1] = y;
      this.positions[p3 + 2] = cz + trackWidth * sinA;

      this.positions[p3 + 3] = cx;
      this.positions[p3 + 4] = y;
      this.positions[p3 + 5] = cz;

      this.positions[p3 + 6] = cx;
      this.positions[p3 + 7] = y;
      this.positions[p3 + 8] = cz;

      this.positions[p3 + 9] = cx + trackWidth * cosA;
      this.positions[p3 + 10] = y;
      this.positions[p3 + 11] = cz - trackWidth * sinA;
    }

    // Carve opacity: deeper when turning hard
    const carveAlpha = 0.55 + Math.min(0.45, Math.abs(carveAngle) * 0.6);
    for (let k = 0; k < 8; k++) {
      this.opacities[idx + k] = carveAlpha;
    }

    this.pointCount++;
    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.attributes.alpha.needsUpdate = true;
  }

  /**
   * Fade out distant track points behind the player
   */
  public update(playerZ: number) {
    let dirty = false;
    for (let i = 0; i < MAX_POINTS; i++) {
      const pZ = this.positions[i * 8 * 3 + 2];
      const dist = playerZ - pZ;
      if (dist > 0 && dist < 120) {
        // Fade out as it gets further behind
        const targetAlpha = Math.max(0, 1.0 - dist / 110);
        if (Math.abs(this.opacities[i * 8] - targetAlpha) > 0.05) {
          for (let k = 0; k < 8; k++) {
            this.opacities[i * 8 + k] = targetAlpha;
          }
          dirty = true;
        }
      }
    }
    if (dirty) {
      this.geometry.attributes.alpha.needsUpdate = true;
    }
  }

  public setTheme(theme: MapTheme) {
    if (theme === 'beach') {
      this.material.color.set(0xffffff); // Foaming white water wake behind surfboard
      this.material.opacity = 0.92;
    } else if (theme === 'halloween') {
      this.material.color.set(0x6b21a8); // Ghostly violet trail behind witch broom / deck
      this.material.opacity = 0.8;
    } else if (theme === 'school') {
      this.material.color.set(0x93c5fd); // Polished linoleum skid marks
      this.material.opacity = 0.7;
    } else if (theme === 'cyber') {
      this.material.color.set(0x06b6d4); // Neon cyan laser light trail
      this.material.opacity = 0.9;
    } else {
      this.material.color.set(0x94a3b8); // Packed ice shadow tone
      this.material.opacity = 0.75;
    }
  }

  public reset() {
    this.positions.fill(0);
    this.opacities.fill(0);
    this.pointCount = 0;
    this.lastRecordedZ = -999;
    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.attributes.alpha.needsUpdate = true;
  }

  public dispose() {
    this.geometry.dispose();
    this.material.dispose();
  }
}
