/**
 * Procedural Web Audio Sound Synthesizer for Alpine Rush
 * Zero external audio files; pure procedural DSP.
 * Engineered for maximum satisfaction: velvety warm tones, ASMR crystal chimes,
 * soothing organic pads, and serene ambient resonance.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private masterGain: GainNode | null = null;

  // Continuous sound nodes
  private windNode: AudioNode | null = null;
  private windGain: GainNode | null = null;
  private carveNode: AudioNode | null = null;
  private carveGain: GainNode | null = null;
  private carveFilter: BiquadFilterNode | null = null;

  // Ambient synth music loop
  private musicInterval: number | null = null;
  private lobbyInterval: number | null = null;
  private lobbyBeat: number = 0;
  private musicEnabled: boolean = true;

  constructor() {
    // AudioContext will be initialized on first user gesture
  }

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.isMuted ? 0 : 0.65;
      this.masterGain.connect(this.ctx.destination);
      this.setupContinuousLoops();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : 0.65, this.ctx.currentTime);
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  private createSoftNoiseBuffer(duration = 2.5): AudioBuffer {
    if (!this.ctx) throw new Error('No context');
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      // Soft gentle brownian/pink noise
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      data[i] = (b0 + b1 + b2) * 0.18;
    }
    return buffer;
  }

  private setupContinuousLoops() {
    if (!this.ctx || !this.masterGain) return;

    try {
      const noiseBuffer = this.createSoftNoiseBuffer();

      // Soothing mountain / ocean breeze
      const windSource = this.ctx.createBufferSource();
      windSource.buffer = noiseBuffer;
      windSource.loop = true;
      const windFilter = this.ctx.createBiquadFilter();
      windFilter.type = 'lowpass';
      windFilter.frequency.value = 320;
      this.windGain = this.ctx.createGain();
      this.windGain.gain.value = 0;
      windSource.connect(windFilter);
      windFilter.connect(this.windGain);
      this.windGain.connect(this.masterGain);
      windSource.start();
      this.windNode = windSource;

      // Soft powdery snow glide / ocean spray wake
      const carveSource = this.ctx.createBufferSource();
      carveSource.buffer = noiseBuffer;
      carveSource.loop = true;
      this.carveFilter = this.ctx.createBiquadFilter();
      this.carveFilter.type = 'bandpass';
      this.carveFilter.frequency.value = 950;
      this.carveFilter.Q.value = 1.4;
      this.carveGain = this.ctx.createGain();
      this.carveGain.gain.value = 0;
      carveSource.connect(this.carveFilter);
      this.carveFilter.connect(this.carveGain);
      this.carveGain.connect(this.masterGain);
      carveSource.start();
      this.carveNode = carveSource;
    } catch (e) {
      console.warn('Error setting up continuous audio loops', e);
    }
  }

  public updateMotion(speedKmh: number, isAirborne: boolean, carveIntensity: number, isBoosting: boolean) {
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;

    // Soothing gentle wind presence
    if (this.windGain) {
      const targetWind = Math.min(0.25, Math.max(0, (speedKmh - 20) / 110 * 0.2 + (isBoosting ? 0.08 : 0)));
      this.windGain.gain.setTargetAtTime(targetWind, t, 0.15);
    }

    // Organic powdery carve whisper
    if (this.carveGain && this.carveFilter) {
      if (isAirborne || speedKmh < 4) {
        this.carveGain.gain.setTargetAtTime(0, t, 0.08);
      } else {
        const targetCarve = Math.min(0.22, (0.04 + Math.abs(carveIntensity) * 0.18) * (speedKmh / 80));
        this.carveGain.gain.setTargetAtTime(targetCarve, t, 0.06);
        this.carveFilter.frequency.setTargetAtTime(700 + Math.abs(carveIntensity) * 800 + speedKmh * 4, t, 0.08);
      }
    }
  }

  // Soft airy jump lift (gentle harmonic whoosh)
  public playJump() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, t);
    osc.frequency.exponentialRampToValueAtTime(340, t + 0.22);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.26);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.28);
  }

  // Velvety soft snow cushion touchdown
  public playLand(impactScale = 1.0) {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(95, t);
    osc.frequency.exponentialRampToValueAtTime(32, t + 0.18);

    gain.gain.setValueAtTime(Math.min(0.28, 0.18 * impactScale), t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.22);
  }

  // Calming, tactile kalimba / crystal glass chime for coins
  public playCoin() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // Soothing dual-tone glass marimba (E6 & B6 pentatonic harmonic)
    const notes = [1318.51, 1975.53]; 
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.04);

      // Sweet ASMR-like bell envelope
      gain.gain.setValueAtTime(0.14, t + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.04 + 0.32);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.04);
      osc.stop(t + idx * 0.04 + 0.35);
    });
  }

  // Sparkling celestial windchime arpeggio for gems
  public playGem() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const chord = [880.0, 1174.66, 1479.98, 1760.0]; // A5, D6, F#6, A6 major chord
    chord.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.04);

      gain.gain.setValueAtTime(0.12, t + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.04 + 0.55);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.04);
      osc.stop(t + idx * 0.04 + 0.58);
    });
  }

  // Warm wooden marimba chime on slalom gates
  public playGate() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const chord = [659.25, 987.77]; // E5, B5
    chord.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, t + idx * 0.03);

      gain.gain.setValueAtTime(0.16, t + idx * 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.03 + 0.32);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.03);
      osc.stop(t + idx * 0.03 + 0.35);
    });
  }

  // Harmonious Celesta chime for tricks
  public playTrick(multiplier: number) {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const baseFreq = 440 * (1 + Math.min(multiplier * 0.1, 0.8));
    const freqs = [baseFreq, baseFreq * 1.25, baseFreq * 1.5, baseFreq * 1.875]; // Lush Major 7th chord

    freqs.forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + i * 0.04);

      gain.gain.setValueAtTime(0.13, t + i * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, t + i * 0.04 + 0.45);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + i * 0.04);
      osc.stop(t + i * 0.04 + 0.48);
    });
  }

  // Smooth warm swell for powerups (no harsh buzzing)
  public playPowerUp() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const freqs = [392.0, 523.25, 659.25, 783.99]; // G4 to G5 arpeggio
    freqs.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t + idx * 0.05);

      gain.gain.setValueAtTime(0.14, t + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.38);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.05);
      osc.stop(t + idx * 0.05 + 0.4);
    });
  }

  // Sparkling crystalline starlight bells
  public playStarChime() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const freqs = [659.25, 830.61, 987.77, 1318.51, 1661.22]; // E-Major celestial pentatonic
    freqs.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.05);

      gain.gain.setValueAtTime(0.16, t + idx * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.6);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.05);
      osc.stop(t + idx * 0.05 + 0.65);
    });
  }

  // Peaceful golden bell chime for Double Coins activation
  public playDoubleCoins() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const freqs = [587.33, 739.99, 880.00, 1108.73, 1479.98]; // D Major 9th chime
    freqs.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, t + idx * 0.04);

      gain.gain.setValueAtTime(0.15, t + idx * 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.04 + 0.6);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.04);
      osc.stop(t + idx * 0.04 + 0.65);
    });
  }

  // Awe-inspiring, serene celestial fanfare for entering a new place
  public playZoneTransition() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const notes = [440.0, 554.37, 659.25, 880.0, 1108.73, 1318.51]; // A, C#, E, A, C#, E celestial harp
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t + idx * 0.07);

      gain.gain.setValueAtTime(0.18, t + idx * 0.07);
      gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.07 + 0.7);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + idx * 0.07);
      osc.stop(t + idx * 0.07 + 0.75);
    });
  }

  // Silky smooth booster glide (warm harmonic rise, never shrill)
  public playBoost() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, t);
    osc.frequency.exponentialRampToValueAtTime(260, t + 0.28);

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.35);
  }

  // Soft powdery impact for crashes (cushioned low-frequency thud, no ear-piercing harshness)
  public playCrash() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    const oscGain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(80, t);
    osc.frequency.exponentialRampToValueAtTime(20, t + 0.3);

    oscGain.gain.setValueAtTime(0.35, t);
    oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

    osc.connect(oscGain);
    oscGain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.38);

    try {
      const buffer = this.createSoftNoiseBuffer(0.35);
      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;
      const noiseFilter = this.ctx.createBiquadFilter();
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(800, t);
      noiseFilter.frequency.exponentialRampToValueAtTime(150, t + 0.3);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.28, t);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, t + 0.32);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(this.masterGain);
      noise.start(t);
      noise.stop(t + 0.35);
    } catch {
      // fallback
    }
  }

  // Ultra-calming, dreamy lo-fi ambient pad chords (lush, tranquil, peaceful)
  public startAtmosphericMusic() {
    if (this.musicInterval !== null) return;
    this.initCtx();

    // Serene dreamy ambient chords: Dmaj9 -> Gmaj7 -> Bm9 -> A6
    const chords = [
      [146.83, 220.00, 277.18, 369.99, 440.00], // D3, A3, C#4, F#4, A4
      [196.00, 246.94, 293.66, 369.99, 440.00], // G3, B3, D4, F#4, A4
      [123.47, 185.00, 220.00, 277.18, 369.99], // B2, F#3, A3, C#4, F#4
      [110.00, 164.81, 220.00, 293.66, 369.99], // A2, E3, A3, D4, F#4
    ];
    let chordIdx = 0;

    const playChord = () => {
      if (!this.musicEnabled || this.isMuted || !this.ctx || !this.masterGain) return;
      const t = this.ctx.currentTime;
      const chord = chords[chordIdx % chords.length];
      chordIdx++;

      chord.forEach((freq) => {
        if (!this.ctx || !this.masterGain) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t);

        // Slow breathing attack, warm sustaining pad, soft feather release
        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.linearRampToValueAtTime(0.024, t + 1.2);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 4.2);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + 4.5);
      });
    };

    playChord();
    this.musicInterval = window.setInterval(playChord, 3800);
  }

  public stopAtmosphericMusic() {
    if (this.musicInterval !== null) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
  }

  // Upbeat, catchy synthwave arcade groove for the lobby & menu
  public startLobbyMusic() {
    this.stopAtmosphericMusic();
    if (this.lobbyInterval !== null) return;
    this.initCtx();
    if (!this.musicEnabled || this.isMuted) return;

    this.lobbyBeat = 0;
    // Catchy upbeat synthwave lobby groove: 120 BPM (125ms per 16th note, 250ms per 8th note)
    const melodySeq = [
      523.25, 0, 587.33, 659.25, 0, 783.99, 659.25, 0,
      523.25, 0, 440.00, 523.25, 0, 659.25, 587.33, 0,
      659.25, 0, 783.99, 880.00, 0, 1046.50, 880.00, 0,
      783.99, 0, 659.25, 587.33, 523.25, 0, 587.33, 0
    ];
    const bassSeq = [
      130.81, 130.81, 261.63, 130.81, 110.00, 110.00, 220.00, 110.00,
      146.83, 146.83, 293.66, 146.83, 130.81, 130.81, 261.63, 196.00
    ];

    const tick = () => {
      if (!this.musicEnabled || this.isMuted || !this.ctx || !this.masterGain) return;
      const t = this.ctx.currentTime;
      const step16 = this.lobbyBeat % 32;
      const step8 = Math.floor(this.lobbyBeat / 2) % 16;
      this.lobbyBeat++;

      // 1. Melodic Arp note
      const noteFreq = melodySeq[step16];
      if (noteFreq > 0) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(noteFreq, t);

        gain.gain.setValueAtTime(0.0001, t);
        gain.gain.linearRampToValueAtTime(0.045, t + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + 0.24);
      }

      // 2. Punchy Synth Bass on every 8th note
      if (this.lobbyBeat % 2 === 0) {
        const bassFreq = bassSeq[step8];
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();
        bOsc.type = 'sawtooth';
        bOsc.frequency.setValueAtTime(bassFreq, t);

        const bFilter = this.ctx.createBiquadFilter();
        bFilter.type = 'lowpass';
        bFilter.frequency.setValueAtTime(450, t);
        bFilter.frequency.exponentialRampToValueAtTime(140, t + 0.22);

        bGain.gain.setValueAtTime(0.05, t);
        bGain.gain.exponentialRampToValueAtTime(0.0001, t + 0.23);

        bOsc.connect(bFilter);
        bFilter.connect(bGain);
        bGain.connect(this.masterGain);
        bOsc.start(t);
        bOsc.stop(t + 0.25);
      }

      // 3. Crisp Lo-Fi Hi-Hat click on off-beats
      if (step16 % 4 === 2) {
        this.playSoftHiHat(t);
      }
    };

    tick();
    this.lobbyInterval = window.setInterval(tick, 125);
  }

  public stopLobbyMusic() {
    if (this.lobbyInterval !== null) {
      clearInterval(this.lobbyInterval);
      this.lobbyInterval = null;
    }
  }

  private playSoftHiHat(t: number) {
    if (!this.ctx || !this.masterGain) return;
    try {
      const buffer = this.createSoftNoiseBuffer(0.05);
      const src = this.ctx.createBufferSource();
      src.buffer = buffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 6500;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.025, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      src.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);
      src.start(t);
      src.stop(t + 0.06);
    } catch {}
  }

  // Triumphant arcade fanfare for cinematic game intro
  public playIntroFanfare() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // Ascending brass/synth fanfare: C4 -> E4 -> G4 -> C5 -> E5 -> G5 chord shimmer
    const notes = [
      { f: 261.63, delay: 0.0, dur: 0.35 },
      { f: 329.63, delay: 0.15, dur: 0.35 },
      { f: 392.00, delay: 0.30, dur: 0.40 },
      { f: 523.25, delay: 0.45, dur: 0.85 },
      { f: 659.25, delay: 0.45, dur: 0.85 },
      { f: 783.99, delay: 0.45, dur: 0.95 },
      { f: 1046.50, delay: 0.50, dur: 1.10 },
    ];

    notes.forEach(({ f, delay, dur }) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, t + delay);

      gain.gain.setValueAtTime(0.0001, t + delay);
      gain.gain.linearRampToValueAtTime(0.18, t + delay + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + delay + dur);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t + delay);
      osc.stop(t + delay + dur + 0.05);
    });
  }

  // Spooky Halloween horror jumpscare hit & screech
  public playJumpscare() {
    this.initCtx();
    if (!this.ctx || !this.masterGain || this.isMuted) return;
    const t = this.ctx.currentTime;

    // 1. Deep hollow sub-bass impact thud
    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(65, t);
    subOsc.frequency.exponentialRampToValueAtTime(18, t + 0.6);
    subGain.gain.setValueAtTime(0.5, t);
    subGain.gain.exponentialRampToValueAtTime(0.001, t + 0.6);
    subOsc.connect(subGain);
    subGain.connect(this.masterGain);
    subOsc.start(t);
    subOsc.stop(t + 0.65);

    // 2. Piercing dissonant horror tritone screech (Witch scream effect)
    const screeches = [666, 888, 1250, 1776];
    screeches.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = idx % 2 === 0 ? 'sawtooth' : 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.linearRampToValueAtTime(freq * (1.3 + idx * 0.1), t + 0.25);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.4, t + 0.8);

      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.85);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.9);
    });
  }
}

export const sound = new SoundEngine();
