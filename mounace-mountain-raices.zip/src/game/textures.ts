import * as THREE from 'three';
import { JacketPattern, VehicleType } from '../types/game';

/**
 * Creates a procedural canvas texture for the racer jacket outfit with custom patterns
 */
export function createJacketTexture(
  baseColorHex: string,
  pattern: JacketPattern,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base background
  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, 512, 512);

  if (pattern === 'solid') {
    // Subtle fabric weave texture
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    for (let y = 0; y < 512; y += 4) {
      ctx.fillRect(0, y, 512, 1.5);
    }
    // Subtle shoulder accents
    ctx.fillStyle = accentColorHex;
    ctx.fillRect(0, 0, 512, 32);
    ctx.fillRect(240, 32, 32, 480); // zipper
  } else if (pattern === 'stripes') {
    // Bold diagonal racing stripes
    ctx.save();
    ctx.translate(256, 256);
    ctx.rotate(-Math.PI / 4);
    ctx.fillStyle = accentColorHex;
    ctx.fillRect(-300, -50, 600, 40);
    ctx.fillRect(-300, 10, 600, 20);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-300, 40, 600, 8);
    ctx.restore();

    // Center seam & collar
    ctx.fillStyle = '#111827';
    ctx.fillRect(250, 0, 12, 512);
  } else if (pattern === 'camo') {
    // Winter fractured camouflage
    const colors = [
      accentColorHex,
      '#ffffff',
      'rgba(0, 0, 0, 0.35)',
      'rgba(255, 255, 255, 0.4)',
    ];

    for (let i = 0; i < 48; i++) {
      ctx.fillStyle = colors[i % colors.length];
      ctx.beginPath();
      const x = (i * 137) % 512;
      const y = (i * 89) % 512;
      const size = 30 + (i % 5) * 15;
      ctx.moveTo(x, y);
      ctx.lineTo(x + size, y + size * 0.4);
      ctx.lineTo(x + size * 0.8, y + size * 1.2);
      ctx.lineTo(x - size * 0.3, y + size);
      ctx.closePath();
      ctx.fill();
    }
    // Zipper
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(250, 0, 12, 512);
  } else if (pattern === 'cyber') {
    // Hexagonal circuit grid
    ctx.strokeStyle = accentColorHex;
    ctx.lineWidth = 3;
    const size = 32;
    for (let x = 0; x < 512; x += size * 1.5) {
      for (let y = 0; y < 512; y += size * Math.sqrt(3)) {
        ctx.beginPath();
        for (let a = 0; a < 6; a++) {
          const angle = (a * Math.PI) / 3;
          const hx = x + size * Math.cos(angle);
          const hy = y + size * Math.sin(angle);
          if (a === 0) ctx.moveTo(hx, hy);
          else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();
      }
    }
    // Glowing center conduits
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(256, 0);
    ctx.lineTo(256, 512);
    ctx.stroke();
  } else if (pattern === 'chevron') {
    // Retro 80s V-stripes
    ctx.fillStyle = accentColorHex;
    for (let y = 40; y < 512; y += 110) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(256, y + 80);
      ctx.lineTo(512, y);
      ctx.lineTo(512, y + 45);
      ctx.lineTo(256, y + 125);
      ctx.lineTo(0, y + 45);
      ctx.closePath();
      ctx.fill();
    }
    // White border line
    ctx.fillStyle = '#ffffff';
    for (let y = 40; y < 512; y += 110) {
      ctx.beginPath();
      ctx.moveTo(0, y + 45);
      ctx.lineTo(256, y + 125);
      ctx.lineTo(512, y + 45);
      ctx.lineTo(512, y + 55);
      ctx.lineTo(256, y + 135);
      ctx.lineTo(0, y + 55);
      ctx.closePath();
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Creates board / ski top-sheet graphics
 */
export function createBoardTexture(
  boardColorHex: string,
  accentColorHex: string,
  vehicleType: VehicleType
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d')!;

  // Base background
  ctx.fillStyle = boardColorHex;
  ctx.fillRect(0, 0, 256, 1024);

  // Carbon fiber weave background effect
  ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
  for (let y = 0; y < 1024; y += 8) {
    ctx.fillRect(0, y, 256, 4);
  }

  // Graphic accents
  ctx.fillStyle = accentColorHex;
  ctx.beginPath();
  ctx.moveTo(0, 200);
  ctx.lineTo(256, 350);
  ctx.lineTo(256, 420);
  ctx.lineTo(0, 270);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(0, 750);
  ctx.lineTo(256, 600);
  ctx.lineTo(256, 670);
  ctx.lineTo(0, 820);
  ctx.closePath();
  ctx.fill();

  // Sport logo text
  ctx.save();
  ctx.translate(128, 512);
  ctx.rotate(-Math.PI / 2);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 36px "Chakra Petch", sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(vehicleType === 'skis' ? 'ALPINE // CARVE' : 'PRO RUSH // 162', 0, 12);
  ctx.restore();

  // Steel edges indicator
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(0, 0, 8, 1024);
  ctx.fillRect(248, 0, 8, 1024);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Creates a procedural normal map for crisp snow sparkle and micro moguls
 */
export function createSnowNormalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(512, 512);
  const data = imgData.data;

  for (let y = 0; y < 512; y++) {
    for (let x = 0; x < 512; x++) {
      const idx = (y * 512 + x) * 4;
      // Wavy windblown snow sastrugi wave
      const wave = Math.sin(x * 0.05 + Math.cos(y * 0.02) * 2.0) * 12;
      // High-frequency crystalline snow facet glint
      const sparkle = (Math.random() - 0.5) * 28;

      data[idx] = Math.min(255, Math.max(0, 128 + wave + sparkle));     // nx
      data[idx + 1] = Math.min(255, Math.max(0, 128 + sparkle * 0.8)); // ny
      data[idx + 2] = 240;                                             // nz (mostly upward)
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 48);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural snow ground diffuse texture with wind ripples and crystalline glint
 */
export function createSnowDiffuseTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Pristine alpine snow gradient with subtle blue ambient sky bounce
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.4, '#f8fafc');
  grad.addColorStop(0.8, '#f1f5f9');
  grad.addColorStop(1, '#e2e8f0');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Soft windblown sastrugi drifts
  ctx.fillStyle = 'rgba(219, 234, 254, 0.35)'; // Sky blue tint in drifts
  for (let y = 0; y < 512; y += 24) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(150, y + 14, 320, y - 12, 512, y + 4);
    ctx.lineTo(512, y + 10);
    ctx.bezierCurveTo(320, y - 2, 150, y + 22, 0, y + 8);
    ctx.closePath();
    ctx.fill();
  }

  // Micro crystalline powder glints
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 400; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const r = Math.random() * 1.5;
    ctx.beginPath();
    ctx.arc(rx, ry, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 32);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Soft radial alpha texture for realistic billowing powder puffs
 */
export function createPowderPuffTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
  grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
  grad.addColorStop(0.3, 'rgba(241, 245, 249, 0.6)');
  grad.addColorStop(0.7, 'rgba(224, 242, 254, 0.2)');
  grad.addColorStop(1, 'rgba(255, 255, 255, 0.0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural coastal sand diffuse texture with warm golden tone, dune ridges, and mineral sparkle
 */
export function createSandDiffuseTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm golden sun-drenched coastal sand gradient
  const grad = ctx.createLinearGradient(0, 0, 0, 512);
  grad.addColorStop(0, '#fef08a');   // Bright sunlit crest
  grad.addColorStop(0.3, '#fde047'); // Warm beach gold
  grad.addColorStop(0.7, '#eab308'); // Amber dune tone
  grad.addColorStop(1, '#ca8a04');   // Deeper warm sand trough
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Windblown dune ripple ridges
  ctx.fillStyle = 'rgba(180, 83, 9, 0.22)';
  for (let y = 0; y < 512; y += 18) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(140, y + 8, 340, y - 10, 512, y + 4);
    ctx.lineTo(512, y + 7);
    ctx.bezierCurveTo(340, y - 3, 140, y + 15, 0, y + 7);
    ctx.closePath();
    ctx.fill();
  }

  // Sparkling golden quartz/mica crystals
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 350; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const r = Math.random() * 1.4;
    ctx.beginPath();
    ctx.arc(rx, ry, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Crushed seashell flecks (coral pink & pearl white)
  const shellColors = ['rgba(254, 205, 211, 0.6)', 'rgba(255, 255, 255, 0.8)', 'rgba(253, 224, 71, 0.5)'];
  for (let i = 0; i < 180; i++) {
    ctx.fillStyle = shellColors[i % shellColors.length];
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    ctx.fillRect(rx, ry, 2, 2);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 32);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural normal map for coastal sand dune ripples
 */
export function createSandNormalTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  const imgData = ctx.createImageData(512, 512);
  const data = imgData.data;

  for (let y = 0; y < 512; y++) {
    for (let x = 0; x < 512; x++) {
      const idx = (y * 512 + x) * 4;
      // Wavy windblown sand dune ridges
      const ripple = Math.sin(y * 0.15 + Math.cos(x * 0.04) * 3.0) * 22;
      const microGrain = (Math.random() - 0.5) * 16;

      data[idx] = Math.min(255, Math.max(0, 128 + microGrain));
      data[idx + 1] = Math.min(255, Math.max(0, 128 + ripple + microGrain * 0.5));
      data[idx + 2] = 230; // Strong upward normal
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 48);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Tropical Hawaiian floral beach shirt & rashguard texture
 */
export function createBeachShirtTexture(
  baseColorHex: string,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Base tropical fabric
  ctx.fillStyle = baseColorHex;
  ctx.fillRect(0, 0, 512, 512);

  // Tropical palm leaves & hibiscus flowers pattern
  const petalColors = ['#ffffff', accentColorHex, '#fef08a', '#f43f5e'];
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 5; col++) {
      const cx = col * 110 + (row % 2) * 55 + 25;
      const cy = row * 110 + 25;

      // 5-petal tropical flower
      for (let p = 0; p < 5; p++) {
        const ang = (p * Math.PI * 2) / 5;
        const px = cx + Math.cos(ang) * 18;
        const py = cy + Math.sin(ang) * 18;

        ctx.fillStyle = petalColors[(row + col + p) % petalColors.length];
        ctx.beginPath();
        ctx.arc(px, py, 11, 0, Math.PI * 2);
        ctx.fill();
      }

      // Yellow flower center
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(cx, cy, 7, 0, Math.PI * 2);
      ctx.fill();

      // Curved tropical palm frond
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx - 25, cy - 20);
      ctx.quadraticCurveTo(cx - 40, cy - 35, cx - 60, cy - 25);
      ctx.stroke();
    }
  }

  // Zipper / open collar center accent
  ctx.fillStyle = 'rgba(0, 0, 0, 0.25)';
  ctx.fillRect(250, 0, 12, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * High-gloss resin tropical surfboard & sandboard texture
 */
export function createSurfboardTexture(
  baseColorHex: string,
  accentColorHex: string
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Vibrant gradient resin deck
  const grad = ctx.createLinearGradient(0, 0, 512, 512);
  grad.addColorStop(0, '#ffffff');
  grad.addColorStop(0.2, baseColorHex);
  grad.addColorStop(0.8, accentColorHex);
  grad.addColorStop(1, '#0284c7');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 512, 512);

  // Dynamic ocean breaker wave crest decal
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.moveTo(0, 200);
  ctx.bezierCurveTo(150, 160, 300, 340, 512, 180);
  ctx.lineTo(512, 230);
  ctx.bezierCurveTo(300, 390, 150, 210, 0, 250);
  ctx.closePath();
  ctx.fill();

  // Tropical sunburst logo
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath();
  ctx.arc(256, 120, 32, 0, Math.PI * 2);
  ctx.fill();

  // Carbon fiber / balsa wood stringer centerline
  ctx.fillStyle = '#1e293b';
  ctx.fillRect(252, 0, 8, 512);

  // Deck traction pad at the tail
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(180, 420, 152, 70);

  const texture = new THREE.CanvasTexture(canvas);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural polished oak wood parquet/plank floor texture for Alpine Chalet Lodge interior
 */
export function createWoodPlankTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm honey oak background
  ctx.fillStyle = '#92400e'; // Warm oak
  ctx.fillRect(0, 0, 512, 512);

  // Planks across Y
  const plankHeight = 64;
  for (let y = 0; y < 512; y += plankHeight) {
    // Individual plank tint variations
    const hueShift = (Math.random() - 0.5) * 20;
    ctx.fillStyle = `rgb(${160 + hueShift}, ${90 + hueShift * 0.6}, ${30 + hueShift * 0.3})`;
    ctx.fillRect(0, y, 512, plankHeight - 4);

    // Fine wood grain lines
    ctx.fillStyle = 'rgba(74, 30, 8, 0.25)';
    for (let g = 0; g < 14; g++) {
      const gy = y + 4 + Math.random() * (plankHeight - 12);
      ctx.fillRect(0, gy, 512, 1.5);
    }

    // Wood knot
    if (Math.random() > 0.4) {
      const kx = 60 + Math.random() * 390;
      const ky = y + plankHeight * 0.5;
      ctx.fillStyle = '#451a03';
      ctx.beginPath();
      ctx.ellipse(kx, ky, 8, 4, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // Staggered plank ends (joints)
    const jointX1 = (y * 3.7) % 512;
    const jointX2 = (jointX1 + 256) % 512;
    ctx.fillStyle = '#291002';
    ctx.fillRect(jointX1, y, 4, plankHeight);
    ctx.fillRect(jointX2, y, 4, plankHeight);

    // Dark seam between planks
    ctx.fillStyle = '#1c0a00';
    ctx.fillRect(0, y + plankHeight - 4, 512, 4);
  }

  // Golden polish shine highlight
  ctx.fillStyle = 'rgba(254, 240, 138, 0.08)';
  for (let y = 0; y < 512; y += plankHeight) {
    ctx.fillRect(0, y + 4, 512, 6);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 24);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural horizontal log cabin wall texture for Alpine Chalet interior
 */
export function createWoodWallTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#78350f'; // Dark amber cedar logs
  ctx.fillRect(0, 0, 512, 512);

  const logH = 85;
  for (let y = 0; y < 512; y += logH) {
    // Log roundness gradient
    const grad = ctx.createLinearGradient(0, y, 0, y + logH);
    grad.addColorStop(0, '#451a03');
    grad.addColorStop(0.3, '#9a3412');
    grad.addColorStop(0.7, '#b45309');
    grad.addColorStop(1, '#3b1402');
    ctx.fillStyle = grad;
    ctx.fillRect(0, y, 512, logH - 6);

    // Chinking seam (white/mortar between logs)
    ctx.fillStyle = '#fef3c7';
    ctx.fillRect(0, y + logH - 6, 512, 6);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 8);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Halloween Gothic Cloak / Vampire Jacket Texture
 */
export function createHalloweenShirtTexture(baseColor = '#18181b', accentColor = '#a855f7'): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 256, 256);

  // Spooky spiderweb pattern & gothic orange/purple accents
  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 1.5;
  ctx.globalAlpha = 0.6;
  // Spiderweb corner
  for (let r = 20; r < 140; r += 25) {
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI / 2);
    ctx.stroke();
  }
  for (let a = 0; a <= Math.PI / 2; a += Math.PI / 8) {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(a) * 140, Math.sin(a) * 140);
    ctx.stroke();
  }
  ctx.globalAlpha = 1.0;

  // Jack-o'-lantern orange trim
  ctx.fillStyle = '#f97316';
  ctx.fillRect(0, 240, 256, 16);
  ctx.fillRect(120, 0, 16, 256);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Magic Broomstick / Coffin Board Texture
 */
export function createHalloweenBoardTexture(baseColor = '#2e1065', accentColor = '#f97316'): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 128, 512);

  // Purple mystic runes
  ctx.fillStyle = accentColor;
  ctx.font = 'bold 24px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('⛥ ☾ ⛧ ☽ ⛥', 64, 120);
  ctx.fillText('H A L L O W', 64, 256);
  ctx.fillText('⛥ ☾ ⛧ ☽ ⛥', 64, 380);

  // Glowing outline
  ctx.strokeStyle = '#c084fc';
  ctx.lineWidth = 4;
  ctx.strokeRect(8, 8, 112, 496);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural School Varsity Jacket Texture
 */
export function createSchoolVarsityTexture(baseColor = '#1e3a8a', accentColor = '#f59e0b'): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Navy or Crimson Varsity body
  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 256, 256);

  // White leather sleeves
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, 50, 256);
  ctx.fillRect(206, 0, 50, 256);

  // Striped rib knit collar and cuffs
  ctx.fillStyle = accentColor;
  ctx.fillRect(0, 0, 256, 14);
  ctx.fillRect(0, 242, 256, 14);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 14, 256, 6);
  ctx.fillRect(0, 236, 256, 6);

  // Letterman 'A' Patch on chest
  ctx.fillStyle = accentColor;
  ctx.font = '900 64px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('A', 128, 140);
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 3;
  ctx.strokeText('A', 128, 140);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural School Skateboard / Heavy Wooden Ruler Deck Texture
 */
export function createSchoolBoardTexture(baseColor = '#d97706', accentColor = '#1e3a8a'): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm school ruler yellow-wood
  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 128, 512);

  // Metric & Imperial ruler tick marks
  ctx.fillStyle = '#0f172a';
  for (let y = 20; y < 500; y += 12) {
    const isMajor = (y % 60) === 0;
    const tickW = isMajor ? 28 : (y % 24 === 0 ? 18 : 10);
    ctx.fillRect(0, y, tickW, 2);
    ctx.fillRect(128 - tickW, y, tickW, 2);
    if (isMajor) {
      ctx.font = '10px monospace';
      ctx.fillText(String(Math.floor(y / 10)), 32, y + 4);
    }
  }

  // School Crest in middle
  ctx.fillStyle = accentColor;
  ctx.beginPath();
  ctx.arc(64, 256, 28, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('100%', 64, 262);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Cemetery Moss & Dead Grass Ground Texture
 */
export function createCemeteryGroundTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Dark overgrown turf & soil
  ctx.fillStyle = '#1c1917';
  ctx.fillRect(0, 0, 512, 512);

  // Dead grass patches
  ctx.fillStyle = '#292524';
  for (let i = 0; i < 400; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const r = Math.random() * 20 + 5;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Eerie dark purple/green moss
  ctx.fillStyle = '#14532d';
  ctx.globalAlpha = 0.25;
  for (let i = 0; i < 200; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    ctx.fillRect(x, y, Math.random() * 40 + 10, Math.random() * 40 + 10);
  }
  ctx.globalAlpha = 1.0;

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(12, 48);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural School Hallway Tile Floor Texture
 */
export function createSchoolHallwayFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  const tileSize = 64;
  for (let y = 0; y < 512; y += tileSize) {
    for (let x = 0; x < 512; x += tileSize) {
      const isAlt = ((x / tileSize) + (y / tileSize)) % 2 === 0;
      ctx.fillStyle = isAlt ? '#f8fafc' : '#cbd5e1';
      ctx.fillRect(x, y, tileSize, tileSize);
      // Grout seam
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, tileSize, tileSize);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(8, 32);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Neon Cyber Highway Floor Texture
 */
export function createCyberHighwayFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep obsidian cyber tarmac
  ctx.fillStyle = '#05050d';
  ctx.fillRect(0, 0, 512, 512);

  // Glowing neon cyan & magenta speed lanes
  ctx.strokeStyle = '#06b6d4';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(128, 0); ctx.lineTo(128, 512);
  ctx.moveTo(384, 0); ctx.lineTo(384, 512);
  ctx.stroke();

  // Center dashed neon pink line
  ctx.strokeStyle = '#ec4899';
  ctx.lineWidth = 6;
  ctx.setLineDash([32, 32]);
  ctx.beginPath();
  ctx.moveTo(256, 0); ctx.lineTo(256, 512);
  ctx.stroke();
  ctx.setLineDash([]);

  // Horizontal neon laser grid pulses
  ctx.strokeStyle = 'rgba(34, 211, 238, 0.25)';
  ctx.lineWidth = 2;
  for (let y = 0; y < 512; y += 64) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 24);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Cyber Club Underground Floor Texture
 */
export function createCyberClubFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#090014';
  ctx.fillRect(0, 0, 512, 512);

  // Hexagonal glowing matrix grid
  ctx.strokeStyle = '#a855f7';
  ctx.lineWidth = 2;
  const size = 32;
  for (let y = 0; y < 512; y += size) {
    for (let x = 0; x < 512; x += size) {
      ctx.strokeRect(x, y, size, size);
      if (((x / size) + (y / size)) % 3 === 0) {
        ctx.fillStyle = 'rgba(236, 72, 153, 0.35)';
        ctx.fillRect(x + 2, y + 2, size - 4, size - 4);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 24);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Cyberpunk Neon Outfit Texture
 */
export function createCyberSuitTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, 512, 512);

  // Neon circuit traces
  ctx.strokeStyle = '#22d3ee';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(50, 0); ctx.lineTo(50, 200); ctx.lineTo(150, 300); ctx.lineTo(150, 512);
  ctx.moveTo(462, 0); ctx.lineTo(462, 200); ctx.lineTo(362, 300); ctx.lineTo(362, 512);
  ctx.moveTo(256, 100); ctx.lineTo(256, 450);
  ctx.stroke();

  // Neon magenta core nodes
  ctx.fillStyle = '#f43f5e';
  ctx.beginPath();
  ctx.arc(256, 180, 24, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Cyber Hoverboard Deck Texture
 */
export function createCyberHoverboardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, 256, 512);

  // Dual glowing neon teal plasma rails
  ctx.fillStyle = '#06b6d4';
  ctx.fillRect(16, 0, 16, 512);
  ctx.fillRect(224, 0, 16, 512);

  // Center neon warning chevron
  ctx.strokeStyle = '#eab308';
  ctx.lineWidth = 5;
  for (let y = 80; y < 450; y += 60) {
    ctx.beginPath();
    ctx.moveTo(80, y);
    ctx.lineTo(128, y + 25);
    ctx.lineTo(176, y);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Spring Road Asphalt & Petals Texture
 */
export function createSpringRoadFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Lush green hill grass base
  ctx.fillStyle = '#4ade80';
  ctx.fillRect(0, 0, 512, 512);

  // Grass blade flecks
  ctx.fillStyle = '#22c55e';
  for (let i = 0; i < 300; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    ctx.fillRect(x, y, 3, 7);
  }

  // Smooth clean asphalt road down the center
  ctx.fillStyle = '#334155';
  ctx.fillRect(70, 0, 372, 512);

  // Road curb stripes
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(70, 0, 8, 512);
  ctx.fillRect(434, 0, 8, 512);

  // White road dashed center divider lines
  ctx.fillStyle = '#f8fafc';
  for (let y = 10; y < 512; y += 64) {
    ctx.fillRect(250, y, 12, 36);
  }

  // Scattered pink cherry blossom petals on the road
  const petalColors = ['#fbcfe8', '#f472b6', '#fda4af', '#fecdd3'];
  for (let i = 0; i < 180; i++) {
    const px = Math.random() * 512;
    const py = Math.random() * 512;
    ctx.fillStyle = petalColors[i % petalColors.length];
    ctx.beginPath();
    ctx.ellipse(px, py, 4 + Math.random() * 3, 2 + Math.random() * 2, Math.random() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 20);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Sakura Bloom Tunnel Floor Texture (for 10k transition)
 */
export function createSpringSakuraBloomFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Dense pink blossom carpet on smooth stone
  ctx.fillStyle = '#fbcfe8';
  ctx.fillRect(0, 0, 512, 512);

  // Sakura petal clusters
  const petalTones = ['#f472b6', '#ec4899', '#db2777', '#fda4af', '#ffffff'];
  for (let i = 0; i < 600; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    ctx.fillStyle = petalTones[i % petalTones.length];
    ctx.beginPath();
    ctx.ellipse(x, y, 6, 3, Math.random() * Math.PI, 0, Math.PI * 2);
    ctx.fill();
  }

  // Festive cobblestone stepping outlines
  ctx.strokeStyle = 'rgba(219, 39, 119, 0.25)';
  ctx.lineWidth = 2;
  for (let y = 0; y < 512; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 20);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Spring Sportswear Outfit Texture
 */
export function createSpringOutfitTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Fresh sporty lime/mint green body
  ctx.fillStyle = '#22c55e';
  ctx.fillRect(0, 0, 256, 256);

  // Bright energetic orange & sakura pink diagonal athletic stripes
  ctx.save();
  ctx.translate(128, 128);
  ctx.rotate(-Math.PI / 4);
  ctx.fillStyle = '#f97316';
  ctx.fillRect(-150, -25, 300, 25);
  ctx.fillStyle = '#f472b6';
  ctx.fillRect(-150, 5, 300, 16);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(-150, 25, 300, 8);
  ctx.restore();

  // White collar and cuffs
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(0, 0, 256, 12);
  ctx.fillRect(0, 244, 256, 12);

  // Flower emblem on chest
  ctx.fillStyle = '#fbcfe8';
  ctx.beginPath();
  ctx.arc(128, 90, 16, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.arc(128, 90, 7, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Sugar Candy Road Texture
 */
export function createCandyFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Sweet bubblegum / strawberry pink frosting road
  ctx.fillStyle = '#f472b6';
  ctx.fillRect(0, 0, 512, 512);

  // Rainbow candy sugar sprinkles
  const sprinkles = ['#ef4444', '#3b82f6', '#10b981', '#fbbf24', '#ffffff', '#a855f7', '#fb7185'];
  for (let i = 0; i < 400; i++) {
    const sx = Math.random() * 512;
    const sy = Math.random() * 512;
    const color = sprinkles[i % sprinkles.length];
    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(Math.random() * Math.PI);
    ctx.fillStyle = color;
    ctx.fillRect(-4, -2, 8, 4);
    ctx.restore();
  }

  // Peppermint candy road divider stripes down middle
  for (let y = 0; y < 512; y += 48) {
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(246, y, 20, 28);
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(250, y + 4, 12, 20);
  }

  // Wavy sugar glaze borders
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 6;
  ctx.beginPath();
  for (let y = 0; y <= 512; y += 20) {
    const x = 50 + Math.sin(y * 0.05) * 12;
    if (y === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  ctx.beginPath();
  for (let y = 0; y <= 512; y += 20) {
    const x = 462 + Math.sin(y * 0.05) * 12;
    if (y === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 20);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Gummy Bear Palace Floor Texture (10k transition)
 */
export function createCandyPalaceFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep chocolate and magenta gloss marble
  ctx.fillStyle = '#701a75';
  ctx.fillRect(0, 0, 512, 512);

  // Candy honeycomb tiles
  ctx.strokeStyle = '#f472b6';
  ctx.lineWidth = 3;
  const r = 32;
  for (let y = 0; y < 512 + r; y += r * 1.5) {
    for (let x = 0; x < 512 + r; x += r * 1.732) {
      ctx.beginPath();
      for (let a = 0; a < 6; a++) {
        const angle = (a * Math.PI) / 3;
        const hx = x + r * Math.cos(angle);
        const hy = y + r * Math.sin(angle);
        if (a === 0) ctx.moveTo(hx, hy);
        else ctx.lineTo(hx, hy);
      }
      ctx.closePath();
      ctx.stroke();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 20);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Candy Chef Suit Texture
 */
export function createCandyChefOutfitTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // Clean chef sugar white jacket
  ctx.fillStyle = '#fdf2f8';
  ctx.fillRect(0, 0, 256, 256);

  // Pink and red peppermint trim
  ctx.fillStyle = '#ec4899';
  ctx.fillRect(0, 0, 256, 16);
  ctx.fillRect(0, 240, 256, 16);

  // Sweet lollipop candy buttons down center
  const buttonColors = ['#ef4444', '#f59e0b', '#10b981', '#3b82f6'];
  for (let i = 0; i < 4; i++) {
    ctx.fillStyle = buttonColors[i];
    ctx.beginPath();
    ctx.arc(128, 50 + i * 50, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Candy Cane Swirl Peppermint Board Texture
 */
export function createCandyBoardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // White candy cane base
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, 128, 512);

  // Classic red diagonal peppermint twists
  ctx.save();
  ctx.translate(64, 256);
  ctx.rotate(-Math.PI / 4);
  ctx.fillStyle = '#dc2626';
  for (let y = -400; y < 400; y += 40) {
    ctx.fillRect(-200, y, 400, 20);
  }
  ctx.restore();

  // Glossy sugar edges
  ctx.fillStyle = '#f43f5e';
  ctx.fillRect(0, 0, 6, 512);
  ctx.fillRect(122, 0, 6, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Deep Universe Cosmic Road Texture with Starry Grid & Pulsar Beams
 */
export function createUniverseCosmicRoadTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep obsidian void base
  ctx.fillStyle = '#050212';
  ctx.fillRect(0, 0, 512, 512);

  // Nebula gradient wash (violet to deep indigo)
  const nebulaGrad = ctx.createLinearGradient(0, 0, 512, 512);
  nebulaGrad.addColorStop(0, 'rgba(88, 28, 135, 0.45)');
  nebulaGrad.addColorStop(0.5, 'rgba(15, 23, 42, 0.1)');
  nebulaGrad.addColorStop(1, 'rgba(14, 116, 144, 0.4)');
  ctx.fillStyle = nebulaGrad;
  ctx.fillRect(0, 0, 512, 512);

  // Twinkling stardust specks
  for (let i = 0; i < 160; i++) {
    const sx = Math.random() * 512;
    const sy = Math.random() * 512;
    const r = Math.random() * 1.8 + 0.6;
    ctx.fillStyle = i % 4 === 0 ? '#38bdf8' : i % 3 === 0 ? '#c084fc' : '#ffffff';
    ctx.beginPath();
    ctx.arc(sx, sy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Futuristic cosmic cyber speedway rails & neon guide lines
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  for (let x = 64; x < 512; x += 96) {
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
  }
  ctx.stroke();

  // Pulsar latitude rings
  ctx.strokeStyle = 'rgba(192, 132, 252, 0.4)';
  ctx.lineWidth = 4;
  for (let y = 32; y < 512; y += 96) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Glowing borders
  ctx.fillStyle = '#06b6d4';
  ctx.fillRect(0, 0, 16, 512);
  ctx.fillRect(496, 0, 16, 512);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 12);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Alien Planet Crater & Crystal Surface Texture
 */
export function createUniversePlanetSurfaceTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep dark extraterrestrial basalt
  ctx.fillStyle = '#090514';
  ctx.fillRect(0, 0, 512, 512);

  // Cosmic crystal veins
  ctx.strokeStyle = 'rgba(168, 85, 247, 0.35)';
  ctx.lineWidth = 2;
  for (let i = 0; i < 20; i++) {
    ctx.beginPath();
    let cx = Math.random() * 512;
    let cy = Math.random() * 512;
    ctx.moveTo(cx, cy);
    for (let j = 0; j < 4; j++) {
      cx += (Math.random() - 0.5) * 120;
      cy += (Math.random() - 0.5) * 120;
      ctx.lineTo(cx, cy);
    }
    ctx.stroke();
  }

  // Lunar and Martian craters
  for (let i = 0; i < 35; i++) {
    const rx = Math.random() * 512;
    const ry = Math.random() * 512;
    const rad = 8 + Math.random() * 28;
    ctx.fillStyle = 'rgba(2, 6, 23, 0.7)';
    ctx.beginPath();
    ctx.arc(rx, ry, rad, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(99, 102, 241, 0.4)';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(3, 10);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Quantum Star Comet Board Texture
 */
export function createUniverseSpaceBoardTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Starlight deep void
  ctx.fillStyle = '#020617';
  ctx.fillRect(0, 0, 128, 512);

  // Carbon weave
  ctx.fillStyle = '#0f172a';
  for (let y = 0; y < 512; y += 8) {
    ctx.fillRect(0, y, 128, 4);
  }

  // Luminescent neon cyan & violet comet trails down center
  ctx.fillStyle = '#38bdf8';
  ctx.fillRect(60, 40, 8, 432);
  ctx.fillStyle = '#a855f7';
  ctx.fillRect(52, 60, 4, 392);
  ctx.fillRect(72, 60, 4, 392);

  // Neon glowing tip
  ctx.fillStyle = '#06b6d4';
  ctx.beginPath();
  ctx.arc(64, 30, 18, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Deep Forest Mossy Ground with Pine Needles & Soil
 */
export function createForestMossyFloorTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Rich dark loam earthen forest base
  ctx.fillStyle = '#0f2415';
  ctx.fillRect(0, 0, 512, 512);

  // Organic moss clumps
  const mossColors = ['#14532d', '#166534', '#15803d', '#1e3a1f', '#064e3b'];
  for (let i = 0; i < 70; i++) {
    ctx.fillStyle = mossColors[i % mossColors.length];
    ctx.beginPath();
    const mx = Math.random() * 512;
    const my = Math.random() * 512;
    const mr = 15 + Math.random() * 35;
    ctx.arc(mx, my, mr, 0, Math.PI * 2);
    ctx.fill();
  }

  // Pine needles scattered
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = 1.8;
  for (let i = 0; i < 180; i++) {
    const px = Math.random() * 512;
    const py = Math.random() * 512;
    const ang = Math.random() * Math.PI;
    const len = 8 + Math.random() * 12;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px + Math.cos(ang) * len, py + Math.sin(ang) * len);
    ctx.stroke();
  }

  // Glowing fairy spores
  ctx.fillStyle = 'rgba(74, 222, 128, 0.45)';
  for (let i = 0; i < 40; i++) {
    ctx.beginPath();
    ctx.arc(Math.random() * 512, Math.random() * 512, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 12);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Sacred Redwood Glade Plank Texture
 */
export function createForestWoodGladeTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Redwood timber base
  ctx.fillStyle = '#451a03';
  ctx.fillRect(0, 0, 512, 512);

  // Planks
  ctx.strokeStyle = '#291003';
  ctx.lineWidth = 4;
  for (let y = 0; y < 512; y += 48) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // Wood grain & moss in crevices
  ctx.fillStyle = 'rgba(21, 128, 61, 0.25)';
  for (let i = 0; i < 20; i++) {
    ctx.fillRect(Math.random() * 450, (i * 24) % 512, 60, 6);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(3, 8);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Red-and-White Checkered Banquet Tablecloth Texture for Dinner Time
 */
export function createDinnerTableclothTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  const tileSize = 64;
  for (let y = 0; y < 512; y += tileSize) {
    for (let x = 0; x < 512; x += tileSize) {
      const isRed = ((x / tileSize) + (y / tileSize)) % 2 === 0;
      ctx.fillStyle = isRed ? '#dc2626' : '#ffffff';
      ctx.fillRect(x, y, tileSize, tileSize);

      // Fabric cross-stitch weave
      ctx.fillStyle = isRed ? 'rgba(185, 28, 28, 0.4)' : 'rgba(241, 245, 249, 0.7)';
      for (let w = 0; w < tileSize; w += 8) {
        ctx.fillRect(x + w, y, 2, tileSize);
        ctx.fillRect(x, y + w, tileSize, 2);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(6, 16);
  texture.needsUpdate = true;
  return texture;
}

/**
 * Procedural Golden Damask Tablecloth Texture for Dinner Time alternate zone
 */
export function createDinnerGoldClothTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm cream banquet base
  ctx.fillStyle = '#fffbeb';
  ctx.fillRect(0, 0, 512, 512);

  // Gold damask diamond grid
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 3;
  for (let d = -512; d < 1024; d += 64) {
    ctx.beginPath();
    ctx.moveTo(d, 0);
    ctx.lineTo(d + 512, 512);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(d, 512);
    ctx.lineTo(d + 512, 0);
    ctx.stroke();
  }

  // Golden fleur florets at diamond centers
  ctx.fillStyle = '#b45309';
  for (let y = 32; y < 512; y += 64) {
    for (let x = 32; x < 512; x += 64) {
      ctx.beginPath();
      ctx.arc(x, y, 6, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(5, 12);
  texture.needsUpdate = true;
  return texture;
}

