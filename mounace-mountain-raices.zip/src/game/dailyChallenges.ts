/**
 * Daily Challenge System for Alpine Rush
 * Generates fresh daily missions with generous coin rewards.
 */

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  rewardCoins: number;
  completed: boolean;
  claimed: boolean;
  icon: string;
  type: 'distance' | 'tricks' | 'coins' | 'gates' | 'star' | 'score';
}

const STORAGE_KEY_PREFIX = 'alpine_rush_daily_challenges_';

export function getTodayDateKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function getDefaultChallengesForDate(dateKey: string): DailyChallenge[] {
  // Deterministic seed based on date
  const seed = dateKey.split('-').reduce((acc, part) => acc * 31 + parseInt(part, 10), 0);

  const missions: Omit<DailyChallenge, 'current' | 'completed' | 'claimed'>[] = [
    {
      id: `${dateKey}_distance`,
      title: 'Downhill Voyager',
      description: 'Race 1,000 meters in a single run',
      target: 1000,
      rewardCoins: 350,
      icon: '🏔️',
      type: 'distance',
    },
    {
      id: `${dateKey}_tricks`,
      title: 'Freestyle Prodigy',
      description: 'Land 5 aerial flips or spins',
      target: 5,
      rewardCoins: 400,
      icon: '🤸',
      type: 'tricks',
    },
    {
      id: `${dateKey}_star`,
      title: 'Starlight Collector',
      description: 'Grab a Shining Star power-up',
      target: 1,
      rewardCoins: 500,
      icon: '⭐',
      type: 'star',
    },
    {
      id: `${dateKey}_coins`,
      title: 'Gold Rush',
      description: 'Farm 35 coins across your runs',
      target: 35,
      rewardCoins: 300,
      icon: '🪙',
      type: 'coins',
    },
    {
      id: `${dateKey}_gates`,
      title: 'Slalom Master',
      description: 'Carve through 6 slalom gates',
      target: 6,
      rewardCoins: 350,
      icon: '🏁',
      type: 'gates',
    },
    {
      id: `${dateKey}_score`,
      title: 'High Velocity',
      description: 'Reach a run score of 2,500 points',
      target: 2500,
      rewardCoins: 450,
      icon: '⚡',
      type: 'score',
    },
  ];

  return missions.map((m) => ({
    ...m,
    current: 0,
    completed: false,
    claimed: false,
  }));
}

export function loadDailyChallenges(): DailyChallenge[] {
  const dateKey = getTodayDateKey();
  const raw = localStorage.getItem(`${STORAGE_KEY_PREFIX}${dateKey}`);
  if (raw) {
    try {
      const parsed = JSON.parse(raw) as DailyChallenge[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {
      // fallback
    }
  }

  const fresh = getDefaultChallengesForDate(dateKey);
  saveDailyChallenges(fresh);
  return fresh;
}

export function saveDailyChallenges(challenges: DailyChallenge[]): void {
  const dateKey = getTodayDateKey();
  try {
    localStorage.setItem(`${STORAGE_KEY_PREFIX}${dateKey}`, JSON.stringify(challenges));
  } catch (err) {
    console.error('Failed to save daily challenges', err);
  }
}

export function updateDailyChallengeProgress(
  type: DailyChallenge['type'],
  amount: number,
  isCumulative = false
): { updatedChallenges: DailyChallenge[]; newlyCompleted: DailyChallenge[] } {
  const challenges = loadDailyChallenges();
  const newlyCompleted: DailyChallenge[] = [];

  const updated = challenges.map((ch) => {
    if (ch.type === type && !ch.completed) {
      const newCurrent = isCumulative ? ch.current + amount : Math.max(ch.current, amount);
      const isNowCompleted = newCurrent >= ch.target;
      if (isNowCompleted && !ch.completed) {
        newlyCompleted.push({ ...ch, current: ch.target, completed: true });
      }
      return {
        ...ch,
        current: Math.min(ch.target, newCurrent),
        completed: isNowCompleted,
      };
    }
    return ch;
  });

  saveDailyChallenges(updated);
  return { updatedChallenges: updated, newlyCompleted };
}

export function claimDailyChallengeReward(challengeId: string): number {
  const challenges = loadDailyChallenges();
  let reward = 0;

  const updated = challenges.map((ch) => {
    if (ch.id === challengeId && ch.completed && !ch.claimed) {
      reward = ch.rewardCoins;
      return { ...ch, claimed: true };
    }
    return ch;
  });

  if (reward > 0) {
    saveDailyChallenges(updated);
  }

  return reward;
}

export function completeAllDailyChallengesAdmin(): number {
  const challenges = loadDailyChallenges();
  const updated = challenges.map((ch) => ({
    ...ch,
    current: ch.target,
    completed: true,
  }));
  saveDailyChallenges(updated);
  return updated.length;
}
