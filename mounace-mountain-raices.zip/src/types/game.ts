/**
 * Alpine Rush - Type Definitions
 */

export type CharacterId = 
  | 'alpine_blitz' 
  | 'frost_maverick' 
  | 'glacier_guardian' 
  | 'vortex_valkyrie' 
  | 'yeti_rider'
  | 'cyber_ninja'
  | 'solar_phoenix'
  | 'shadow_phantom'
  | 'blaze_rider'
  | 'arctic_wolf'
  | 'plasma_punk'
  | 'samurai_jack'
  | 'galaxy_nomad'
  | 'storm_striker'
  | 'mecha_titan'
  | 'dragon_emperor'
  | 'chrono_traveler'
  | 'sakura_ninja'
  | 'sugar_fairy'
  | 'neon_viper'
  | 'thunder_beast'
  | 'phantom_pirate'
  | 'crystal_queen'
  | 'cyber_samurai'
  | 'magma_colossus'
  | 'laser_raptor'
  | 'bubblegum_pop'
  | 'astro_monkey'
  | 'golden_pharaoh'
  | 'toxic_overload'
  | 'speed_demon'
  | 'polar_bear_king'
  | 'circuit_cyborg'
  | 'rainbow_unicorn'
  | 'shadow_assassin'
  // 40 Brand New Racers (Total: 75)
  | 'storm_dragon'
  | 'plasma_reaper'
  | 'cosmic_voyager'
  | 'crimson_valkyrie'
  | 'frostbite_specter'
  | 'shadow_blade'
  | 'thunder_claw'
  | 'solar_knight'
  | 'void_hunter'
  | 'neon_drifter'
  | 'cyber_panther'
  | 'glacier_beast'
  | 'phoenix_blaze'
  | 'toxic_phantom'
  | 'hyper_racer'
  | 'quantum_shifter'
  | 'iron_golem'
  | 'arctic_fox'
  | 'dune_runner'
  | 'blizzard_king'
  | 'aurora_maiden'
  | 'volcano_lord'
  | 'cyber_dj'
  | 'skull_rider'
  | 'candy_princess'
  | 'gummy_brawler'
  | 'steampunk_pilot'
  | 'emerald_assassin'
  | 'golden_gladiator'
  | 'ruby_enchantress'
  | 'sapphire_skater'
  | 'obsidian_warlord'
  | 'star_paladin'
  | 'ice_witch'
  | 'sandstorm_nomad'
  | 'gravity_breaker'
  | 'chrono_master'
  | 'spectral_monk'
  | 'frost_archer'
  | 'infinity_titan'
  // 75 New Racers (Total: 150 Racers!)
  | 'forest_ranger'
  | 'emerald_stag'
  | 'moss_wanderer'
  | 'sylvan_whisper'
  | 'ancient_druid'
  | 'pine_sentinel'
  | 'fern_stalker'
  | 'autumn_spirit'
  | 'canopy_glider'
  | 'timber_wolf'
  | 'woodland_sprite'
  | 'redwood_colossus'
  | 'lichen_stalker'
  | 'celestial_pegasus'
  | 'solar_flare'
  | 'nebula_seraph'
  | 'black_hole_rider'
  | 'comet_chaser'
  | 'quasar_queen'
  | 'pulsar_knight'
  | 'void_walker'
  | 'supernova_scout'
  | 'galactic_emperor'
  | 'starlight_wraith'
  | 'asteroid_miner'
  | 'meteor_striker'
  | 'lunar_huntress'
  | 'solar_valkyrie'
  | 'quantum_archer'
  | 'abyssal_kraken'
  | 'deep_sea_diver'
  | 'coral_guardian'
  | 'tsunami_surfer'
  | 'hydro_phantom'
  | 'arctic_seal'
  | 'polar_owl'
  | 'blizzard_elemental'
  | 'frost_giant'
  | 'crystal_golem'
  | 'aurora_shaman'
  | 'cyber_ronin'
  | 'neon_valkyrie'
  | 'synth_hacker'
  | 'matrix_drifter'
  | 'vector_rebel'
  | 'techno_mage'
  | 'quantum_specter'
  | 'laser_monk'
  | 'cyber_samurai_x'
  | 'overclock_racer'
  | 'candy_jester'
  | 'marshmallow_beast'
  | 'caramel_knight'
  | 'chocoberry_queen'
  | 'licorice_assassin'
  | 'donut_dasher'
  | 'sugar_rush_girl'
  | 'toffee_brawler'
  | 'bubble_baron'
  | 'macaron_maiden'
  | 'inferno_berserker'
  | 'ember_phoenix'
  | 'magma_drake'
  | 'ash_strider'
  | 'pyro_valkyrie'
  | 'sunfire_titan'
  | 'sand_scorpion'
  | 'oasis_wanderer'
  | 'mirage_assassin'
  | 'pharaoh_guard'
  | 'dune_falcon'
  | 'tomb_raider_rex'
  | 'thunder_tempest'
  | 'storm_valkyrie'
  | 'lightning_panther'
  | 'miss_russian';

export type DifficultyLevel = 'easy' | 'normal' | 'hard' | 'insane' | 'impossible';

export type CharacterRarity = 'common' | 'rare' | 'epic' | 'legendary' | 'mythic';

export type VehicleType = 'skis' | 'snowboard' | 'hoverboard' | 'yeti_stride' | 'roller_skates' | 'skateboard';

export type JacketPattern = 'solid' | 'stripes' | 'camo' | 'cyber' | 'chevron';

export interface CharacterCustomization {
  jacketColor: string;
  jacketPattern: JacketPattern;
  pantsColor: string;
  helmetColor: string;
  visorColor: string;
  boardColor: string;
  accentColor: string;
}

export interface CharacterDef {
  id: CharacterId;
  name: string;
  title: string;
  vehicleType: VehicleType;
  rarity?: CharacterRarity;
  description: string;
  specialAbility: string;
  stats: {
    speed: number;       // 1 - 10
    carving: number;     // 1 - 10 (handling)
    airtime: number;     // 1 - 10 (jump height/trick window)
    boost: number;       // 1 - 10 (nitro duration/recharge)
    resilience: number;  // 1 - 10 (shield/bump recovery)
  };
  unlockCost: number;     // 0 for free
  unlockRequirement?: string;
  defaultCustomization: CharacterCustomization;
}

export type BoxTier = 'bronze' | 'silver' | 'gold' | 'diamond' | 'mythic';

export interface BoxOdds {
  common: number;     // percentage (e.g. 70)
  rare: number;       // percentage (e.g. 24)
  epic: number;       // percentage (e.g. 5)
  legendary: number;  // percentage (e.g. 0.9)
  mythic: number;     // percentage (e.g. 0.1)
}

export interface MysteryBoxDef {
  id: BoxTier;
  name: string;
  subtitle: string;
  icon: string;
  badge?: string;
  color: string;
  glowColor: string;
  borderColor: string;
  costCoins: number;
  costGems: number;
  odds: BoxOdds;
  description: string;
}

export type GameStatus = 'title' | 'customize' | 'playing' | 'paused' | 'gameover';

export type PowerUpType = 'nitro' | 'shield' | 'magnet' | 'multiplier' | 'freeze' | 'star';

export interface ActivePowerUp {
  type: PowerUpType;
  duration: number;
  maxDuration: number;
}

export interface TrickEvent {
  name: string;
  points: number;
  rotationName?: string;
  timestamp: number;
}

export type WeatherType = 'clear_day' | 'sunset_glow' | 'heavy_blizzard' | 'aurora_night';

export interface WeatherInfo {
  type: WeatherType;
  name: string;
  icon: string;
  frostVignette: number;
  windSpeed: number;
}

export type GameModeId = 
  | 'classic'          // Pure downhill survival
  | 'bot_race'         // Race downhill against 3 AI rival bots
  | 'package_delivery' // Deliver fragile cargo across 5 checkpoints
  | 'coin_rush'        // Mega high-density coins & diamonds
  | 'slalom_gp'        // Gate precision slalom tournament
  | 'time_attack'      // Ticking countdown clock with time extensions
  | 'survival_storm'   // Intense falling meteors/boulders barrage
  | 'police_chase'     // Highway patrol cruiser in hot pursuit
  | 'laser_gauntlet'   // High-voltage laser fields to duck & jump
  | 'boss_nemesis';    // Colossal boss monster pursuit

export interface GameModeDef {
  id: GameModeId;
  name: string;
  subtitle: string;
  icon: string;
  badge: string;
  color: string;
  description: string;
  objective: string;
}

export interface RunStats {
  distance: number;       // meters
  speed: number;          // current km/h
  topSpeed: number;       // km/h
  score: number;
  multiplier: number;
  coinsCollected: number;
  gemsCollected: number;
  gatesPassed: number;
  tricksLanded: number;
  airtimeTotal: number;
  nearMisses: number;
  isDoubleCoinsActive?: boolean;
  currentZoneName?: string;
  zoneIndex?: number;
  lives?: number;
  maxLives?: number;
  mode?: GameModeId;
  botRank?: number;
  packageIntegrity?: number;
  packagesDelivered?: number;
  timeRemaining?: number;
  slalomStreak?: number;
}

export type MapTheme = 
  | 'snow'
  | 'beach'
  | 'halloween'
  | 'school'
  | 'cyber'
  | 'spring'
  | 'candy'
  | 'universe'
  | 'forest'
  | 'dinner_time';

export interface PlayerProgress {
  coins: number;
  gems: number;
  highScore: number;
  maxDistance: number;
  unlockedCharacters: CharacterId[];
  selectedCharacter: CharacterId;
  selectedMap: MapTheme;
  unlockedMaps: MapTheme[];
  customizations: Record<CharacterId, CharacterCustomization>;
  soundEnabled: boolean;
  musicEnabled: boolean;
  selectedDifficulty?: DifficultyLevel;
  selectedGameMode?: GameModeId;
  isVip?: boolean;
  lastDailyClaimDate?: string;
  dailyStreak?: number;
  lastSpinTimestamp?: number;
  
  // Permanent Shop Upgrades & Gear
  magnetLevel?: number;        // Level 1-10
  shieldCharges?: number;      // Extra shields (0-5)
  boostDurationLevel?: number; // Level 1-5
  nitroRechargeLevel?: number; // Level 1-5 (Faster boost regen)
  doubleCoinsPerma?: boolean;  // Permanent 2x Coin Token
  gliderWings?: boolean;       // Aero Glider Parachute Wings
  iceBreaker?: boolean;        // Ice Breaker Kinetic Shocker
  alpineGrips?: boolean;       // Pro Slalom Alpine Grips
  diamondMiner?: boolean;      // Diamond Miner Pickaxe
  forestCloak?: boolean;       // Camo Forest Cloak (reduces obstacle wipeout impact & grants coins)
  cosmicEngine?: boolean;      // Anti-Gravity Warp Engine (higher airtime trick multipliers)
  luckyCharm?: boolean;        // Golden Horseshoe (+25% lucky box & spin rewards)
  doubleGemsPerma?: boolean;   // Permanent 2x Gem Multiplier
  starlightThruster?: boolean; // Starlight Nitro Thruster (instant max boost recharge)
  selectedAuraTrail?: string;
  unlockedAuras?: string[];
}
