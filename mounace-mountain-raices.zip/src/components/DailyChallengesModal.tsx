import React, { useState, useEffect } from 'react';
import { 
  DailyChallenge, 
  loadDailyChallenges, 
  claimDailyChallengeReward, 
  getTodayDateKey 
} from '../game/dailyChallenges';
import { X, Award, CheckCircle2, Gift, Sparkles, ChevronRight, Clock } from 'lucide-react';
import { sound } from '../game/audio';

interface DailyChallengesModalProps {
  onClose: () => void;
  onRewardClaimed: (coins: number) => void;
}

export const DailyChallengesModal: React.FC<DailyChallengesModalProps> = ({
  onClose,
  onRewardClaimed,
}) => {
  const [challenges, setChallenges] = useState<DailyChallenge[]>([]);
  const [claimedAnimationId, setClaimedAnimationId] = useState<string | null>(null);

  useEffect(() => {
    setChallenges(loadDailyChallenges());
  }, []);

  const handleClaim = (challenge: DailyChallenge) => {
    if (!challenge.completed || challenge.claimed) return;

    const reward = claimDailyChallengeReward(challenge.id);
    if (reward > 0) {
      sound.playPowerUp();
      sound.playCoin();
      setClaimedAnimationId(challenge.id);
      setTimeout(() => setClaimedAnimationId(null), 1200);

      setChallenges(loadDailyChallenges());
      onRewardClaimed(reward);
    }
  };

  const totalRewardsAvailable = challenges.filter(c => c.completed && !c.claimed).reduce((sum, c) => sum + c.rewardCoins, 0);
  const completedCount = challenges.filter(c => c.completed).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-2xl shadow-lg shadow-amber-500/20">
              📅
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-race font-extrabold text-white tracking-wide">
                  DAILY CHALLENGES
                </h2>
                <span className="text-xs font-race font-bold bg-amber-500/20 border border-amber-500/40 text-amber-300 px-2.5 py-0.5 rounded-full">
                  {completedCount}/{challenges.length} DONE
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-0.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Resets every midnight · Date: {getTodayDateKey()}</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl transition-all border border-slate-700 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Claim All Banner if rewards ready */}
        {totalRewardsAvailable > 0 && (
          <div className="bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/20 border-b border-amber-500/30 px-6 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-amber-200 font-medium">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span>You have completed objectives ready to claim!</span>
            </div>
            <div className="font-race font-bold text-amber-400 flex items-center gap-1">
              <span>+{totalRewardsAvailable}</span>
              <span>🪙</span>
            </div>
          </div>
        )}

        {/* Challenges List */}
        <div className="p-6 overflow-y-auto space-y-3.5 flex-1 custom-scrollbar">
          {challenges.map((ch) => {
            const pct = Math.min(100, Math.round((ch.current / ch.target) * 100));
            const isClaimedAnim = claimedAnimationId === ch.id;

            return (
              <div
                key={ch.id}
                className={`p-4 rounded-2xl border transition-all duration-300 ${
                  ch.claimed
                    ? 'bg-slate-950/60 border-slate-800/80 opacity-70'
                    : ch.completed
                    ? 'bg-gradient-to-r from-amber-950/30 via-slate-900 to-slate-900 border-amber-500/50 shadow-lg shadow-amber-500/10'
                    : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3.5 min-w-0">
                    <span className="text-3xl flex-shrink-0 select-none">{ch.icon}</span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-race font-bold text-base text-white truncate">
                          {ch.title}
                        </h4>
                        {ch.completed && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">{ch.description}</p>
                    </div>
                  </div>

                  {/* Reward & Claim Button */}
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="flex items-center gap-1.5 bg-slate-950/70 border border-slate-800 px-3 py-1.5 rounded-xl font-race font-bold text-amber-300 text-sm">
                      <span>🪙</span>
                      <span>+{ch.rewardCoins}</span>
                    </div>

                    {ch.claimed ? (
                      <span className="text-xs font-race font-bold text-emerald-400/80 px-3 py-1.5 rounded-xl bg-emerald-950/40 border border-emerald-800/30">
                        CLAIMED
                      </span>
                    ) : ch.completed ? (
                      <button
                        onClick={() => handleClaim(ch)}
                        className={`px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 active:scale-95 text-slate-950 font-race font-black text-xs rounded-xl shadow-lg shadow-amber-500/30 transition-all flex items-center gap-1.5 cursor-pointer ${
                          isClaimedAnim ? 'animate-bounce' : ''
                        }`}
                      >
                        <Gift className="w-4 h-4" />
                        <span>CLAIM</span>
                      </button>
                    ) : (
                      <span className="text-xs font-race text-slate-500 px-3 py-1.5 rounded-xl bg-slate-800/40">
                        {ch.current}/{ch.target}
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="mt-3 flex items-center gap-3">
                  <div className="flex-1 bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        ch.completed
                          ? 'bg-gradient-to-r from-amber-400 to-emerald-400'
                          : 'bg-gradient-to-r from-cyan-500 to-blue-500'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-race font-bold text-slate-400 tabular-nums w-10 text-right">
                    {pct}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-xs text-slate-400">
          <span>Complete all challenges to earn up to 2,200 bonus coins daily!</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-race font-bold rounded-xl transition-all cursor-pointer"
          >
            BACK TO RACING
          </button>
        </div>
      </div>
    </div>
  );
};
