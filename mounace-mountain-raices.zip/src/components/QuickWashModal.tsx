import React, { useRef, useState, useEffect } from 'react';
import { sound } from '../game/audio';
import { Sparkles, Coins, X, Clock, RotateCcw, Check, Droplets } from 'lucide-react';

interface QuickWashModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  onReward: (rewardCoins: number, rewardGems: number) => void;
  onClose: () => void;
}

export const QuickWashModal: React.FC<QuickWashModalProps> = ({
  coins,
  gems,
  isVip = false,
  onReward,
  onClose,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [cleanedPercent, setCleanedPercent] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10);
  const [gameState, setGameState] = useState<'ready' | 'playing' | 'won' | 'lost'>('ready');
  const [isDrawing, setIsDrawing] = useState(false);

  const ENTRY_COST_GEMS = isVip ? 0 : 10;
  const canAfford = isVip || gems >= ENTRY_COST_GEMS;

  const timerRef = useRef<number | null>(null);
  const isWonRef = useRef(false);

  // Generate muddy texture onto the canvas
  const initMudLayer = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    ctx.globalCompositeOperation = 'source-over';

    // Rich mud base color
    ctx.fillStyle = '#451a03';
    ctx.fillRect(0, 0, w, h);

    // Mud splatter & shades
    for (let i = 0; i < 90; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = 15 + Math.random() * 45;
      const shade = Math.random() > 0.5 ? '#78350f' : '#3f1807';
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = shade;
      ctx.fill();
    }

    // Dirt spots and gravel specks
    for (let i = 0; i < 150; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = 2 + Math.random() * 6;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = Math.random() > 0.5 ? '#92400e' : '#1c0a00';
      ctx.fill();
    }

    setCleanedPercent(0);
    isWonRef.current = false;
  };

  useEffect(() => {
    initMudLayer();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // 10 second countdown timer
  useEffect(() => {
    if (gameState === 'playing') {
      timerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            if (timerRef.current) clearInterval(timerRef.current);
            if (!isWonRef.current) {
              setGameState('lost');
              sound.playCrash();
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (timerRef.current) clearInterval(timerRef.current);
      };
    }
  }, [gameState]);

  // Check how much mud was erased
  const checkCleanProgress = () => {
    const canvas = canvasRef.current;
    if (!canvas || gameState !== 'playing') return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Sample 20x15 grid of points
    const stepX = w / 20;
    const stepY = h / 15;
    let transparentCount = 0;
    let totalSamples = 0;

    for (let x = stepX / 2; x < w; x += stepX) {
      for (let y = stepY / 2; y < h; y += stepY) {
        totalSamples++;
        const pixel = ctx.getImageData(Math.floor(x), Math.floor(y), 1, 1).data;
        if (pixel[3] < 50) {
          transparentCount++;
        }
      }
    }

    const percent = Math.min(100, Math.round((transparentCount / totalSamples) * 100));
    setCleanedPercent(percent);

    if (percent >= 80 && !isWonRef.current) {
      isWonRef.current = true;
      setGameState('won');
      if (timerRef.current) clearInterval(timerRef.current);
      sound.playStarChime();
      sound.playZoneTransition();
      // Reward 600 coins and 5 bonus gems (minus 10 gem entry fee = net -5 gems, +600 coins)
      onReward(600, 5);
    }
  };

  const eraseAt = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (clientX - rect.left) * scaleX;
    const y = (clientY - rect.top) * scaleY;

    ctx.globalCompositeOperation = 'destination-out';
    ctx.beginPath();
    ctx.arc(x, y, 32, 0, Math.PI * 2);
    ctx.fill();

    checkCleanProgress();
  };

  const handleStart = () => {
    if (!canAfford) {
      sound.playCrash();
      return;
    }
    if (!isVip) {
      onReward(0, -ENTRY_COST_GEMS);
    }
    initMudLayer();
    setTimeLeft(10);
    setGameState('playing');
    sound.playPowerUp();
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (gameState === 'ready') handleStart();
    setIsDrawing(true);
    eraseAt(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    eraseAt(e.clientX, e.clientY);
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (gameState === 'ready') handleStart();
    setIsDrawing(true);
    const touch = e.touches[0];
    eraseAt(touch.clientX, touch.clientY);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const touch = e.touches[0];
    eraseAt(touch.clientX, touch.clientY);
  };

  const handleTouchEnd = () => {
    setIsDrawing(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-blue-500/30 rounded-3xl shadow-2xl p-6 text-white flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-300 text-xs font-bold mb-1">
            <Droplets className="w-3.5 h-3.5" />
            SWIPE QUICK WASH
          </div>
          <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-blue-200 via-sky-300 to-cyan-400 font-race tracking-wider">
            QUICK CAR WASH
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Quickly swipe like an eraser to wipe off 80% of mud in 10 seconds! Entry: <strong className="text-cyan-300 font-bold">10 💎</strong>
          </p>
        </div>

        {/* Balance & Status Indicators */}
        <div className="w-full flex items-center justify-between px-4 py-2 bg-slate-800/60 rounded-2xl border border-slate-700/60 text-xs mb-3 font-race">
          <div className="flex items-center gap-3">
            <span className="text-amber-300 font-bold">🪙 {coins.toLocaleString()}</span>
            <span className="text-cyan-300 font-bold">💎 {gems.toLocaleString()}</span>
          </div>

          <div className="flex items-center gap-2">
            <Clock className={`w-4 h-4 ${timeLeft <= 3 ? 'text-rose-400 animate-pulse' : 'text-sky-400'}`} />
            <span>Time Left: <strong className={`text-sm ${timeLeft <= 3 ? 'text-rose-400' : 'text-white'}`}>{timeLeft}s</strong></span>
          </div>

          <div>
            <span>Cleaned: <strong className="text-emerald-400 text-sm">{cleanedPercent}%</strong></span>
          </div>
        </div>

        {/* Canvas Mud Area with clean Sports Car beneath */}
        <div className="relative w-full max-w-[360px] h-52 bg-slate-800 rounded-2xl overflow-hidden border-2 border-slate-700 shadow-inner flex items-center justify-center select-none touch-none">
          {/* Shiny Sports Car Silhouette & Background Beneath */}
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-950 via-slate-900 to-cyan-950 flex flex-col items-center justify-center pointer-events-none">
            <div className="text-7xl filter drop-shadow-[0_10px_20px_rgba(56,189,248,0.5)]">
              🏎️
            </div>
            <div className="text-xs font-race font-extrabold text-cyan-300 tracking-widest mt-1">
              ✨ SHINY CUSTOM RACER ✨
            </div>
          </div>

          {/* Mud Overlay Canvas */}
          <canvas
            ref={canvasRef}
            width={360}
            height={208}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            className="absolute inset-0 w-full h-full cursor-crosshair active:cursor-grabbing z-10"
          />

          {/* Start Screen Overlay */}
          {gameState === 'ready' && (
            <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-sm z-20 flex flex-col items-center justify-center p-4 text-center">
              <span className="text-3xl mb-1">🧽</span>
              <p className="text-xs text-slate-200 font-bold mb-3 font-race">
                Ready to wipe off the mud? Cost: 10 💎
              </p>
              <button
                onClick={handleStart}
                disabled={!canAfford}
                className={`py-2 px-5 rounded-xl font-race font-black text-xs tracking-wider transition-all cursor-pointer ${
                  canAfford
                    ? 'bg-gradient-to-r from-blue-500 to-cyan-400 text-slate-950 shadow-lg shadow-blue-500/30 hover:scale-105 active:scale-95'
                    : 'bg-rose-950/80 border border-rose-800 text-rose-300 cursor-not-allowed'
                }`}
              >
                {canAfford ? 'START CLEANING (10 💎)' : 'NEED 10 💎'}
              </button>
            </div>
          )}

          {/* Won Overlay */}
          {gameState === 'won' && (
            <div className="absolute inset-0 bg-emerald-950/85 backdrop-blur-md z-20 flex flex-col items-center justify-center p-4 text-center animate-in zoom-in-95">
              <Sparkles className="w-8 h-8 text-emerald-400 mb-1 animate-bounce" />
              <h3 className="text-lg font-race font-black text-emerald-300">CAR FULLY CLEANED!</h3>
              <p className="text-xs text-white font-bold font-race mt-1">
                +600 COINS &amp; +5 💎 WON!
              </p>
              <button
                onClick={handleStart}
                disabled={!canAfford}
                className="mt-3 py-1.5 px-4 bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-race font-black text-xs rounded-xl shadow-lg cursor-pointer"
              >
                WASH AGAIN (10 💎)
              </button>
            </div>
          )}

          {/* Lost Overlay */}
          {gameState === 'lost' && (
            <div className="absolute inset-0 bg-rose-950/85 backdrop-blur-md z-20 flex flex-col items-center justify-center p-4 text-center animate-in zoom-in-95">
              <span className="text-3xl mb-1">⏳</span>
              <h3 className="text-base font-race font-black text-rose-300">TIME RAN OUT!</h3>
              <p className="text-xs text-slate-300 font-race mt-1">
                Cleaned {cleanedPercent}% (needed 80%)
              </p>
              <button
                onClick={handleStart}
                disabled={!canAfford}
                className="mt-3 py-1.5 px-4 bg-amber-400 hover:bg-amber-300 text-slate-950 font-race font-black text-xs rounded-xl shadow-lg cursor-pointer"
              >
                TRY AGAIN (10 💎)
              </button>
            </div>
          )}
        </div>

        {/* Progress Bar */}
        <div className="w-full max-w-[360px] mt-3">
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-700">
            <div
              className="bg-gradient-to-r from-blue-400 to-emerald-400 h-full rounded-full transition-all duration-75"
              style={{ width: `${cleanedPercent}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
