import React, { useEffect, useState } from 'react';
import { sound } from '../game/audio';
import { getSavedLanguage, t } from '../game/i18n';

interface HalloweenJumpscareModalProps {
  onFinished: () => void;
}

export const HalloweenJumpscareModal: React.FC<HalloweenJumpscareModalProps> = ({ onFinished }) => {
  const [phase, setPhase] = useState<'flash' | 'lunge' | 'fade'>('flash');
  const lang = getSavedLanguage();

  useEffect(() => {
    // Play the horrific jumpscare sound hit
    sound.playJumpscare();

    // Visual sequence
    const t1 = setTimeout(() => setPhase('lunge'), 100);
    const t2 = setTimeout(() => setPhase('fade'), 1600);
    const t3 = setTimeout(() => onFinished(), 1950);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onFinished]);

  return (
    <div 
      onClick={onFinished}
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center select-none overflow-hidden cursor-pointer transition-opacity duration-300 ${
        phase === 'fade' ? 'opacity-0' : 'opacity-100'
      } bg-black`}
    >
      {/* 1. Flashing Blood Red & Necromancer Purple Strobe */}
      <div className="absolute inset-0 bg-gradient-radial from-red-600/60 via-purple-950/90 to-black animate-pulse pointer-events-none" />

      {/* Screen flash strobe */}
      <div className="absolute inset-0 bg-red-600/30 mix-blend-overlay animate-ping pointer-events-none" />

      {/* Scary Vignette border */}
      <div className="absolute inset-0 border-[16px] sm:border-[28px] border-red-900/80 shadow-[inset_0_0_80px_rgba(220,38,38,0.9)] pointer-events-none" />

      {/* 2. Terrifying Animated Screaming Witch & Pumpkin Lunging to the Screen */}
      <div className={`relative z-10 flex flex-col items-center justify-center transition-all duration-300 transform ${
        phase === 'lunge' 
          ? 'scale-110 sm:scale-125 rotate-1 animate-bounce' 
          : 'scale-90 rotate-[-4deg]'
      }`}>
        <svg 
          viewBox="0 0 320 320" 
          className="w-64 h-64 sm:w-80 sm:h-80 drop-shadow-[0_0_40px_rgba(239,68,68,0.9)]"
        >
          <defs>
            <radialGradient id="witchGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#ef4444" />
              <stop offset="60%" stopColor="#7e22ce" />
              <stop offset="100%" stopColor="#000000" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Sinister Aura */}
          <circle cx="160" cy="160" r="140" fill="url(#witchGlow)" opacity="0.6" />

          {/* Witch Pointy Hat */}
          <polygon points="160,20 80,140 240,140" fill="#0f172a" stroke="#a855f7" strokeWidth="4" />
          <polygon points="160,20 180,45 155,70 170,95 140,140" fill="#3b0764" />
          {/* Hat Brim */}
          <ellipse cx="160" cy="140" rx="95" ry="18" fill="#18181b" stroke="#ef4444" strokeWidth="3" />
          {/* Hat Band with glowing buckle */}
          <rect x="135" y="125" width="50" height="14" fill="#a855f7" rx="3" />
          <rect x="150" y="127" width="20" height="10" fill="#facc15" rx="2" />

          {/* Witch Green/Pale Face */}
          <ellipse cx="160" cy="180" rx="55" ry="50" fill="#15803d" stroke="#14532d" strokeWidth="4" />

          {/* Stringy Wild Hair */}
          <path d="M105,140 Q85,190 90,250 Q105,210 115,170" fill="#a855f7" />
          <path d="M215,140 Q235,190 230,250 Q215,210 205,170" fill="#a855f7" />

          {/* Terrifying Glowing Bloodshot Eyes */}
          <ellipse cx="138" cy="175" rx="14" ry="16" fill="#fef08a" stroke="#dc2626" strokeWidth="3" />
          <ellipse cx="182" cy="175" rx="14" ry="16" fill="#fef08a" stroke="#dc2626" strokeWidth="3" />
          {/* Slit Pupils */}
          <ellipse cx="138" cy="175" rx="4" ry="12" fill="#7f1d1d" />
          <ellipse cx="182" cy="175" rx="4" ry="12" fill="#7f1d1d" />

          {/* Pointy Crooked Nose */}
          <polygon points="160,175 185,195 160,200" fill="#166534" />
          {/* Wart */}
          <circle cx="178" cy="192" r="3.5" fill="#14532d" />

          {/* Gaping Screaming Mouth with sharp fangs */}
          <path d="M130,205 Q160,255 190,205 Z" fill="#000000" stroke="#dc2626" strokeWidth="3" />
          {/* Sharp Fangs */}
          <polygon points="140,205 145,218 150,205" fill="#ffffff" />
          <polygon points="170,205 175,218 180,205" fill="#ffffff" />
          <polygon points="155,230 160,215 165,230" fill="#ffffff" />

          {/* Wicked Flying Claws */}
          <path d="M60,220 L100,205 L110,225" stroke="#15803d" strokeWidth="8" strokeLinecap="round" />
          <path d="M260,220 L220,205 L210,225" stroke="#15803d" strokeWidth="8" strokeLinecap="round" />
          {/* Long Black Nails */}
          <polygon points="55,220 70,215 65,225" fill="#000000" />
          <polygon points="265,220 250,215 255,225" fill="#000000" />
        </svg>

        {/* Screaming Horror Text */}
        <div className="text-center mt-3 px-4">
          <h1 className="text-3xl sm:text-5xl font-black font-race text-red-500 tracking-wider drop-shadow-[0_0_25px_rgba(239,68,68,1)] uppercase animate-pulse">
            {t('jumpscareTitle', lang)}
          </h1>
          <p className="mt-1 font-race font-extrabold text-sm sm:text-lg text-amber-400 tracking-widest drop-shadow-[0_0_15px_rgba(245,158,11,0.8)] uppercase">
            {t('jumpscareSub', lang)}
          </p>
          <div className="mt-3 inline-block px-3 py-1 rounded-full bg-red-950/80 border border-red-500/50 text-red-300 font-race text-[10px] sm:text-xs">
            TAP ANYWHERE TO CONTINUE &bull; 💀
          </div>
        </div>
      </div>
    </div>
  );
};
