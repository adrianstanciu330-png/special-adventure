import React from 'react';
import { sound } from '../game/audio';
import { Crown, Sparkles, Coins, Zap, ShieldCheck, X, Check, Gift } from 'lucide-react';

interface VipModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  onBuyVip: () => void;
  onClose: () => void;
}

export const VipModal: React.FC<VipModalProps> = ({
  coins,
  gems,
  isVip = false,
  onBuyVip,
  onClose,
}) => {
  const VIP_COST_GEMS = 1000;
  const canAfford = gems >= VIP_COST_GEMS;

  const handleBuy = () => {
    if (!canAfford && !isVip) {
      sound.playCrash();
      return;
    }
    sound.playStarChime();
    sound.playDoubleCoins();
    sound.playZoneTransition();
    onBuyVip();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-amber-950/90 via-slate-900 to-slate-950 border-2 border-amber-400/80 rounded-3xl shadow-[0_0_50px_rgba(245,158,11,0.35)] p-6 text-white flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Crown Icon Header */}
        <div className="relative mb-3 flex flex-col items-center">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 flex items-center justify-center text-slate-950 shadow-2xl shadow-amber-500/50 animate-pulse">
            <Crown className="w-12 h-12 stroke-[2.5]" />
          </div>
          <div className="absolute -bottom-2 bg-slate-950 px-3 py-0.5 rounded-full border border-amber-400 text-[10px] font-race font-black text-amber-300 uppercase tracking-widest">
            {isVip ? '👑 VIP ACTIVE' : 'LIFETIME STATUS'}
          </div>
        </div>

        {/* Title */}
        <h2 className="text-3xl font-black font-race text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-200 to-orange-400 tracking-wider text-center">
          {isVip ? 'V.I.P CLUB MEMBER' : 'BECOME A V.I.P'}
        </h2>
        <p className="text-xs text-amber-200/80 text-center mt-1 max-w-sm">
          Unlock the ultimate high-roller experience with double rewards and 100% free access to everything!
        </p>

        {/* Current Currencies */}
        <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-1.5 rounded-full border border-slate-800 text-xs my-3 font-race">
          <span className="flex items-center gap-1 text-amber-300 font-bold">
            🪙 {coins.toLocaleString()}
          </span>
          <span className="flex items-center gap-1 text-cyan-300 font-bold">
            💎 {gems.toLocaleString()}
          </span>
        </div>

        {/* Perks Grid */}
        <div className="w-full bg-slate-950/70 border border-amber-500/30 rounded-2xl p-4 my-2 space-y-2.5 text-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 text-amber-300 rounded-xl flex-shrink-0">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <div className="font-race font-extrabold text-white text-sm">
                +1,000,000 COINS INSTANT CASH!
              </div>
              <div className="text-[11px] text-slate-400">
                Immediately credited to your bank account upon activating VIP!
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-300 rounded-xl flex-shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-race font-extrabold text-emerald-300 text-sm">
                2X ADVENTURE SCORE &amp; 2X COINS!
              </div>
              <div className="text-[11px] text-slate-400">
                All distance points, stunts, and coins collected in runs are permanently doubled!
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/20 text-cyan-300 rounded-xl flex-shrink-0">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <div className="font-race font-extrabold text-cyan-300 text-sm">
                EVERYTHING IS 100% FREE!
              </div>
              <div className="text-[11px] text-slate-400">
                All 5 Worlds, all 15 Racers &amp; Gear, and all 5 Mini-Games cost 0 diamonds/coins!
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/20 text-purple-300 rounded-xl flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-race font-extrabold text-purple-300 text-sm">
                EXCLUSIVE GOLDEN CROWN BADGE
              </div>
              <div className="text-[11px] text-slate-400">
                Golden VIP distinction displayed on your racer, HUD, and leaderboards!
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="w-full mt-3">
          {isVip ? (
            <div className="w-full py-3.5 bg-gradient-to-r from-amber-500/30 to-yellow-500/30 border border-amber-400 rounded-2xl flex items-center justify-center gap-2 text-amber-300 font-race font-black text-sm">
              <Check className="w-5 h-5 text-emerald-400" />
              <span>V.I.P ACTIVE &mdash; ALL PERKS &amp; FREE UNLOCKS ENABLED!</span>
            </div>
          ) : (
            <button
              onClick={handleBuy}
              disabled={!canAfford}
              className={`w-full py-4 px-6 rounded-2xl font-race font-black text-base tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl ${
                canAfford
                  ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 shadow-amber-500/30 hover:scale-[1.02] active:scale-[0.98]'
                  : 'bg-slate-900 border border-rose-800 text-rose-300 cursor-not-allowed'
              }`}
            >
              <Crown className="w-5 h-5 fill-current" />
              {canAfford ? (
                <span>ACTIVATE V.I.P (COST: 1,000 💎)</span>
              ) : (
                <span>NEED {VIP_COST_GEMS - gems} MORE 💎 (COST: 1,000 💎)</span>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
