import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, Mountain, ArrowRight, Zap, Flame, Shield, Compass, Gauge } from 'lucide-react';
import { sound } from '../game/audio';

interface LoadingScreenProps {
  onLoaded: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onLoaded }) => {
  const [progress, setProgress] = useState(0);
  const [tipIndex, setTipIndex] = useState(0);
  const chimeMilestones = useRef<Set<number>>(new Set());

  const tips = [
    'Waxing downhill twin-tip boards & tuning edge carve arcs...',
    '🌸 Blooming cherry blossoms & gearing up spring rollerblades...',
    '🍬 Heating up pink frosting slopes & chocolate gummy waterfalls...',
    '🪦 Lighting pumpkin lanterns & warning the cemetery witch...',
    '🏫 Polishing classroom hallway desks & sharpening ruler chase...',
    '🏙️ Powering neon cyber highway lasers & sub-bass arcade synthesizers...',
    '⚡ Reaching 10 points automatically activates DOUBLE COINS frenzy!',
    '🏔️ Calibrating Mount Frostbite summit gates at 3,850 meters...',
  ];

  useEffect(() => {
    // Dynamic progressive ramp up
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        // Organic pacing: fast burst, slight pause around 70%, then rush to 100%
        let delta = Math.floor(Math.random() * 6) + 3;
        if (prev > 65 && prev < 75) delta = Math.floor(Math.random() * 3) + 1;
        if (prev > 85) delta = Math.floor(Math.random() * 8) + 5;
        return Math.min(100, prev + delta);
      });
    }, 95);

    const tipInterval = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % tips.length);
    }, 1100);

    return () => {
      clearInterval(interval);
      clearInterval(tipInterval);
    };
  }, []);

  // Sound chimes on milestones
  useEffect(() => {
    if (progress >= 25 && !chimeMilestones.current.has(25)) {
      chimeMilestones.current.add(25);
      sound.playGate();
    }
    if (progress >= 50 && !chimeMilestones.current.has(50)) {
      chimeMilestones.current.add(50);
      sound.playGate();
    }
    if (progress >= 75 && !chimeMilestones.current.has(75)) {
      chimeMilestones.current.add(75);
      sound.playGate();
    }
    if (progress === 100) {
      sound.playStarChime();
      const timer = setTimeout(() => {
        onLoaded();
      }, 450);
      return () => clearTimeout(timer);
    }
  }, [progress, onLoaded]);

  // Telemetry simulation
  const simulatedSpeed = Math.floor(20 + (progress / 100) * 148);
  const simulatedAltitude = Math.floor(3850 - (progress / 100) * 1620);
  const gearNumber = Math.min(6, Math.floor(1 + (progress / 100) * 5.2));

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-between items-center bg-[#050814] select-none overflow-hidden p-4 sm:p-6">
      {/* 1. Deep Cyber-Alpine Sky with Aurora Wave Gradients */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#060a17] via-[#0b1736] to-[#12284c] pointer-events-none" />
      
      {/* Neon Aurora Glow Wave */}
      <div className="absolute top-0 inset-x-0 h-96 bg-gradient-to-r from-emerald-500/15 via-cyan-500/20 to-purple-600/20 blur-3xl pointer-events-none animate-pulse" />

      {/* Cyber Grid Horizon */}
      <div 
        className="absolute inset-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(to right, rgba(56, 189, 248, 0.15) 1px, transparent 1px), linear-gradient(to bottom, rgba(56, 189, 248, 0.15) 1px, transparent 1px)',
          backgroundSize: '40px 40px',
          transform: 'perspective(400px) rotateX(60deg) translateY(120px)',
        }}
      />

      {/* 2. Stylized Vector Mountain Range & Animated Downhill Carve */}
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
        <svg 
          viewBox="0 0 1000 650" 
          className="w-full h-full object-cover"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            {/* Golden Neon Eclipse Sun */}
            <radialGradient id="neonSunGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="45%" stopColor="#f59e0b" />
              <stop offset="85%" stopColor="#ef4444" />
              <stop offset="100%" stopColor="#9333ea" stopOpacity="0" />
            </radialGradient>

            {/* Back Mountain Gradient */}
            <linearGradient id="backMtnGradCool" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
              <stop offset="70%" stopColor="#0c4a6e" />
              <stop offset="100%" stopColor="#082f49" />
            </linearGradient>

            {/* Mid Snowy Peak */}
            <linearGradient id="midSlopeGradCool" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f0f9ff" />
              <stop offset="30%" stopColor="#bae6fd" />
              <stop offset="70%" stopColor="#0284c7" />
              <stop offset="100%" stopColor="#0369a1" />
            </linearGradient>

            {/* Fore Track Glow Slope */}
            <linearGradient id="trackForeGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="40%" stopColor="#e0f2fe" />
              <stop offset="80%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>

            {/* Board Trail Neon Blur */}
            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="5" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Distant Star Constellations */}
          <circle cx="120" cy="80" r="1.5" fill="#ffffff" opacity="0.8" />
          <circle cx="240" cy="110" r="2" fill="#38bdf8" opacity="0.9" />
          <circle cx="390" cy="65" r="1.2" fill="#facc15" opacity="0.7" />
          <circle cx="580" cy="90" r="2" fill="#ffffff" opacity="0.9" />
          <circle cx="820" cy="70" r="1.8" fill="#ec4899" opacity="0.8" />
          <circle cx="910" cy="120" r="1.5" fill="#38bdf8" opacity="0.8" />

          {/* Giant Retro Alpine Sun */}
          <circle cx="760" cy="190" r="125" fill="url(#neonSunGrad)" />

          {/* Far Majestic Peaks */}
          <polygon points="60,430 240,160 410,430" fill="url(#backMtnGradCool)" opacity="0.65" />
          <polygon points="240,160 280,225 240,250 200,225" fill="#ffffff" opacity="0.95" />

          <polygon points="340,460 560,120 780,460" fill="url(#backMtnGradCool)" opacity="0.8" />
          <polygon points="560,120 620,195 560,230 500,195" fill="#ffffff" opacity="0.95" />

          <polygon points="690,480 890,190 1060,480" fill="url(#backMtnGradCool)" opacity="0.65" />
          <polygon points="890,190 925,240 890,265 860,240" fill="#ffffff" opacity="0.9" />

          {/* Mid Layer Curving Ridges & Snowy Chalets */}
          <path d="M-20,440 Q240,310 500,410 T1040,370 L1040,650 L-20,650 Z" fill="url(#midSlopeGradCool)" opacity="0.9" />

          {/* Pine Trees with Snow Caps */}
          <polygon points="110,400 125,340 140,400" fill="#064e3b" />
          <polygon points="115,365 125,325 135,365" fill="#f8fafc" />
          <polygon points="200,420 215,360 230,420" fill="#047857" />
          <polygon points="320,410 335,350 350,410" fill="#064e3b" />
          <polygon points="840,380 855,320 870,380" fill="#064e3b" />
          <polygon points="900,410 915,350 930,410" fill="#047857" />

          {/* Main Downhill Track Slope */}
          <path 
            d="M-50,210 Q280,370 520,440 T1050,550 L1050,680 L-50,680 Z" 
            fill="url(#trackForeGrad)" 
          />

          {/* Dynamic Laser Carve Tracks */}
          <path d="M-10,270 Q300,400 560,460 T1020,550" stroke="#38bdf8" strokeWidth="6" fill="none" opacity="0.7" strokeDasharray="20 14" filter="url(#neonGlow)" />
          <path d="M-30,290 Q280,420 540,480 T1010,570" stroke="#f59e0b" strokeWidth="4" fill="none" opacity="0.5" />

          {/* ================= ANIMATED RACER ON SLOPE ================= */}
          <g 
            transform={`translate(${140 + progress * 6.2}, ${260 + progress * 2.5}) rotate(${-12 + Math.sin(progress * 0.3) * 6})`}
            filter="url(#neonGlow)"
          >
            {/* Billowing Nitro & Snow Spray Wake */}
            <g className="animate-pulse">
              <ellipse cx="-55" cy="24" rx="34" ry="14" fill="#38bdf8" opacity="0.7" />
              <ellipse cx="-85" cy="18" rx="26" ry="10" fill="#facc15" opacity="0.6" />
              <ellipse cx="-110" cy="12" rx="20" ry="7" fill="#ec4899" opacity="0.5" />
              <circle cx="-60" cy="10" r="8" fill="#ffffff" />
              <circle cx="-90" cy="5" r="6" fill="#ffffff" />
              <circle cx="-125" cy="2" r="4" fill="#38bdf8" />
            </g>

            {/* Glowing High-Performance Carve Board */}
            <path 
              d="M-55,26 C-45,30 40,30 58,19 C64,15 52,19 25,22 C-22,24 -50,24 -55,26 Z" 
              fill="#f59e0b" 
              stroke="#fbbf24" 
              strokeWidth="3.5"
            />
            {/* Neon Speed Stripe on Board */}
            <path d="M-35,24 L42,20" stroke="#38bdf8" strokeWidth="5" strokeLinecap="round" />
            <path d="M-20,24 L25,21" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />

            {/* Racer Legs */}
            <path d="M-14,20 L-9,3" stroke="#0f172a" strokeWidth="10" strokeLinecap="round" />
            <path d="M14,18 L9,3" stroke="#0f172a" strokeWidth="10" strokeLinecap="round" />

            {/* Racer Torso & Futuristic Aero Jacket */}
            <ellipse cx="0" cy="-12" rx="17" ry="19" fill="#0284c7" stroke="#38bdf8" strokeWidth="2.5" />
            <rect x="-3.5" y="-23" width="7" height="19" fill="#facc15" rx="3.5" />

            {/* Fluttering Neon Bandana / Scarf */}
            <path 
              d="M-8,-24 C-24,-29 -40,-23 -58,-32 C-44,-21 -28,-23 -8,-20 Z" 
              fill="#ec4899" 
              className="animate-pulse"
            />

            {/* Racer Helmet */}
            <circle cx="2" cy="-35" r="15" fill="#0f172a" stroke="#38bdf8" strokeWidth="1.5" />
            {/* Mirrored Gold Visor */}
            <rect x="5" cy="-39" width="14" height="9" rx="4.5" fill="#facc15" stroke="#f59e0b" strokeWidth="1.5" />
            {/* Helmet Fin */}
            <circle cx="-4" cy="-48" r="4.5" fill="#ef4444" />

            {/* Dynamic Carving Arm Outstretch */}
            <path d="M-12,-14 L-32,-2" stroke="#0284c7" strokeWidth="8" strokeLinecap="round" />
            <circle cx="-33" cy="-2" r="5" fill="#0f172a" />

            <path d="M12,-14 L32,-25" stroke="#0284c7" strokeWidth="8" strokeLinecap="round" />
            <circle cx="33" cy="-25" r="5" fill="#0f172a" />
          </g>
        </svg>
      </div>

      {/* 3. Top Header Status & Live Telemetry Pods */}
      <div className="relative z-10 flex items-center justify-between w-full max-w-5xl">
        <div className="flex items-center gap-3 bg-slate-900/90 backdrop-blur-xl border border-cyan-500/30 rounded-2xl px-4 py-2 sm:px-5 sm:py-2.5 shadow-[0_0_25px_rgba(6,182,212,0.25)]">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-cyan-400 via-blue-500 to-indigo-600 flex items-center justify-center text-slate-950 font-black shadow-md">
            <Mountain className="w-5 h-5 text-slate-950" />
          </div>
          <div>
            <div className="font-race font-black text-sm sm:text-base text-white tracking-widest flex items-center gap-2">
              <span>ALPINE RUSH</span>
              <span className="hidden sm:inline px-1.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] border border-cyan-400/40">
                PRO SPEEDWAY
              </span>
            </div>
            <div className="text-[10px] text-amber-300 font-race font-bold uppercase tracking-wider flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-400" />
              <span>Downhill Descent 3D</span>
            </div>
          </div>
        </div>

        {/* Live Gauges Display */}
        <div className="hidden md:flex items-center gap-2 bg-slate-900/85 backdrop-blur-md border border-white/10 rounded-2xl px-4 py-2 shadow-lg text-xs font-race">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-slate-950/70 border border-cyan-500/30 text-cyan-300">
            <Gauge className="w-3.5 h-3.5" />
            <span>{simulatedSpeed} KM/H</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-slate-950/70 border border-purple-500/30 text-purple-300">
            <Compass className="w-3.5 h-3.5" />
            <span>{simulatedAltitude} M</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-xl bg-slate-950/70 border border-amber-500/30 text-amber-300 font-black">
            <Zap className="w-3.5 h-3.5" />
            <span>GEAR {gearNumber}</span>
          </div>
        </div>

        {/* Skip to Action Button */}
        <button
          onClick={onLoaded}
          className="bg-slate-900/90 hover:bg-slate-800 text-cyan-200 hover:text-white border border-cyan-400/30 hover:border-cyan-400 px-4 py-2 rounded-2xl text-xs font-race font-bold flex items-center gap-1.5 transition-all shadow-lg cursor-pointer hover:scale-105 active:scale-95"
        >
          <span>DROP IN</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 4. Bottom High-Tech Loading Dashboard */}
      <div className="relative z-10 w-full max-w-2xl flex flex-col items-center gap-3">
        {/* Animated Dynamic Tips with Glow */}
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-950/80 border border-cyan-500/30 text-xs sm:text-sm font-race font-bold text-white tracking-wide shadow-xl backdrop-blur-md text-center max-w-full truncate">
          <Sparkles className="w-4 h-4 text-amber-300 animate-spin flex-shrink-0" />
          <span className="truncate">{tips[tipIndex]}</span>
        </div>

        {/* Multi-layer Neon Beveled Progress Bar */}
        <div className="w-full bg-slate-950/90 p-2 rounded-3xl border-2 border-cyan-400/40 shadow-[0_0_35px_rgba(6,182,212,0.3)] backdrop-blur-xl">
          <div className="relative w-full h-6 sm:h-7 bg-slate-900/90 rounded-2xl overflow-hidden p-0.5">
            {/* Fill gradient */}
            <div 
              className="h-full bg-gradient-to-r from-amber-400 via-cyan-400 to-blue-500 rounded-xl transition-all duration-150 relative shadow-[0_0_20px_rgba(56,189,248,0.7)]"
              style={{ width: `${progress}%` }}
            >
              {/* Dynamic Laser Stripes */}
              <div 
                className="absolute inset-0 opacity-40 animate-pulse" 
                style={{
                  backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,0.8) 10px, rgba(255,255,255,0.8) 20px)'
                }} 
              />
              {/* Leading Spark Point */}
              <div className="absolute right-0 top-0 bottom-0 w-3 bg-white blur-[2px] rounded-r-xl" />
            </div>
          </div>
        </div>

        {/* Telemetry Status Bar */}
        <div className="flex items-center justify-between w-full px-2 text-xs font-race font-bold text-slate-300">
          <div className="flex items-center gap-2 text-cyan-300">
            <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
            <span>CARVING PEAKS &bull; 100% READY</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-slate-400 text-[11px] hidden sm:inline">ALT: {simulatedAltitude}M</span>
            <span className="text-amber-300 tabular-nums text-base sm:text-lg font-black tracking-wider">
              {progress}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
