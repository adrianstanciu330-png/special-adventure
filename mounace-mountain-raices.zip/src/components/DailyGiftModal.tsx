import React, { useState } from 'react';
import { sound } from '../game/audio';
import { Gift, Sparkles, Coins, Check, X, Calendar, Crown, Clock } from 'lucide-react';

interface DailyGiftModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  lastDailyClaimDate?: string;
  dailyStreak?: number;
  onClaim: (coins: number, gems: number, newClaimDate: string, newStreak: number) => void;
  onClose: () => void;
}

const STREAK_REWARDS = [
  { day: 1, label: 'Day 1', coins: 300, gems: 0, icon: '💰' },
  { day: 2, label: 'Day 2', coins: 600, gems: 2, icon: '🪙' },
  { day: 3, label: 'Day 3', coins: 900, gems: 5, icon: '💎' },
  { day: 4, label: 'Day 4', coins: 1200, gems: 10, icon: '✨' },
  { day: 5, label: 'Day 5', coins: 1800, gems: 15, icon: '🌟' },
  { day: 6, label: 'Day 6', coins: 2800, gems: 25, icon: '⚡' },
  { day: 7, label: 'Day 7', coins: 5500, gems: 50, icon: '👑', isMega: true },
];

export const DailyGiftModal: React.FC<DailyGiftModalProps> = ({
  coins,
  gems,
  isVip = false,
  lastDailyClaimDate = '',
  dailyStreak = 0,
  onClaim,
  onClose,
}) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  const alreadyClaimedToday = lastDailyClaimDate === todayStr;

  const currentStreak = dailyStreak % 7;
  const currentReward = STREAK_REWARDS[currentStreak];

  const [hasJustClaimed, setHasJustClaimed] = useState(false);

  // If already claimed, player can spend 10 diamonds to re-roll and farm daily money (FREE for VIP!)
  const FARM_COST_GEMS = isVip ? 0 : 10;
  const canFarm = isVip || gems >= FARM_COST_GEMS;

  const handleClaim = () => {
    sound.playZoneTransition();
    sound.playDoubleCoins();

    const nextStreak = (dailyStreak % 7) + 1;
    setHasJustClaimed(true);

    if (alreadyClaimedToday && !isVip) {
      // Deduct 10 diamonds for extra farming claim
      onClaim(currentReward.coins, currentReward.gems - FARM_COST_GEMS, todayStr, nextStreak);
    } else {
      // Free daily check-in or VIP free farm claim
      onClaim(currentReward.coins, currentReward.gems, todayStr, nextStreak);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-amber-500/30 rounded-3xl shadow-2xl p-6 text-white flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold mb-1">
            <Gift className="w-3.5 h-3.5" />
            DAILY CHECK-IN REWARDS
          </div>
          <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-400 font-race tracking-wider">
            DAILY LOGIN GIFT
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Log in every day to claim escalating cash &amp; diamond rewards!
          </p>
        </div>

        {/* User Balance */}
        <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-1.5 rounded-full border border-slate-800 text-xs mb-4">
          <span className="flex items-center gap-1 text-amber-300 font-bold font-race">
            🪙 {coins.toLocaleString()}
          </span>
          <span className="flex items-center gap-1 text-cyan-300 font-bold font-race">
            💎 {gems.toLocaleString()}
          </span>
        </div>

        {/* 7-Day Rewards Strip */}
        <div className="grid grid-cols-7 gap-1.5 w-full mb-5">
          {STREAK_REWARDS.map((r, i) => {
            const isPast = i < currentStreak;
            const isToday = i === currentStreak;

            return (
              <div
                key={r.day}
                className={`p-2 rounded-xl flex flex-col items-center justify-between text-center relative border transition-all ${
                  isToday
                    ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40 shadow-lg scale-105'
                    : isPast
                    ? 'bg-slate-800/40 border-emerald-500/30 opacity-70'
                    : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <span className="text-[9px] font-race font-bold text-slate-400 uppercase">
                  {r.label}
                </span>

                <span className="text-xl my-1">{r.icon}</span>

                <div className="text-[10px] font-race font-extrabold text-amber-300">
                  +{r.coins}
                </div>
                {r.gems > 0 && (
                  <div className="text-[9px] font-race font-bold text-cyan-300">
                    +{r.gems} 💎
                  </div>
                )}

                {isPast && (
                  <div className="absolute inset-0 bg-slate-950/70 rounded-xl flex items-center justify-center">
                    <Check className="w-4 h-4 text-emerald-400" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Action Button */}
        <div className="w-full">
          {!alreadyClaimedToday ? (
            <button
              onClick={handleClaim}
              className="w-full py-4 px-6 bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-race font-black text-base tracking-wider rounded-2xl shadow-xl shadow-amber-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-5 h-5 fill-current" />
              <span>COLLECT TODAY&apos;S FREE GIFT!</span>
            </button>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="w-full py-2.5 px-4 bg-emerald-950/60 border border-emerald-500/30 rounded-xl text-center text-xs text-emerald-300 font-race font-bold flex items-center justify-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>TODAY&apos;S FREE REWARD ALREADY CLAIMED!</span>
              </div>

              {/* Extra farm claim for 10 diamonds */}
              <button
                onClick={handleClaim}
                disabled={!canFarm}
                className={`w-full py-3.5 px-6 rounded-2xl font-race font-black text-sm tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                  canFarm
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 hover:scale-[1.02] active:scale-[0.98]'
                    : 'bg-rose-950/60 border border-rose-800 text-rose-300 cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                {canFarm ? (
                  <span>FARM BONUS GIFT NOW (COST: 10 💎)</span>
                ) : (
                  <span>NEED 10 💎 TO FARM EXTRA GIFT</span>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
