import React, { useState, useEffect } from 'react';
import { CharacterDef, PlayerProgress, MapTheme, DifficultyLevel, GameModeId } from '../types/game';
import { WORLDS_CONFIG, GAME_MODES_CONFIG } from '../game/charactersConfig';
import { 
  Play, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Zap, 
  Award, 
  Calendar, 
  Lock, 
  Check, 
  AlertCircle,
  X,
  Crown,
  Gift,
  RotateCw,
  Droplets,
  HelpCircle,
  Target,
  Package,
  Globe,
  Flame,
  Skull,
  Crosshair,
  Timer,
  ShieldAlert,
  Radio,
  Boxes
} from 'lucide-react';
import { sound } from '../game/audio';
import { SupportedLanguage, LANGUAGES, t } from '../game/i18n';

interface TitleScreenProps {
  progress: PlayerProgress;
  activeCharacter: CharacterDef;
  onStart: () => void;
  onOpenCustomizer: () => void;
  onToggleSound: () => void;
  onSelectMap: (theme: MapTheme) => void;
  onUnlockMap: (theme: MapTheme, coins: number, gems: number) => void;
  onOpenDailyChallenges: () => void;
  unclaimedChallengesCount?: number;
  onOpenVip: () => void;
  onOpenMysteryBox: () => void;
  onOpenLuckySpin: () => void;
  onOpenPowerTap: () => void;
  onOpenQuiz: () => void;
  onOpenQuickWash: () => void;
  onOpenDailyGift: () => void;
  onSelectDifficulty?: (level: DifficultyLevel) => void;
  onSelectGameMode?: (mode: GameModeId) => void;
  language?: SupportedLanguage;
  onSelectLanguage?: (lang: SupportedLanguage) => void;
}

const DIFFICULTIES: Array<{
  id: DifficultyLevel;
  labelKey: string;
  badge: string;
  mult: string;
  color: string;
  border: string;
  bgActive: string;
  icon: string;
  desc: string;
}> = [
  {
    id: 'easy',
    labelKey: 'easy',
    badge: 'CASUAL',
    mult: '1.0X',
    color: 'text-emerald-400',
    border: 'border-emerald-500/50',
    bgActive: 'bg-emerald-950/90 border-2 border-emerald-400 border-b-4 border-b-emerald-600 text-emerald-300 ring-2 ring-emerald-400/60 shadow-[0_0_20px_rgba(16,185,129,0.5)] scale-105',
    icon: '🟢',
    desc: 'Gentle slopes & wide gates',
  },
  {
    id: 'normal',
    labelKey: 'normal',
    badge: 'STANDARD',
    mult: '1.5X',
    color: 'text-cyan-400',
    border: 'border-cyan-500/50',
    bgActive: 'bg-cyan-950/90 border-2 border-cyan-400 border-b-4 border-b-cyan-600 text-cyan-200 ring-2 ring-cyan-400/60 shadow-[0_0_20px_rgba(6,182,212,0.5)] scale-105',
    icon: '🔵',
    desc: 'Balanced downhill slalom',
  },
  {
    id: 'hard',
    labelKey: 'hard',
    badge: 'VETERAN',
    mult: '2.5X',
    color: 'text-amber-400',
    border: 'border-amber-500/50',
    bgActive: 'bg-amber-950/90 border-2 border-amber-400 border-b-4 border-b-amber-600 text-amber-200 ring-2 ring-amber-400/60 shadow-[0_0_20px_rgba(245,158,11,0.5)] scale-105',
    icon: '🟠',
    desc: 'Faster speeds & dense obstacles',
  },
  {
    id: 'insane',
    labelKey: 'insane',
    badge: 'EXTREME',
    mult: '4.0X',
    color: 'text-rose-400',
    border: 'border-rose-500/50',
    bgActive: 'bg-rose-950/90 border-2 border-rose-400 border-b-4 border-b-rose-600 text-rose-200 ring-2 ring-rose-400/60 shadow-[0_0_20px_rgba(244,63,94,0.5)] scale-105',
    icon: '🔴',
    desc: 'Severe hazards & high velocity',
  },
  {
    id: 'impossible',
    labelKey: 'impossible',
    badge: 'CHAOS',
    mult: '6.5X',
    color: 'text-purple-400',
    border: 'border-purple-500/50',
    bgActive: 'bg-purple-950/90 border-2 border-purple-400 border-b-4 border-b-purple-600 text-purple-200 ring-2 ring-purple-400/60 shadow-[0_0_25px_rgba(168,85,247,0.6)] scale-105',
    icon: '💀',
    desc: 'Lightning reflexes & chaos + gems',
  },
];

export const TitleScreen: React.FC<TitleScreenProps> = ({
  progress,
  activeCharacter,
  onStart,
  onOpenCustomizer,
  onToggleSound,
  onSelectMap,
  onUnlockMap,
  onOpenDailyChallenges,
  unclaimedChallengesCount = 0,
  onOpenVip,
  onOpenMysteryBox,
  onOpenLuckySpin,
  onOpenPowerTap,
  onOpenQuiz,
  onOpenQuickWash,
  onOpenDailyGift,
  onSelectDifficulty,
  onSelectGameMode,
  language = 'en',
  onSelectLanguage,
}) => {
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const currentDifficulty: DifficultyLevel = progress.selectedDifficulty || 'normal';
  const currentMap = progress.selectedMap || 'snow';
  const unlockedMaps = progress.unlockedMaps || ['snow', 'beach'];
  const [unlockTarget, setUnlockTarget] = useState<typeof WORLDS_CONFIG[0] | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onStart();
      } else if (e.code === 'KeyC') {
        onOpenCustomizer();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStart, onOpenCustomizer]);

  const handleWorldClick = (world: typeof WORLDS_CONFIG[0]) => {
    sound.playGate();
    if (unlockedMaps.includes(world.id)) {
      onSelectMap(world.id);
    } else {
      setUnlockTarget(world);
      setErrorMessage(null);
    }
  };

  const handleConfirmUnlock = () => {
    if (!unlockTarget) return;

    if (progress.isVip) {
      sound.playStarChime();
      sound.playPowerUp();
      onUnlockMap(unlockTarget.id, 0, 0);
      onSelectMap(unlockTarget.id);
      setUnlockTarget(null);
      return;
    }

    const canAffordCoins = progress.coins >= unlockTarget.costCoins;
    const canAffordGems = progress.gems >= unlockTarget.costGems;

    if (!canAffordCoins || !canAffordGems) {
      sound.playCrash();
      const needCoins = Math.max(0, unlockTarget.costCoins - progress.coins);
      const needGems = Math.max(0, unlockTarget.costGems - progress.gems);
      let msg = 'You need ';
      if (needCoins > 0) msg += `${needCoins} more 🪙 `;
      if (needGems > 0) msg += `${needGems} more 💎 `;
      msg += 'to unlock this world! Play runs or mini-games to earn more!';
      setErrorMessage(msg);
      return;
    }

    onUnlockMap(unlockTarget.id, unlockTarget.costCoins, unlockTarget.costGems);
    onSelectMap(unlockTarget.id);
    setUnlockTarget(null);
  };

  const activeWorldConfig = WORLDS_CONFIG.find(w => w.id === currentMap) || WORLDS_CONFIG[0];

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-5 select-none overflow-y-auto">
      {/* 1. Top Bar Status Cluster */}
      <div className="flex items-center justify-between pointer-events-auto gap-2 flex-wrap">
        {/* Currencies & Best */}
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-1.5 bg-slate-900/85 border border-white/10 rounded-2xl px-3 sm:px-4 py-2 backdrop-blur-xl shadow-lg">
            <span className="text-amber-400 text-base sm:text-lg">🪙</span>
            <span className="font-race text-base sm:text-lg text-amber-300 font-bold tabular-nums">
              {progress.coins.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-900/85 border border-white/10 rounded-2xl px-3 sm:px-4 py-2 backdrop-blur-xl shadow-lg">
            <span className="text-cyan-400 text-base sm:text-lg">💎</span>
            <span className="font-race text-base sm:text-lg text-cyan-300 font-bold tabular-nums">
              {progress.gems.toLocaleString()}
            </span>
          </div>

          {progress.highScore > 0 && (
            <div className="hidden md:flex items-center gap-2 bg-slate-900/85 border border-white/10 rounded-2xl px-3.5 py-2 backdrop-blur-xl">
              <Award className="w-4 h-4 text-yellow-400" />
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Best</span>
              <span className="font-race text-sm text-slate-200 font-bold tabular-nums">
                {progress.highScore.toLocaleString()}
              </span>
            </div>
          )}
        </div>

        {/* Right Action Tools: VIP, Shop, Daily Missions, Sound */}
        <div className="flex items-center gap-2">
          {/* BUY V.I.P Button */}
          <button
            onClick={() => {
              sound.playGate();
              onOpenVip();
            }}
            className={`px-3.5 py-2.5 rounded-2xl transition-all flex items-center gap-2 cursor-pointer font-race font-black text-xs active:translate-y-1 active:border-b-0 ${
              progress.isVip
                ? 'bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-slate-950 border-2 border-yellow-200 border-b-4 border-b-amber-600 shadow-[0_0_25px_rgba(251,191,36,0.7)] animate-pulse'
                : 'bg-gradient-to-r from-amber-600/35 via-yellow-500/30 to-amber-500/35 hover:from-amber-500/60 hover:to-yellow-500/60 border border-amber-400/80 border-b-4 border-b-amber-700 text-amber-300 hover:text-white shadow-[0_0_15px_rgba(245,158,11,0.4)]'
            }`}
            title="V.I.P Pass - 2X Adventure Rewards & 100% Free Unlocks"
          >
            <Crown className="w-4 h-4 fill-current text-yellow-300 filter drop-shadow" />
            <span className="hidden sm:inline">{progress.isVip ? t('vipActive', language) : t('buyVip', language)}</span>
            <span className="sm:hidden">{progress.isVip ? '👑 VIP' : '👑 VIP'}</span>
          </button>

          {/* Mystery Box Crate Shop */}
          <button
            onClick={() => {
              sound.playGate();
              onOpenMysteryBox();
            }}
            className="px-3.5 py-2.5 bg-gradient-to-r from-purple-700/50 via-pink-600/40 to-indigo-700/50 hover:from-purple-600/70 hover:to-pink-600/70 border border-purple-400/80 border-b-4 border-b-purple-800 rounded-2xl text-purple-200 hover:text-white transition-all shadow-[0_0_20px_rgba(168,85,247,0.4)] active:border-b-0 active:translate-y-1 flex items-center gap-2 cursor-pointer font-race font-black text-xs"
            title="Mystery Boxes - Unlock Rare & Mythic Racers"
          >
            <Package className="w-4 h-4 text-pink-300 filter drop-shadow" />
            <span className="hidden sm:inline">{t('shop', language)}</span>
            <span className="sm:hidden">{t('shop', language)}</span>
          </button>

          {/* Daily Challenges Button */}
          <button
            onClick={() => {
              sound.playGate();
              onOpenDailyChallenges();
            }}
            className="relative px-3.5 py-2.5 bg-gradient-to-r from-blue-600/40 via-cyan-600/40 to-teal-600/40 hover:from-blue-600/60 hover:to-cyan-600/60 border border-cyan-400/80 border-b-4 border-b-cyan-700 rounded-2xl text-cyan-200 hover:text-white transition-all shadow-[0_0_20px_rgba(6,182,212,0.4)] active:border-b-0 active:translate-y-1 flex items-center gap-2 cursor-pointer font-race font-black text-xs"
            aria-label="Daily Missions"
          >
            <Calendar className="w-4 h-4 text-cyan-300 filter drop-shadow" />
            <span className="hidden sm:inline">{t('missions', language)}</span>
            {unclaimedChallengesCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-400 text-slate-950 font-black text-[10px] flex items-center justify-center animate-bounce shadow-md">
                {unclaimedChallengesCount}
              </span>
            )}
          </button>

          <button
            onClick={onToggleSound}
            className="p-2.5 bg-slate-900/95 hover:bg-slate-800 border border-white/20 border-b-4 border-b-slate-700 rounded-2xl text-slate-300 hover:text-white transition-all shadow-lg active:border-b-0 active:translate-y-1 cursor-pointer"
            aria-label="Toggle Sound"
          >
            {progress.soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400 filter drop-shadow" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* 2. Main Middle Area: Left Languages & Minigames Dock + Center Hero Selection */}
      <div className="relative my-auto py-2 w-full flex flex-col lg:flex-row items-center justify-between gap-4">
        
        {/* Left Side: Language Selector Dock + 5 Arcade Farming Minigames Bar */}
        <div className="w-full lg:w-60 pointer-events-auto flex flex-col gap-2 order-2 lg:order-1">
          {/* Languages Selector Dock (User request: "add langauges in the main screen in the left! Add russian, romanian, englsih, french, italian, spanish and german!") */}
          <div className="p-2 sm:p-2.5 bg-slate-900/95 border border-cyan-500/35 rounded-2xl shadow-xl flex flex-col gap-1.5 backdrop-blur-md">
            <div className="flex items-center justify-between px-1">
              <span className="text-[10px] font-race font-black text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                <span>{t('language', language)}</span>
              </span>
              <span className="text-[9px] font-race font-bold text-amber-300 bg-amber-950/70 border border-amber-800/40 px-1.5 py-0.5 rounded-full">
                7 LANGS
              </span>
            </div>

            {/* Language Selection Grid */}
            <div className="grid grid-cols-7 lg:grid-cols-4 gap-1">
              {LANGUAGES.map((item) => {
                const isActive = language === item.code;
                return (
                  <button
                    key={item.code}
                    onClick={() => {
                      sound.playGate();
                      onSelectLanguage?.(item.code);
                    }}
                    className={`py-1.5 px-1 rounded-xl border text-[11px] font-race font-bold flex items-center justify-center gap-1 transition-all cursor-pointer active:translate-y-0.5 ${
                      isActive
                        ? 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 border-cyan-300 border-b-3 border-b-cyan-800 text-white shadow-[0_0_15px_rgba(6,182,212,0.7)] scale-105 ring-1 ring-cyan-200'
                        : 'bg-slate-950/80 border-white/10 border-b-2 border-b-slate-800 hover:border-white/30 text-slate-400 hover:text-white hover:bg-slate-850'
                    }`}
                    title={`${item.flag} ${item.nativeName} (${item.name})`}
                  >
                    <span className="text-sm">{item.flag}</span>
                    <span className="text-[9px] uppercase font-mono">{item.code}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between px-1 mb-0.5">
            <span className="text-[10px] font-race font-black text-amber-400 uppercase tracking-widest flex items-center gap-1">
              <span>⚡</span> {t('farmMoney', language)}
            </span>
            <span className="text-[9px] font-race text-cyan-400 bg-cyan-950/70 border border-cyan-800/40 px-1.5 py-0.5 rounded-full">
              {t('minigames', language)}
            </span>
          </div>

          <div className="grid grid-cols-5 lg:grid-cols-1 gap-2">
            {/* 1. Lucky Spin */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenLuckySpin();
              }}
              className="group p-2.5 bg-gradient-to-r from-slate-900/95 to-amber-950/50 hover:from-slate-850 hover:to-amber-900/60 border border-amber-500/50 border-b-4 border-b-amber-600 rounded-2xl transition-all shadow-[0_0_15px_rgba(245,158,11,0.25)] hover:shadow-[0_0_25px_rgba(245,158,11,0.5)] flex items-center gap-2.5 cursor-pointer text-left active:border-b-0 active:translate-y-1"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-slate-950 flex items-center justify-center flex-shrink-0 group-hover:rotate-45 transition-transform shadow-md">
                <RotateCw className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="hidden lg:block min-w-0 flex-1">
                <div className="font-race font-black text-xs text-white truncate flex items-center justify-between">
                  <span>{t('luckySpin', language)}</span>
                  <span className="text-[9px] text-amber-300 font-black">10 💎</span>
                </div>
                <div className="text-[10px] text-slate-300 truncate">{t('wheelOfFortune', language)}</div>
              </div>
            </button>

            {/* 2. Power Tap */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenPowerTap();
              }}
              className="group p-2.5 bg-gradient-to-r from-slate-900/95 to-emerald-950/50 hover:from-slate-850 hover:to-emerald-900/60 border border-emerald-500/50 border-b-4 border-b-emerald-600 rounded-2xl transition-all shadow-[0_0_15px_rgba(16,185,129,0.25)] hover:shadow-[0_0_25px_rgba(16,185,129,0.5)] flex items-center gap-2.5 cursor-pointer text-left active:border-b-0 active:translate-y-1"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-slate-950 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md">
                <Target className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="hidden lg:block min-w-0 flex-1">
                <div className="font-race font-black text-xs text-white truncate flex items-center justify-between">
                  <span>{t('powerTap', language)}</span>
                  <span className="text-[9px] text-emerald-300 font-black">10 💎</span>
                </div>
                <div className="text-[10px] text-slate-300 truncate">{t('greenSweetSpot', language)}</div>
              </div>
            </button>

            {/* 3. Mountain Trivia */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenQuiz();
              }}
              className="group p-2.5 bg-gradient-to-r from-slate-900/95 to-cyan-950/50 hover:from-slate-850 hover:to-cyan-900/60 border border-cyan-500/50 border-b-4 border-b-cyan-600 rounded-2xl transition-all shadow-[0_0_15px_rgba(6,182,212,0.25)] hover:shadow-[0_0_25px_rgba(6,182,212,0.5)] flex items-center gap-2.5 cursor-pointer text-left active:border-b-0 active:translate-y-1"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 text-slate-950 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md">
                <HelpCircle className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="hidden lg:block min-w-0 flex-1">
                <div className="font-race font-black text-xs text-white truncate flex items-center justify-between">
                  <span>{t('mountainTrivia', language)}</span>
                  <span className="text-[9px] text-cyan-300 font-black">10 💎</span>
                </div>
                <div className="text-[10px] text-slate-300 truncate">{t('speedQuiz', language)}</div>
              </div>
            </button>

            {/* 4. Quick Car Wash */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenQuickWash();
              }}
              className="group p-2.5 bg-gradient-to-r from-slate-900/95 to-blue-950/50 hover:from-slate-850 hover:to-blue-900/60 border border-blue-500/50 border-b-4 border-b-blue-600 rounded-2xl transition-all shadow-[0_0_15px_rgba(59,130,246,0.25)] hover:shadow-[0_0_25px_rgba(59,130,246,0.5)] flex items-center gap-2.5 cursor-pointer text-left active:border-b-0 active:translate-y-1"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-blue-400 to-indigo-600 text-slate-950 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md">
                <Droplets className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="hidden lg:block min-w-0 flex-1">
                <div className="font-race font-black text-xs text-white truncate flex items-center justify-between">
                  <span>{t('quickWash', language)}</span>
                  <span className="text-[9px] text-blue-300 font-black">10 💎</span>
                </div>
                <div className="text-[10px] text-slate-300 truncate">{t('polishBoards', language)}</div>
              </div>
            </button>

            {/* 5. Daily Gift */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenDailyGift();
              }}
              className="group p-2.5 bg-gradient-to-r from-slate-900/95 to-purple-950/50 hover:from-slate-850 hover:to-purple-900/60 border border-purple-500/50 border-b-4 border-b-purple-600 rounded-2xl transition-all shadow-[0_0_15px_rgba(168,85,247,0.25)] hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] flex items-center gap-2.5 cursor-pointer text-left active:border-b-0 active:translate-y-1"
            >
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-400 to-pink-600 text-slate-950 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md">
                <Gift className="w-4 h-4 stroke-[2.5]" />
              </div>
              <div className="hidden lg:block min-w-0 flex-1">
                <div className="font-race font-black text-xs text-white truncate flex items-center justify-between">
                  <span>{t('dailyGift', language)}</span>
                  <span className="text-[9px] text-amber-300 font-black">Free/Farm</span>
                </div>
                <div className="text-[10px] text-slate-300 truncate">{t('streakBonus', language)}</div>
              </div>
            </button>
          </div>
        </div>

        {/* Center: World Selection & Hero Title */}
        <div className="flex-1 flex flex-col items-center justify-center text-center max-w-2xl order-1 lg:order-2">
          {/* Dynamic Title based on selected world */}
          <div className="relative mb-2">
            <h1 className="font-race font-black tracking-widest text-3xl sm:text-5xl text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-blue-400 drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)] uppercase">
              {activeWorldConfig.name}
            </h1>
            <p className="font-race font-extrabold tracking-[0.2em] text-xs sm:text-base text-cyan-300 mt-0.5 uppercase">
              {activeWorldConfig.subtitle}
            </p>
          </div>

          {/* 1. Epic Worlds Selection Grid (10 Worlds: 9 Classic + Dinner Time) */}
          <div className="w-full mb-3 pointer-events-auto">
            <div className="flex items-center justify-between gap-1 mb-1.5 px-1">
              <span className="text-[11px] font-race font-black uppercase tracking-widest text-cyan-300 flex items-center gap-1.5 filter drop-shadow">
                <span>🗺️</span> 10 EPIC WORLDS
              </span>
              <span className="text-[9px] font-race text-amber-300 font-bold">
                {WORLDS_CONFIG.find(w => w.id === currentMap)?.name || 'Alpine Snow'}
              </span>
            </div>

            {/* 10 Worlds Grid: 5 cols on desktop, 2 rows */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-h-48 sm:max-h-none overflow-y-auto pr-0.5">
              {WORLDS_CONFIG.map((world) => {
                const isUnlocked = unlockedMaps.includes(world.id);
                const isSelected = currentMap === world.id;

                return (
                  <button
                    key={world.id}
                    onClick={() => handleWorldClick(world)}
                    className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between backdrop-blur-xl relative overflow-hidden active:translate-y-1 ${
                      isSelected
                        ? 'border-2 border-cyan-300 border-b-[5px] border-b-cyan-600 bg-gradient-to-b from-cyan-950/95 via-blue-950/95 to-slate-950/95 shadow-[0_0_25px_rgba(6,182,212,0.8)] ring-2 ring-cyan-400/70 scale-[1.03]'
                        : isUnlocked
                        ? 'border border-slate-700/80 border-b-[4px] border-b-slate-800 bg-gradient-to-b from-slate-900/90 to-slate-950/90 hover:from-slate-850 hover:to-slate-900 hover:border-cyan-400 hover:border-b-cyan-500 hover:shadow-[0_0_20px_rgba(6,182,212,0.4)] text-slate-300 hover:scale-[1.02]'
                        : 'border border-amber-500/50 border-b-[4px] border-b-amber-900 bg-gradient-to-b from-slate-950/95 to-amber-950/30 hover:border-amber-400 hover:shadow-[0_0_15px_rgba(245,158,11,0.4)] text-slate-400 hover:scale-[1.01]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xl filter drop-shadow">{world.icon}</span>
                      {isUnlocked ? (
                        isSelected && (
                          <span className="p-0.5 rounded-md bg-cyan-400 text-slate-950 font-black shadow-sm">
                            <Check className="w-2.5 h-2.5 stroke-[3]" />
                          </span>
                        )
                      ) : (
                        <span className="px-1 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/50 flex items-center gap-0.5 text-[8px] font-race font-bold">
                          <Lock className="w-2 h-2" />
                          <span>LOCKED</span>
                        </span>
                      )}
                    </div>

                    <div>
                      <div className="font-race font-black text-[11px] text-white truncate drop-shadow">
                        {t(`map_${world.id}`, language) || world.name}
                      </div>
                      {!isUnlocked ? (
                        <div className="text-[8px] font-race font-black text-amber-400 flex items-center gap-0.5 mt-0.5">
                          {world.costCoins > 0 && <span>{world.costCoins.toLocaleString()}🪙</span>}
                          {world.costGems > 0 && <span>{world.costGems}💎</span>}
                        </div>
                      ) : (
                        <div className="text-[8px] font-race font-bold truncate mt-0.5 text-cyan-300">
                          {isSelected ? '● SELECTED' : 'READY'}
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. 5-Mode Difficulty Selector (Obstacle Density Scaling!) */}
          <div className="w-full max-w-lg mb-3 pointer-events-auto bg-slate-950/95 border border-white/20 border-b-[5px] border-b-slate-800 rounded-3xl p-3 backdrop-blur-xl shadow-2xl">
            <div className="flex items-center justify-between px-1 mb-2">
              <span className="text-[10px] font-race font-black uppercase tracking-widest text-slate-200 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-400 filter drop-shadow animate-pulse" />
                {t('difficulty', language)}: OBSTACLE DENSITY
              </span>
              <span className="text-[9px] font-race font-black text-cyan-300 uppercase px-2.5 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-500/50 shadow-sm">
                {currentDifficulty.toUpperCase()} &middot; {DIFFICULTIES.find(d => d.id === currentDifficulty)?.mult} SCORE
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1.5">
              {DIFFICULTIES.map((diff) => {
                const isActive = currentDifficulty === diff.id;
                const densityLabel = diff.id === 'easy' ? '0.55x Obsts' : diff.id === 'normal' ? '1.0x Obsts' : diff.id === 'hard' ? '+60% Obsts' : diff.id === 'insane' ? '+120% Obsts' : '+200% Swarm';
                return (
                  <button
                    key={diff.id}
                    onClick={() => {
                      sound.playGate();
                      onSelectDifficulty?.(diff.id);
                    }}
                    className={`py-2 px-1 rounded-2xl text-center transition-all cursor-pointer flex flex-col items-center justify-center min-h-[52px] active:translate-y-1 active:border-b-0 ${
                      isActive
                        ? diff.bgActive
                        : 'bg-slate-900/80 border border-white/10 border-b-[4px] border-b-slate-800 hover:border-white/30 hover:border-b-slate-700 text-slate-400 hover:text-white hover:bg-slate-850'
                    }`}
                    title={diff.desc}
                  >
                    <div className="text-base sm:text-lg leading-none mb-0.5 filter drop-shadow">{diff.icon}</div>
                    <span className="font-race font-black text-[9px] sm:text-[10px] uppercase truncate w-full px-0.5">
                      {t(diff.labelKey, language)}
                    </span>
                    <span className={`text-[7px] font-mono font-black mt-0.5 ${isActive ? 'text-white' : 'text-slate-400'}`}>
                      {densityLabel}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Drop-In Race Buttons - 100X COOLER ARCADE BEVELS & NEON GLOW */}
          <div className="flex flex-col sm:flex-row items-center gap-3.5 pointer-events-auto w-full max-w-lg justify-center">
            {/* RACE NOW - Ultra Arcade Neon 3D Showstopper */}
            <button
              onClick={() => {
                sound.playJump();
                onStart();
              }}
              className="group relative flex-1 w-full px-8 py-4 bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:via-yellow-300 hover:to-orange-400 text-slate-950 font-race font-black text-lg tracking-widest rounded-2xl transition-all flex items-center justify-center gap-3 cursor-pointer border-2 border-yellow-100 border-b-[6px] border-b-amber-700 active:border-b-[2px] active:translate-y-1.5 shadow-[0_0_35px_rgba(245,158,11,0.7)] hover:shadow-[0_0_60px_rgba(245,158,11,0.95)] hover:scale-105 active:scale-95 min-h-[56px]"
            >
              <Play className="w-6 h-6 fill-current filter drop-shadow group-hover:scale-125 transition-transform" />
              <span className="drop-shadow uppercase tracking-wider">{t('play', language)}</span>
              <span className="text-xl animate-bounce">⚡</span>
            </button>

            {/* MEGA SHOP Button - 3D Purple Arcade Crystal */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenMysteryBox();
              }}
              className="flex-1 w-full px-6 py-4 bg-gradient-to-r from-purple-700 via-fuchsia-700 to-pink-700 hover:from-purple-600 hover:to-pink-600 text-white font-race font-black text-sm tracking-wider rounded-2xl border-2 border-fuchsia-300/80 border-b-[6px] border-b-purple-950 active:border-b-[2px] active:translate-y-1.5 shadow-[0_0_25px_rgba(168,85,247,0.6)] hover:shadow-[0_0_45px_rgba(168,85,247,0.85)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 pointer-events-auto cursor-pointer min-h-[56px]"
            >
              <Package className="w-5 h-5 text-pink-300 filter drop-shadow" />
              <span>{t('shop', language)}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-mono font-black shadow-inner">150+</span>
            </button>

            {/* RACERS & GEAR (150 RACERS) Button - 3D Cyber Cyan */}
            <button
              onClick={() => {
                sound.playGate();
                onOpenCustomizer();
              }}
              className="flex-1 w-full px-6 py-4 bg-gradient-to-r from-cyan-700 via-blue-700 to-indigo-700 hover:from-cyan-600 hover:to-blue-600 text-white font-race font-black text-sm tracking-wider rounded-2xl border-2 border-cyan-300/80 border-b-[6px] border-b-cyan-950 active:border-b-[2px] active:translate-y-1.5 shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:shadow-[0_0_45px_rgba(6,182,212,0.85)] hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 pointer-events-auto cursor-pointer min-h-[56px]"
            >
              <Sparkles className="w-5 h-5 text-amber-300 filter drop-shadow" />
              <span>{t('customize', language)} (151 Racers)</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. Bottom Control Hints (Clean, no next zone/planet/deer text!) */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pointer-events-auto pb-1">
        <div className="bg-slate-950/85 border border-slate-800 rounded-full px-4 py-1.5 backdrop-blur-md text-[11px] text-slate-300 font-medium tracking-wide text-center shadow-lg">
          <span className="text-cyan-300 font-bold">A/D</span> {t('controlSteer', language)} &nbsp;·&nbsp;
          <span className="text-cyan-300 font-bold">W</span> {t('controlBoost', language)} &nbsp;·&nbsp;
          <span className="text-cyan-300 font-bold">Space</span> {t('controlJump', language)}
        </div>
      </div>

      {/* Unlock World Confirmation Modal */}
      {unlockTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md pointer-events-auto animate-in fade-in duration-150">
          <div className="w-full max-w-md bg-slate-900/95 border border-amber-500/50 rounded-3xl p-6 shadow-2xl flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500 to-yellow-600 flex items-center justify-center text-3xl mb-4 shadow-lg shadow-amber-500/25">
              {unlockTarget.icon}
            </div>

            <h3 className="text-2xl font-race font-black text-white mb-1">
              UNLOCK {unlockTarget.name.toUpperCase()}?
            </h3>
            <p className="text-xs text-slate-300 mb-4 px-2">
              {unlockTarget.description}
            </p>

            {/* Included Features & Themed Costumes */}
            <div className="w-full bg-slate-950/80 border border-white/10 rounded-2xl p-4 mb-4 text-left space-y-2 text-xs">
              <div className="flex items-center gap-2 text-cyan-300 font-race font-bold">
                <span>📍</span>
                <span>Area 1: {unlockTarget.firstPlace}</span>
              </div>
              <div className="flex items-center gap-2 text-amber-300 font-race font-bold">
                <span>🏰</span>
                <span>Area 2 (at 10k): {unlockTarget.secondPlace}</span>
              </div>
              {unlockTarget.pursuerName && (
                <div className="flex items-center gap-2 text-rose-300 font-race font-bold">
                  <span>🏃</span>
                  <span>Chase: {unlockTarget.pursuerName} following you!</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-emerald-300 font-race font-bold">
                <span>🥋</span>
                <span>Includes {unlockTarget.costumeName} for all 15 racers!</span>
              </div>
            </div>

            {/* Error Message if Insufficient Funds */}
            {errorMessage && (
              <div className="w-full p-3 mb-4 bg-rose-950/60 border border-rose-800/80 rounded-xl text-xs text-rose-200 flex items-start gap-2 text-left">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Cost & Action Buttons */}
            <div className="flex items-center gap-3 w-full">
              <button
                onClick={() => setUnlockTarget(null)}
                className="flex-1 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-race font-bold text-sm rounded-2xl transition-all cursor-pointer border border-white/10 border-b-4 border-b-slate-900 active:border-b-0 active:translate-y-1"
              >
                CANCEL
              </button>

              <button
                onClick={handleConfirmUnlock}
                className="flex-1 py-3.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 font-race font-black text-sm rounded-2xl transition-all cursor-pointer border-2 border-yellow-200 border-b-4 border-b-amber-700 active:border-b-0 active:translate-y-1 shadow-[0_0_25px_rgba(245,158,11,0.6)] flex items-center justify-center gap-2"
              >
                <Lock className="w-4 h-4 fill-current stroke-[2.5]" />
                <span>
                  UNLOCK (
                  {unlockTarget.costCoins > 0 && `${unlockTarget.costCoins.toLocaleString()} 🪙`}
                  {unlockTarget.costGems > 0 && ` ${unlockTarget.costGems} 💎`}
                  )
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
