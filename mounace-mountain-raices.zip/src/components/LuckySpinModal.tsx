import React, { useState, useRef, useEffect } from 'react';
import { sound } from '../game/audio';
import { Coins, Sparkles, X, RotateCw, Trophy, PartyPopper } from 'lucide-react';

interface LuckySpinModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  lastSpinTimestamp?: number;
  onReward: (rewardCoins: number, rewardGems: number, newTimestamp?: number) => void;
  onClose: () => void;
}

interface Wedge {
  label: string;
  subLabel: string;
  coins: number;
  gems: number;
  color: string;
  textColor: string;
  isJackpot?: boolean;
}

const WEDGES: Wedge[] = [
  { label: '+100', subLabel: 'COINS', coins: 100, gems: 0, color: '#10b981', textColor: '#ffffff' },
  { label: '+250', subLabel: 'COINS', coins: 250, gems: 0, color: '#0284c7', textColor: '#ffffff' },
  { label: '+15 💎', subLabel: 'DIAMONDS', coins: 0, gems: 15, color: '#ec4899', textColor: '#ffffff' },
  { label: '+500', subLabel: 'COINS', coins: 500, gems: 0, color: '#8b5cf6', textColor: '#ffffff' },
  { label: '+5 💎', subLabel: 'DIAMONDS', coins: 0, gems: 5, color: '#06b6d4', textColor: '#ffffff' },
  { label: '+1,000', subLabel: 'COINS', coins: 1000, gems: 0, color: '#f59e0b', textColor: '#ffffff' },
  { label: '+2,500', subLabel: 'COINS', coins: 2500, gems: 0, color: '#059669', textColor: '#ffffff' },
  { label: 'JACKPOT', subLabel: '5000+50💎', coins: 5000, gems: 50, color: '#eab308', textColor: '#1e293b', isJackpot: true },
];

export const LuckySpinModal: React.FC<LuckySpinModalProps> = ({
  coins,
  gems,
  isVip = false,
  lastSpinTimestamp = 0,
  onReward,
  onClose,
}) => {
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<Wedge | null>(null);
  const [showCelebration, setShowCelebration] = useState(false);

  const numWedges = WEDGES.length;
  const wedgeAngle = 360 / numWedges;

  // Farm minigame entry cost: 10 diamonds (gems), FREE for VIP!
  const SPIN_COST_GEMS = isVip ? 0 : 10;
  const canAfford = isVip || gems >= SPIN_COST_GEMS;

  const spinTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (spinTimeoutRef.current) clearTimeout(spinTimeoutRef.current);
    };
  }, []);

  const handleSpin = () => {
    if (isSpinning || !canAfford) {
      if (!canAfford) sound.playCrash();
      return;
    }

    sound.playPowerUp();
    setIsSpinning(true);
    setWonPrize(null);
    setShowCelebration(false);

    // Pick random winning index
    let targetIndex: number;
    const r = Math.random();
    if (r < 0.08) {
      targetIndex = 7; // Jackpot!
    } else if (r < 0.22) {
      targetIndex = 6; // 2,500
    } else if (r < 0.38) {
      targetIndex = 5; // 1,000
    } else if (r < 0.52) {
      targetIndex = 3; // 500
    } else if (r < 0.68) {
      targetIndex = 2; // 15 gems
    } else if (r < 0.82) {
      targetIndex = 4; // 5 gems
    } else if (r < 0.92) {
      targetIndex = 1; // 250
    } else {
      targetIndex = 0; // 100
    }

    const wedgeCenter = targetIndex * wedgeAngle + wedgeAngle / 2;
    const extraRotations = 5 * 360;
    const targetRotation = rotation + extraRotations + (360 - (rotation % 360)) + (360 - wedgeCenter);

    setRotation(targetRotation);

    let tickCount = 0;
    const tickerInterval = setInterval(() => {
      tickCount++;
      if (tickCount % 2 === 0) {
        sound.playGate();
      }
      if (tickCount > 35) clearInterval(tickerInterval);
    }, 110);

    spinTimeoutRef.current = window.setTimeout(() => {
      clearInterval(tickerInterval);
      const prize = WEDGES[targetIndex];
      setWonPrize(prize);
      setIsSpinning(false);
      setShowCelebration(true);

      if (prize.isJackpot) {
        sound.playStarChime();
        sound.playZoneTransition();
      } else {
        sound.playDoubleCoins();
      }

      // Net gems: prize.gems minus entry cost (10 diamonds)
      onReward(prize.coins, prize.gems - SPIN_COST_GEMS, Date.now());
    }, 4200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-500/30 rounded-3xl shadow-2xl p-6 text-white flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title Lockup */}
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-bold mb-1">
            <Trophy className="w-3.5 h-3.5" />
            LUCKY WHEEL OF FORTUNE
          </div>
          <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-orange-400 font-race tracking-wider">
            LUCKY SPIN
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Spin the wheel to farm huge coins & gems! Entry: <strong className="text-cyan-300 font-bold">10 💎</strong>
          </p>
        </div>

        {/* User Balance */}
        <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-1.5 rounded-full border border-slate-800 text-xs mb-4">
          <span className="flex items-center gap-1 text-amber-300 font-bold font-race">
            🪙 {coins.toLocaleString()}
          </span>
          <span className="flex items-center gap-1 text-cyan-300 font-bold font-race">
            💎 {gems.toLocaleString()}
          </span>
        </div>

        {/* 2D Wheel Canvas / SVG */}
        <div className="relative w-64 h-64 sm:w-72 sm:h-72 my-2 flex items-center justify-center">
          {/* Wheel Pointer (Top center) */}
          <div className="absolute -top-3 z-20 flex flex-col items-center drop-shadow-[0_4px_8px_rgba(0,0,0,0.8)]">
            <div className="w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[24px] border-t-amber-400 filter drop-shadow animate-pulse" />
          </div>

          {/* Rotating Disk */}
          <div
            className="w-full h-full rounded-full border-4 border-amber-400/80 shadow-[0_0_30px_rgba(245,158,11,0.3)] overflow-hidden relative"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: isSpinning ? 'transform 4.2s cubic-bezier(0.15, 0.85, 0.25, 1)' : 'none',
            }}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full">
              {WEDGES.map((w, i) => {
                const startAngle = i * wedgeAngle;
                const endAngle = (i + 1) * wedgeAngle;
                const startRad = (startAngle - 90) * (Math.PI / 180);
                const endRad = (endAngle - 90) * (Math.PI / 180);
                const x1 = 50 + 50 * Math.cos(startRad);
                const y1 = 50 + 50 * Math.sin(startRad);
                const x2 = 50 + 50 * Math.cos(endRad);
                const y2 = 50 + 50 * Math.sin(endRad);

                const midAngle = startAngle + wedgeAngle / 2;
                const midRad = (midAngle - 90) * (Math.PI / 180);
                const textX = 50 + 33 * Math.cos(midRad);
                const textY = 50 + 33 * Math.sin(midRad);

                return (
                  <g key={i}>
                    <path
                      d={`M 50 50 L ${x1} ${y1} A 50 50 0 0 1 ${x2} ${y2} Z`}
                      fill={w.color}
                      stroke="#1e293b"
                      strokeWidth="0.8"
                    />
                    <text
                      x={textX}
                      y={textY}
                      fill={w.textColor}
                      fontSize={w.isJackpot ? '4.5' : '4.8'}
                      fontWeight="900"
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${midAngle}, ${textX}, ${textY})`}
                      style={{ textShadow: '0 1px 2px rgba(0,0,0,0.8)' }}
                    >
                      {w.label}
                    </text>
                  </g>
                );
              })}
              {/* Outer Golden Rim Ring */}
              <circle cx="50" cy="50" r="49" fill="none" stroke="#f59e0b" strokeWidth="2" opacity="0.6" />
            </svg>

            {/* Central Pin */}
            <div className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-gradient-to-br from-amber-300 via-amber-500 to-yellow-600 border-2 border-white/60 shadow-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-slate-950 fill-current" />
            </div>
          </div>
        </div>

        {/* Won Prize Banner */}
        {wonPrize && (
          <div className="w-full mt-3 p-3 bg-gradient-to-r from-amber-500/20 to-yellow-500/20 border border-amber-400/50 rounded-2xl flex items-center justify-center gap-2 animate-bounce">
            <PartyPopper className="w-5 h-5 text-amber-400" />
            <span className="font-race font-extrabold text-sm text-amber-300 uppercase">
              YOU WON {wonPrize.label} {wonPrize.subLabel}!
            </span>
          </div>
        )}

        {/* Spin Action Button */}
        <div className="w-full mt-4">
          <button
            onClick={handleSpin}
            disabled={isSpinning || !canAfford}
            className={`w-full py-3.5 px-6 rounded-2xl font-race font-black text-base tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
              isSpinning
                ? 'bg-slate-800 text-slate-400 cursor-not-allowed'
                : canAfford
                ? 'bg-gradient-to-r from-amber-400 via-yellow-400 to-orange-500 hover:from-amber-300 hover:to-orange-400 text-slate-950 shadow-amber-500/25 hover:scale-[1.02] active:scale-[0.98]'
                : 'bg-rose-950/60 border border-rose-800 text-rose-300 cursor-not-allowed'
            }`}
          >
            <RotateCw className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
            {isSpinning ? (
              <span>SPINNING WHEEL...</span>
            ) : isVip ? (
              <span>SPIN WHEEL (FREE WITH VIP 👑)</span>
            ) : canAfford ? (
              <span>SPIN WHEEL (COST: 10 💎)</span>
            ) : (
              <span>NEED 10 💎 TO SPIN</span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
