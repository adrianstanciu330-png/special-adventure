import React, { useState } from 'react';
import { PlayerProgress, CharacterId, CharacterDef } from '../types/game';
import { MYSTERY_BOXES, CHARACTERS, openMysteryBox } from '../game/charactersConfig';
import { sound } from '../game/audio';
import { getSavedLanguage, t } from '../game/i18n';
import { 
  Package, 
  Sparkles, 
  Coins, 
  Crown, 
  X, 
  Check, 
  AlertCircle, 
  Zap, 
  RotateCw, 
  CheckCircle2, 
  Gift, 
  Award,
  ChevronRight,
  Flame,
  ArrowUpRight,
  ShieldAlert,
  SlidersHorizontal,
  Magnet,
  ShieldCheck,
  Feather,
  ArrowRightLeft,
  ShoppingBag,
  Layers,
  Heart,
  Compass,
  Gauge,
  Sparkle,
  Gem,
  Dice5
} from 'lucide-react';

interface MysteryBoxModalProps {
  progress: PlayerProgress;
  onUnlockCharacter: (characterId: CharacterId) => void;
  onSelectCharacter: (characterId: CharacterId) => void;
  onAddCurrency: (coins: number, gems: number) => void;
  onDeductCurrency: (coins: number, gems: number) => void;
  onUpdateProgress?: (updater: (prev: PlayerProgress) => PlayerProgress) => void;
  onClose: () => void;
}

type ModalState = 'shop' | 'opening' | 'revealed';
type ShopTab = 'boxes' | 'upgrades' | 'auras' | 'exchange' | 'roster';

export const MysteryBoxModal: React.FC<MysteryBoxModalProps> = ({
  progress,
  onUnlockCharacter,
  onSelectCharacter,
  onAddCurrency,
  onDeductCurrency,
  onUpdateProgress,
  onClose,
}) => {
  const [modalState, setModalState] = useState<ModalState>('shop');
  const [activeTab, setActiveTab] = useState<ShopTab>('boxes');
  const [selectedBox, setSelectedBox] = useState<typeof MYSTERY_BOXES[0]>(MYSTERY_BOXES[0]);
  const [unboxedResult, setUnboxedResult] = useState<{
    character: CharacterDef;
    isDuplicate: boolean;
    refundCoins: number;
    refundGems: number;
  } | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [filterRarity, setFilterRarity] = useState<string>('all');

  const isVip = progress.isVip ?? false;
  const magnetLevel = progress.magnetLevel ?? 1;
  const shieldCharges = progress.shieldCharges ?? 0;
  const boostLevel = progress.boostDurationLevel ?? 1;
  const nitroRecharge = progress.nitroRechargeLevel ?? 1;
  const doubleCoinsPerma = progress.doubleCoinsPerma ?? false;
  const gliderWings = progress.gliderWings ?? false;
  const iceBreaker = progress.iceBreaker ?? false;
  const alpineGrips = progress.alpineGrips ?? false;
  const diamondMiner = progress.diamondMiner ?? false;
  const forestCloak = progress.forestCloak ?? false;
  const cosmicEngine = progress.cosmicEngine ?? false;
  const luckyCharm = progress.luckyCharm ?? false;
  const doubleGemsPerma = progress.doubleGemsPerma ?? false;
  const starlightThruster = progress.starlightThruster ?? false;
  const currentAura = progress.selectedAuraTrail ?? 'none';
  const unlockedAuras = progress.unlockedAuras || ['none'];
  const lang = getSavedLanguage();

  const showToast = (msg: string, isError = false) => {
    if (isError) {
      setErrorMessage(msg);
      setTimeout(() => setErrorMessage(null), 3000);
    } else {
      setSuccessMessage(msg);
      setTimeout(() => setSuccessMessage(null), 3000);
    }
  };

  // --- BOX PURCHASE ---
  const handleBuyBox = (box: typeof MYSTERY_BOXES[0], useGems = false) => {
    setErrorMessage(null);

    // Free for VIP
    if (isVip) {
      sound.playGate();
      startOpeningBox(box, 0, 0);
      return;
    }

    if (useGems || box.costCoins === 0) {
      if (progress.gems < box.costGems) {
        sound.playCrash();
        showToast(`You need ${box.costGems - progress.gems} more 💎 Diamonds to open this box!`, true);
        return;
      }
      onDeductCurrency(0, box.costGems);
      startOpeningBox(box, 0, box.costGems);
    } else {
      if (progress.coins < box.costCoins) {
        sound.playCrash();
        showToast(`You need ${(box.costCoins - progress.coins).toLocaleString()} more 🪙 Coins to open this box!`, true);
        return;
      }
      onDeductCurrency(box.costCoins, 0);
      startOpeningBox(box, box.costCoins, 0);
    }
  };

  const startOpeningBox = (box: typeof MYSTERY_BOXES[0], spentCoins: number, spentGems: number) => {
    setSelectedBox(box);
    setModalState('opening');
    sound.playZoneTransition();

    const result = openMysteryBox(box, progress.unlockedCharacters);
    setUnboxedResult(result);

    setTimeout(() => {
      setModalState('revealed');
      if (result.character.rarity === 'mythic' || result.character.rarity === 'legendary') {
        sound.playStarChime();
        sound.playPowerUp();
      } else {
        sound.playDoubleCoins();
      }

      if (result.isDuplicate) {
        onAddCurrency(result.refundCoins, result.refundGems);
      } else {
        onUnlockCharacter(result.character.id);
      }
    }, 1800);
  };

  // --- GEAR UPGRADES ---
  const handleUpgradeMagnet = () => {
    if (magnetLevel >= 10) return;
    const costs = [0, 2500, 6000, 12000, 20000, 32000, 45000, 60000, 80000, 100000];
    const cost = costs[magnetLevel];
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playPowerUp();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        magnetLevel: magnetLevel + 1,
      }));
    }
    showToast(`Magnet upgraded to Level ${magnetLevel + 1}! (${9 + (magnetLevel) * 7}m pull range)`);
  };

  const handleBuyShieldCharge = () => {
    if (shieldCharges >= 5) return;
    const costs = [5000, 12000, 25000, 45000, 75000];
    const cost = costs[shieldCharges];
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playPowerUp();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        shieldCharges: shieldCharges + 1,
      }));
    }
    showToast(`Added +1 Titan Deflector Shield! (Total: ${shieldCharges + 1})`);
  };

  const handleUpgradeNitroRecharge = () => {
    if (nitroRecharge >= 5) return;
    const costs = [0, 3500, 9000, 20000, 40000];
    const cost = costs[nitroRecharge];
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playBoost();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        nitroRechargeLevel: nitroRecharge + 1,
      }));
    }
    showToast(`Nitro Recharge upgraded to Level ${nitroRecharge + 1}! (+${(nitroRecharge) * 35}% faster regen)`);
  };

  const handleBuyGliderWings = () => {
    if (gliderWings) return;
    const cost = 18000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playStarChime();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        gliderWings: true,
      }));
    }
    showToast('Aero Glider Wings Unlocked! Floaty airtime & huge stunts!');
  };

  const handleBuyIceBreaker = () => {
    if (iceBreaker) return;
    const cost = 22000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playPowerUp();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        iceBreaker: true,
      }));
    }
    showToast('Ice Breaker Kinetic Shocker Unlocked! Shatter obstacles for +500 pts!');
  };

  const handleBuyAlpineGrips = () => {
    if (alpineGrips) return;
    const cost = 16000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playGate();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        alpineGrips: true,
      }));
    }
    showToast('Pro Slalom Alpine Grips Unlocked! Zero icy slip & +25% agility!');
  };

  const handleBuyDiamondMiner = () => {
    if (diamondMiner) return;
    const cost = 45000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playGem();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        diamondMiner: true,
      }));
    }
    showToast('Diamond Miner Pickaxe Unlocked! Bonus Diamond drops downhill!');
  };

  const handleBuyPermaDoubleCoins = () => {
    if (doubleCoinsPerma) return;
    const cost = 35000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playDoubleCoins();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        doubleCoinsPerma: true,
      }));
    }
    showToast('Permanent 2X Coins Token Activated!');
  };

  const handleBuyForestCloak = () => {
    if (forestCloak) return;
    const cost = 28000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playZoneTransition();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({ ...prev, forestCloak: true }));
    }
    showToast('Camo Forest Cloak Unlocked! Tree crash absorption & +500 forest bonus coins!');
  };

  const handleBuyCosmicEngine = () => {
    if (cosmicEngine) return;
    const cost = 50000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playZoneTransition();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({ ...prev, cosmicEngine: true }));
    }
    showToast('Anti-Gravity Warp Engine Unlocked! 2.5x Airtime Stunts & Zero-G Space Glide!');
  };

  const handleBuyLuckyCharm = () => {
    if (luckyCharm) return;
    const cost = 30000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playStarChime();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({ ...prev, luckyCharm: true }));
    }
    showToast('Golden Horseshoe Unlocked! +25% luck on boxes & wheels!');
  };

  const handleBuyPermaDoubleGems = () => {
    if (doubleGemsPerma) return;
    const cost = 60000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playGem();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({ ...prev, doubleGemsPerma: true }));
    }
    showToast('Permanent 2X Gems Multiplier Activated! Doubles every mountain diamond forever!');
  };

  const handleBuyStarlightThruster = () => {
    if (starlightThruster) return;
    const cost = 40000;
    if (progress.coins < cost && !isVip) {
      sound.playCrash();
      showToast(`Need ${(cost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(cost, 0);
    sound.playZoneTransition();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({ ...prev, starlightThruster: true }));
    }
    showToast('Starlight Nitro Thruster Unlocked! Instant max boost refill & glowing starlight wake!');
  };

  // --- EXPANDED AURA TRAILS (10 Auras) ---
  const AURAS_LIST = [
    { id: 'none', name: 'Standard Alpine White', desc: 'Default fresh alpine powdery snow spray', icon: '❄️', costCoins: 0, costGems: 0 },
    { id: 'rainbow', name: 'Rainbow Slipstream', desc: 'Multicolor rainbow sparkle ribbons', icon: '🌈', costCoins: 8000, costGems: 15 },
    { id: 'fire', name: 'Inferno Flame Jet', desc: 'Blazing orange fiery booster exhaust', icon: '🔥', costCoins: 14000, costGems: 25 },
    { id: 'neon', name: 'Cyber Neon Grid', desc: 'Futuristic electric cyan laser particles', icon: '⚡', costCoins: 20000, costGems: 35 },
    { id: 'golden', name: 'Midas Gold Radiance', desc: 'Pure gleaming golden coin sparks', icon: '👑', costCoins: 35000, costGems: 50 },
    { id: 'cosmic', name: 'Cosmic Starlight', desc: 'Deep space magenta nebula stardust', icon: '🌌', costCoins: 50000, costGems: 80 },
    { id: 'sakura', name: 'Sakura Petal Drift', desc: 'Flowing cherry blossom pink flower petals', icon: '🌸', costCoins: 18000, costGems: 30 },
    { id: 'candy', name: 'Candy Lollipop Confetti', desc: 'Sweet peppermint sparkles and sprinkles', icon: '🍭', costCoins: 22000, costGems: 35 },
    { id: 'ghost', name: 'Spectral Phantom Mist', desc: 'Eerie glowing emerald spectral embers', icon: '👻', costCoins: 26000, costGems: 40 },
    { id: 'thunder', name: 'Thunderbolt Electric Arc', desc: 'Crackling blue lightning sparks along your track', icon: '🌩️', costCoins: 38000, costGems: 60 },
    { id: 'diamond', name: 'Prismatic Diamond Shimmer', desc: 'Glittering crystal diamond facets and shine', icon: '💎', costCoins: 65000, costGems: 95 },
  ];

  const handleBuyAura = (aura: typeof AURAS_LIST[0]) => {
    const isOwned = unlockedAuras.includes(aura.id);
    if (isOwned) {
      sound.playGate();
      if (onUpdateProgress) {
        onUpdateProgress((prev) => ({ ...prev, selectedAuraTrail: aura.id }));
      }
      showToast(`Equipped ${aura.name}!`);
      return;
    }

    if (progress.coins < aura.costCoins && !isVip) {
      sound.playCrash();
      showToast(`Need ${(aura.costCoins - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }

    if (!isVip) onDeductCurrency(aura.costCoins, 0);
    sound.playStarChime();
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        unlockedAuras: [...(prev.unlockedAuras || ['none']), aura.id],
        selectedAuraTrail: aura.id,
      }));
    }
    showToast(`Unlocked and equipped ${aura.name}!`);
  };

  // --- CURRENCY EXCHANGE ---
  const handleExchangeCoinsToGems = (coinsCost: number, gemsGained: number) => {
    if (progress.coins < coinsCost) {
      sound.playCrash();
      showToast(`You need ${(coinsCost - progress.coins).toLocaleString()} more coins!`, true);
      return;
    }
    sound.playGem();
    onDeductCurrency(coinsCost, 0);
    onAddCurrency(0, gemsGained);
    showToast(`Exchanged ${coinsCost.toLocaleString()} Coins for +${gemsGained} 💎 Diamonds!`);
  };

  const handleExchangeGemsToCoins = (gemsCost: number, coinsGained: number) => {
    if (progress.gems < gemsCost) {
      sound.playCrash();
      showToast(`You need ${gemsCost - progress.gems} more diamonds!`, true);
      return;
    }
    sound.playDoubleCoins();
    onDeductCurrency(0, gemsCost);
    onAddCurrency(coinsGained, 0);
    showToast(`Exchanged ${gemsCost} Diamonds for +${coinsGained.toLocaleString()} 🪙 Coins!`);
  };

  // --- BUNDLES ---
  const handleBuySakuraBundle = () => {
    const costGems = 45;
    if (progress.gems < costGems && !isVip) {
      sound.playCrash();
      showToast(`You need ${costGems - progress.gems} more diamonds!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(0, costGems);
    sound.playStarChime();
    onAddCurrency(60000, 50);
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        unlockedAuras: Array.from(new Set([...(prev.unlockedAuras || []), 'sakura'])),
        selectedAuraTrail: 'sakura',
      }));
    }
    showToast('Sakura Spring Pack Claimed! +60K 🪙, +50 💎 & Sakura Trail!');
  };

  const handleBuyCandyBundle = () => {
    const costGems = 70;
    if (progress.gems < costGems && !isVip) {
      sound.playCrash();
      showToast(`You need ${costGems - progress.gems} more diamonds!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(0, costGems);
    sound.playPowerUp();
    onAddCurrency(120000, 0);
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        iceBreaker: true,
        unlockedAuras: Array.from(new Set([...(prev.unlockedAuras || []), 'candy'])),
        selectedAuraTrail: 'candy',
      }));
    }
    showToast('Candy Wonderland Pack Claimed! +120K 🪙, Ice Breaker & Candy Trail!');
  };

  const handleBuyMegaChampionBundle = () => {
    const costGems = 85;
    if (progress.gems < costGems && !isVip) {
      sound.playCrash();
      showToast(`You need ${costGems - progress.gems} more diamonds!`, true);
      return;
    }
    if (!isVip) onDeductCurrency(0, costGems);
    sound.playStarChime();
    sound.playPowerUp();
    onAddCurrency(100000, 100);
    if (onUpdateProgress) {
      onUpdateProgress((prev) => ({
        ...prev,
        doubleCoinsPerma: true,
        gliderWings: true,
        unlockedAuras: Array.from(new Set([...(prev.unlockedAuras || []), 'golden', 'rainbow'])),
        selectedAuraTrail: 'golden',
      }));
    }
    showToast('Mega Champion Bundle Activated! +100K 🪙, +100 💎, Golden Aura & Wings!');
  };

  const handleOpenLuckySack = () => {
    const costGems = 5;
    if (progress.gems < costGems && !isVip) {
      sound.playCrash();
      showToast('Need 5 diamonds to open the Lucky Surprise Sack!', true);
      return;
    }
    if (!isVip) onDeductCurrency(0, costGems);
    sound.playDoubleCoins();
    const bonusCoins = Math.floor(Math.random() * 30000) + 10000;
    const bonusGems = Math.floor(Math.random() * 15) + 5;
    onAddCurrency(bonusCoins, bonusGems);
    showToast(`Lucky Sack popped! Awarded +${bonusCoins.toLocaleString()} 🪙 and +${bonusGems} 💎!`);
  };

  // Helper for Rarity Badges
  const getRarityBadge = (rarity: string = 'common') => {
    switch (rarity) {
      case 'mythic':
        return {
          label: 'MYTHIC',
          bg: 'bg-rose-500/20 text-rose-300 border-rose-500/50',
          glow: 'shadow-[0_0_20px_rgba(244,63,94,0.6)]',
          color: 'text-rose-400',
        };
      case 'legendary':
        return {
          label: 'LEGENDARY',
          bg: 'bg-amber-500/20 text-amber-300 border-amber-500/50',
          glow: 'shadow-[0_0_20px_rgba(245,158,11,0.6)]',
          color: 'text-amber-400',
        };
      case 'epic':
        return {
          label: 'EPIC',
          bg: 'bg-purple-500/20 text-purple-300 border-purple-500/50',
          glow: 'shadow-[0_0_20px_rgba(168,85,247,0.5)]',
          color: 'text-purple-400',
        };
      case 'rare':
        return {
          label: 'RARE',
          bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
          glow: 'shadow-[0_0_15px_rgba(6,182,212,0.4)]',
          color: 'text-cyan-400',
        };
      default:
        return {
          label: 'COMMON',
          bg: 'bg-slate-500/20 text-slate-300 border-slate-500/40',
          glow: '',
          color: 'text-slate-300',
        };
    }
  };

  const filteredCharacters = CHARACTERS.filter((c) => {
    if (filterRarity === 'all') return true;
    return c.rarity === filterRarity;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-slate-900/95 border-2 border-amber-500/50 rounded-3xl shadow-2xl overflow-hidden p-3 sm:p-5 text-white h-[94vh] sm:h-[88vh] flex flex-col">
        
        {/* Floating Toast Alert */}
        {(errorMessage || successMessage) && (
          <div className={`absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full font-black font-race text-xs sm:text-sm shadow-xl flex items-center gap-2 animate-bounce ${
            errorMessage ? 'bg-rose-500 text-white shadow-rose-500/30' : 'bg-emerald-500 text-slate-950 shadow-emerald-500/30'
          }`}>
            {errorMessage ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
            {errorMessage || successMessage}
          </div>
        )}

        {/* 1. Header with Currency & VIP indicator */}
        <div className="flex items-center justify-between pb-2.5 sm:pb-3 border-b border-slate-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 sm:p-2.5 bg-gradient-to-tr from-amber-500 to-yellow-300 rounded-2xl shadow-lg shadow-amber-500/25 text-slate-950 flex-shrink-0">
              <ShoppingBag className="w-5 h-5 sm:w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-xl font-black font-race tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-300 to-amber-500">
                  DOWNHILL MEGA SHOP
                </h2>
                {isVip && (
                  <span className="px-2 py-0.5 text-[9px] sm:text-[10px] font-black rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1 font-race">
                    <Crown className="w-3 h-3 text-amber-400" />
                    VIP FREE PASS
                  </span>
                )}
              </div>
              <p className="text-[10px] sm:text-xs text-slate-400 truncate">
                Mystery Crates, Gear Boosters, 10 Aura Trails &amp; Bundles
              </p>
            </div>
          </div>

          {/* Right Wallet Status */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1 rounded-xl border border-amber-500/30">
              <Coins className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400" />
              <span className="font-race font-bold text-xs sm:text-sm text-amber-300">
                {progress.coins.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-950/80 px-2.5 py-1 rounded-xl border border-cyan-500/30">
              <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
              <span className="font-race font-bold text-xs sm:text-sm text-cyan-300">
                {progress.gems.toLocaleString()}
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer active:scale-95"
              aria-label="Close Shop"
            >
              <X className="w-5 h-5 sm:w-6 h-6" />
            </button>
          </div>
        </div>

        {/* 2. Mobile Touch-Optimized Shop Tabs */}
        <div className="flex items-center gap-1 sm:gap-1.5 bg-slate-950/80 p-1 rounded-2xl border border-white/5 my-2.5 flex-shrink-0 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              sound.playGate();
              setActiveTab('boxes');
              setModalState('shop');
            }}
            className={`flex-1 py-1.5 sm:py-2 px-2.5 rounded-xl font-race font-bold text-[11px] sm:text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap min-h-[38px] ${
              activeTab === 'boxes'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>1. Crates</span>
          </button>

          <button
            onClick={() => {
              sound.playGate();
              setActiveTab('upgrades');
              setModalState('shop');
            }}
            className={`flex-1 py-1.5 sm:py-2 px-2.5 rounded-xl font-race font-bold text-[11px] sm:text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap min-h-[38px] ${
              activeTab === 'upgrades'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>2. Gear (13)</span>
          </button>

          <button
            onClick={() => {
              sound.playGate();
              setActiveTab('auras');
              setModalState('shop');
            }}
            className={`flex-1 py-1.5 sm:py-2 px-2.5 rounded-xl font-race font-bold text-[11px] sm:text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap min-h-[38px] ${
              activeTab === 'auras'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>3. Auras (11)</span>
          </button>

          <button
            onClick={() => {
              sound.playGate();
              setActiveTab('exchange');
              setModalState('shop');
            }}
            className={`flex-1 py-1.5 sm:py-2 px-2.5 rounded-xl font-race font-bold text-[11px] sm:text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap min-h-[38px] ${
              activeTab === 'exchange'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>4. Bundles</span>
          </button>

          <button
            onClick={() => {
              sound.playGate();
              setActiveTab('roster');
              setModalState('shop');
            }}
            className={`flex-1 py-1.5 sm:py-2 px-2.5 rounded-xl font-race font-bold text-[11px] sm:text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1 cursor-pointer whitespace-nowrap min-h-[38px] ${
              activeTab === 'roster'
                ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>5. Racers (150)</span>
          </button>
        </div>

        {/* 3. Main Content Scroll Area */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-3 scrollbar-thin scrollbar-thumb-slate-700">

          {/* TAB 1: MYSTERY CRATES */}
          {activeTab === 'boxes' && (
            <>
              {modalState === 'shop' && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {MYSTERY_BOXES.map((box) => {
                    const canAffordCoins = progress.coins >= box.costCoins && box.costCoins > 0;
                    const canAffordGems = progress.gems >= box.costGems && box.costGems > 0;

                    return (
                      <div
                        key={box.id}
                        className={`bg-slate-950/70 border rounded-2xl p-4 flex flex-col justify-between transition-all hover:scale-[1.01] ${box.borderColor} relative overflow-hidden`}
                      >
                        {box.id === 'mythic' && (
                          <div className="absolute -top-12 -right-12 w-28 h-28 bg-rose-500/20 rounded-full blur-2xl pointer-events-none" />
                        )}

                        <div>
                          {/* Box Header */}
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-3xl sm:text-4xl">{box.icon}</span>
                            <span className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border ${box.badge} font-race`}>
                              {box.id} CRATE
                            </span>
                          </div>

                          <h3 className="font-race font-black text-base sm:text-lg text-white mb-1">
                            {box.name}
                          </h3>
                          <p className="text-xs text-slate-300 mb-3 line-clamp-2">
                            {box.description}
                          </p>

                          {/* Probability Drop Rates Bar */}
                          <div className="bg-slate-900/90 rounded-xl p-2.5 border border-white/5 space-y-1.5 mb-3">
                            <div className="text-[10px] font-race font-bold uppercase text-slate-400 tracking-wider">
                              Drop Probabilities:
                            </div>
                            <div className="flex h-2 rounded-full overflow-hidden bg-slate-800">
                              <div style={{ width: `${box.odds.common}%` }} className="bg-slate-400" title={`Common ${box.odds.common}%`} />
                              <div style={{ width: `${box.odds.rare}%` }} className="bg-cyan-400" title={`Rare ${box.odds.rare}%`} />
                              <div style={{ width: `${box.odds.epic}%` }} className="bg-purple-500" title={`Epic ${box.odds.epic}%`} />
                              <div style={{ width: `${box.odds.legendary}%` }} className="bg-amber-400" title={`Legendary ${box.odds.legendary}%`} />
                              <div style={{ width: `${box.odds.mythic}%` }} className="bg-rose-500" title={`Mythic ${box.odds.mythic}%`} />
                            </div>
                            <div className="grid grid-cols-5 gap-1 text-[9px] font-race font-bold text-center pt-0.5">
                              <span className="text-slate-400">Com: {box.odds.common}%</span>
                              <span className="text-cyan-400">Rare: {box.odds.rare}%</span>
                              <span className="text-purple-400">Epic: {box.odds.epic}%</span>
                              <span className="text-amber-400">Leg: {box.odds.legendary}%</span>
                              <span className="text-rose-400">Myt: {box.odds.mythic}%</span>
                            </div>
                          </div>
                        </div>

                        {/* Purchase Buttons */}
                        <div className="space-y-1.5 pt-1">
                          {isVip ? (
                            <button
                              onClick={() => handleBuyBox(box)}
                              className="w-full py-2.5 px-3 rounded-xl font-race font-black text-xs bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-slate-950 flex items-center justify-center gap-1.5 shadow-lg shadow-amber-400/20 cursor-pointer active:scale-95"
                            >
                              <Crown className="w-4 h-4 text-slate-950" />
                              <span>OPEN FREE (VIP PASS)</span>
                            </button>
                          ) : (
                            <div className="flex gap-2">
                              {box.costCoins > 0 && (
                                <button
                                  onClick={() => handleBuyBox(box, false)}
                                  disabled={!canAffordCoins}
                                  className={`flex-1 py-2.5 px-2 rounded-xl font-race font-black text-xs flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 ${
                                    canAffordCoins
                                      ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                                      : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                                  }`}
                                >
                                  <Coins className="w-3.5 h-3.5" />
                                  <span>{box.costCoins.toLocaleString()}</span>
                                </button>
                              )}

                              {box.costGems > 0 && (
                                <button
                                  onClick={() => handleBuyBox(box, true)}
                                  disabled={!canAffordGems}
                                  className={`flex-1 py-2.5 px-2 rounded-xl font-race font-black text-xs flex items-center justify-center gap-1 transition-all cursor-pointer active:scale-95 ${
                                    canAffordGems
                                      ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
                                      : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                                  }`}
                                >
                                  <Sparkles className="w-3.5 h-3.5" />
                                  <span>{box.costGems} Gems</span>
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* UNBOXING ANIMATION */}
              {modalState === 'opening' && (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-5 animate-pulse">
                  <div className="text-7xl sm:text-8xl animate-bounce">
                    {selectedBox.icon}
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-race font-black text-2xl sm:text-3xl text-amber-300 tracking-wider">
                      UNBOXING {selectedBox.name.toUpperCase()}...
                    </h3>
                    <p className="text-sm text-slate-400">
                      Rolling downhill probabilities across all 35 racers...
                    </p>
                  </div>
                  <div className="w-48 h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-amber-400 via-rose-500 to-purple-500 w-full animate-pulse" />
                  </div>
                </div>
              )}

              {/* REVEALED RESULT */}
              {modalState === 'revealed' && unboxedResult && (
                <div className="h-full flex flex-col items-center justify-center text-center p-4 sm:p-6 space-y-4">
                  <div className={`p-6 rounded-3xl bg-slate-950/80 border-2 ${getRarityBadge(unboxedResult.character.rarity).bg} ${getRarityBadge(unboxedResult.character.rarity).glow} max-w-md w-full relative overflow-hidden`}>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-4xl">
                        {unboxedResult.character.vehicleType === 'skis' ? '⛷️' :
                         unboxedResult.character.vehicleType === 'yeti_stride' ? '🐾' :
                         unboxedResult.character.vehicleType === 'roller_skates' ? '🛼' :
                         unboxedResult.character.vehicleType === 'hoverboard' ? '🛸' : '🏂'}
                      </span>
                      <span className={`text-xs font-black uppercase px-3 py-1 rounded-full border ${getRarityBadge(unboxedResult.character.rarity).bg} font-race`}>
                        {getRarityBadge(unboxedResult.character.rarity).label} RACER
                      </span>
                    </div>

                    <div className="space-y-1 mb-4">
                      <div className="text-2xl sm:text-3xl font-race font-black text-white">
                        {unboxedResult.character.name}
                      </div>
                      <div className="text-xs text-slate-300">
                        {unboxedResult.character.title}
                      </div>
                    </div>

                    {unboxedResult.isDuplicate ? (
                      <div className="bg-amber-950/50 border border-amber-500/40 rounded-xl p-3 mb-4 text-xs text-amber-200">
                        <div className="font-race font-bold uppercase tracking-wider text-amber-400 flex items-center justify-center gap-1 mb-1">
                          <CheckCircle2 className="w-4 h-4" /> Already in your Roster!
                        </div>
                        <div>
                          Duplicate bonus refund awarded: <strong className="text-amber-300">+{unboxedResult.refundCoins.toLocaleString()} 🪙</strong> {unboxedResult.refundGems > 0 && <strong className="text-cyan-300">+{unboxedResult.refundGems} 💎</strong>}
                        </div>
                      </div>
                    ) : (
                      <div className="bg-emerald-950/50 border border-emerald-500/40 rounded-xl p-3 mb-4 text-xs text-emerald-200">
                        <div className="font-race font-bold uppercase tracking-wider text-emerald-400 flex items-center justify-center gap-1 mb-1">
                          <Sparkles className="w-4 h-4" /> NEW RACER UNLOCKED!
                        </div>
                        <div>Added permanently to your collection of 35 downhill champions!</div>
                      </div>
                    )}

                    <div className="bg-slate-900/80 rounded-xl p-3 text-left border border-white/5 space-y-1 text-xs mb-4">
                      <div className="font-race font-bold text-amber-300 text-[10px] uppercase">
                        Signature Trait
                      </div>
                      <div className="text-slate-300">
                        {unboxedResult.character.specialAbility}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          sound.playGate();
                          onSelectCharacter(unboxedResult.character.id);
                          onClose();
                        }}
                        className="flex-1 py-3 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black font-race text-xs rounded-xl shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <Check className="w-4 h-4" />
                        <span>EQUIP RACER</span>
                      </button>

                      <button
                        onClick={() => {
                          sound.playGate();
                          setModalState('shop');
                        }}
                        className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-white font-black font-race text-xs rounded-xl cursor-pointer active:scale-95"
                      >
                        BACK TO CRATES
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}

          {/* TAB 2: EXPANDED GEAR UPGRADES (8 POWER ITEMS) */}
          {activeTab === 'upgrades' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Upgrade 1: Mega Vacuum Magnet (Up to Lvl 10) */}
              <div className="bg-slate-950/70 border border-purple-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-purple-500/20 text-purple-400 rounded-xl"><Magnet className="w-5 h-5" /></span>
                    <span className="text-[10px] font-black font-race bg-purple-500/30 text-purple-200 px-2.5 py-0.5 rounded-full">
                      Lvl {magnetLevel}/10
                    </span>
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Mega Vacuum Coin Magnet</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Pulls coins &amp; diamonds from up to {9 + (magnetLevel - 1) * 7}m distance! Max level pulls 72m!
                  </p>
                </div>
                <button
                  onClick={handleUpgradeMagnet}
                  disabled={magnetLevel >= 10}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    magnetLevel >= 10 ? 'bg-slate-800 text-slate-500' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-purple-500 hover:bg-purple-400 text-white'
                  }`}
                >
                  {magnetLevel >= 10 ? 'MAX LEVEL' : isVip ? 'UPGRADE FREE (VIP)' : `UPGRADE (${[0, 2500, 6000, 12000, 20000, 32000, 45000, 60000, 80000, 100000][magnetLevel].toLocaleString()} 🪙)`}
                </button>
              </div>

              {/* Upgrade 2: Titan Crash Deflector Shields (Up to 5) */}
              <div className="bg-slate-950/70 border border-sky-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-sky-500/20 text-sky-400 rounded-xl"><ShieldCheck className="w-5 h-5" /></span>
                    <span className="text-[10px] font-black font-race bg-sky-500/30 text-sky-200 px-2.5 py-0.5 rounded-full">
                      {shieldCharges}/5 Charges
                    </span>
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Titan Crash Deflector Shields</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Absorb obstacle hits with kinetic explosions instead of wiping out!
                  </p>
                </div>
                <button
                  onClick={handleBuyShieldCharge}
                  disabled={shieldCharges >= 5}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    shieldCharges >= 5 ? 'bg-slate-800 text-slate-500' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                  }`}
                >
                  {shieldCharges >= 5 ? 'MAX CHARGES' : isVip ? 'ADD FREE (VIP)' : `BUY CHARGE (${[5000, 12000, 25000, 45000, 75000][shieldCharges].toLocaleString()} 🪙)`}
                </button>
              </div>

              {/* Upgrade 3: Nitro Thruster Turbo Recharge */}
              <div className="bg-slate-950/70 border border-cyan-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-cyan-500/20 text-cyan-400 rounded-xl"><Gauge className="w-5 h-5" /></span>
                    <span className="text-[10px] font-black font-race bg-cyan-500/30 text-cyan-200 px-2.5 py-0.5 rounded-full">
                      Lvl {nitroRecharge}/5
                    </span>
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Nitro Turbo Recharge</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Regenerate your rocket boost meter up to 2.5x faster between carves and stunts!
                  </p>
                </div>
                <button
                  onClick={handleUpgradeNitroRecharge}
                  disabled={nitroRecharge >= 5}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    nitroRecharge >= 5 ? 'bg-slate-800 text-slate-500' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                  }`}
                >
                  {nitroRecharge >= 5 ? 'MAX LEVEL' : isVip ? 'UPGRADE FREE (VIP)' : `UPGRADE (${[0, 3500, 9000, 20000, 40000][nitroRecharge].toLocaleString()} 🪙)`}
                </button>
              </div>

              {/* Upgrade 4: Aero Glider Parachute Wings */}
              <div className="bg-slate-950/70 border border-amber-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-amber-500/20 text-amber-400 rounded-xl"><Feather className="w-5 h-5" /></span>
                    {gliderWings && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Aero Glider Parachute Wings</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    50% reduced jump gravity for long floaty hang-time and easy double flips.
                  </p>
                </div>
                <button
                  onClick={handleBuyGliderWings}
                  disabled={gliderWings}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    gliderWings ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                  }`}
                >
                  {gliderWings ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (18,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 5: Ice Breaker Kinetic Shocker */}
              <div className="bg-slate-950/70 border border-blue-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-blue-500/20 text-blue-400 rounded-xl"><Zap className="w-5 h-5" /></span>
                    {iceBreaker && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Ice Breaker Kinetic Shocker</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Shatters obstacles with freezing shockwaves and yields +500 bonus score!
                  </p>
                </div>
                <button
                  onClick={handleBuyIceBreaker}
                  disabled={iceBreaker}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    iceBreaker ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-blue-500 hover:bg-blue-400 text-white'
                  }`}
                >
                  {iceBreaker ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (22,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 6: Pro Slalom Alpine Grips */}
              <div className="bg-slate-950/70 border border-teal-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-teal-500/20 text-teal-400 rounded-xl"><Compass className="w-5 h-5" /></span>
                    {alpineGrips && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Pro Slalom Alpine Grips</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    +25% sharper carve arcs and zero drift slippage across frozen glaciers!
                  </p>
                </div>
                <button
                  onClick={handleBuyAlpineGrips}
                  disabled={alpineGrips}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    alpineGrips ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-teal-500 hover:bg-teal-400 text-slate-950'
                  }`}
                >
                  {alpineGrips ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (16,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 7: Diamond Miner Pickaxe */}
              <div className="bg-slate-950/70 border border-emerald-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl"><Gem className="w-5 h-5" /></span>
                    {diamondMiner && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Diamond Miner Pickaxe</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Excavates rare diamond clusters on high-speed downhill slopes!
                  </p>
                </div>
                <button
                  onClick={handleBuyDiamondMiner}
                  disabled={diamondMiner}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    diamondMiner ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                  }`}
                >
                  {diamondMiner ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (45,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 8: Permanent 2X Coin Multiplier */}
              <div className="bg-slate-950/70 border border-yellow-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-yellow-500/20 text-yellow-400 rounded-xl"><Coins className="w-5 h-5" /></span>
                    {doubleCoinsPerma && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">PERMANENT</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">Permanent 2X Coin Doubler</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    Doubles every single coin collected on every single run forever!
                  </p>
                </div>
                <button
                  onClick={handleBuyPermaDoubleCoins}
                  disabled={doubleCoinsPerma}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    doubleCoinsPerma ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-gradient-to-r from-yellow-400 to-amber-500 text-slate-950'
                  }`}
                >
                  {doubleCoinsPerma ? 'ACTIVE FOREVER' : isVip ? 'CLAIM FREE (VIP)' : 'UNLOCK (35,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 9: Camo Forest Cloak */}
              <div className="bg-slate-950/70 border border-emerald-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl">🌲</span>
                    {forestCloak && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">{t('gear_forestCloak', lang)}</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    {t('gear_desc_forestCloak', lang)}
                  </p>
                </div>
                <button
                  onClick={handleBuyForestCloak}
                  disabled={forestCloak}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    forestCloak ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  }`}
                >
                  {forestCloak ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (28,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 10: Anti-Gravity Warp Engine */}
              <div className="bg-slate-950/70 border border-indigo-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-indigo-500/20 text-indigo-400 rounded-xl">🪐</span>
                    {cosmicEngine && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">{t('gear_cosmicEngine', lang)}</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    {t('gear_desc_cosmicEngine', lang)}
                  </p>
                </div>
                <button
                  onClick={handleBuyCosmicEngine}
                  disabled={cosmicEngine}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    cosmicEngine ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {cosmicEngine ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (50,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 11: Golden Horseshoe Lucky Charm */}
              <div className="bg-slate-950/70 border border-yellow-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-yellow-500/20 text-yellow-400 rounded-xl">🧲</span>
                    {luckyCharm && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">{t('gear_luckyCharm', lang)}</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    {t('gear_desc_luckyCharm', lang)}
                  </p>
                </div>
                <button
                  onClick={handleBuyLuckyCharm}
                  disabled={luckyCharm}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    luckyCharm ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-yellow-500 hover:bg-yellow-400 text-slate-950'
                  }`}
                >
                  {luckyCharm ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (30,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 12: Permanent 2X Gem Multiplier */}
              <div className="bg-slate-950/70 border border-cyan-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-cyan-500/20 text-cyan-400 rounded-xl">💎</span>
                    {doubleGemsPerma && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">{t('gear_doubleGems', lang)}</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    {t('gear_desc_doubleGems', lang)}
                  </p>
                </div>
                <button
                  onClick={handleBuyPermaDoubleGems}
                  disabled={doubleGemsPerma}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    doubleGemsPerma ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-gradient-to-r from-cyan-400 to-blue-500 text-slate-950'
                  }`}
                >
                  {doubleGemsPerma ? 'ACTIVE FOREVER' : isVip ? 'CLAIM FREE (VIP)' : 'UNLOCK (60,000 🪙)'}
                </button>
              </div>

              {/* Upgrade 13: Starlight Nitro Thruster */}
              <div className="bg-slate-950/70 border border-fuchsia-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="p-2 bg-fuchsia-500/20 text-fuchsia-400 rounded-xl">✨</span>
                    {starlightThruster && <span className="text-[10px] font-black font-race bg-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded-full">ACTIVE</span>}
                  </div>
                  <h3 className="font-race font-black text-sm text-white">{t('gear_starlightThruster', lang)}</h3>
                  <p className="text-xs text-slate-300 mt-0.5 mb-3">
                    {t('gear_desc_starlightThruster', lang)}
                  </p>
                </div>
                <button
                  onClick={handleBuyStarlightThruster}
                  disabled={starlightThruster}
                  className={`w-full py-2 rounded-xl font-race font-black text-xs transition-all cursor-pointer min-h-[38px] ${
                    starlightThruster ? 'bg-slate-800 text-emerald-400' : isVip ? 'bg-amber-400 text-slate-950' : 'bg-fuchsia-600 hover:bg-fuchsia-500 text-white'
                  }`}
                >
                  {starlightThruster ? 'EQUIPPED' : isVip ? 'UNLOCK FREE (VIP)' : 'UNLOCK (40,000 🪙)'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: EXPANDED 11 AURA TRAILS */}
          {activeTab === 'auras' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {AURAS_LIST.map((aura) => {
                const isOwned = unlockedAuras.includes(aura.id);
                const isSelected = currentAura === aura.id;

                return (
                  <div
                    key={aura.id}
                    className={`bg-slate-950/70 border rounded-2xl p-3.5 flex flex-col justify-between transition-all ${
                      isSelected ? 'border-amber-400 ring-1 ring-amber-400 bg-amber-950/20' : 'border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-3xl">{aura.icon}</span>
                        {isSelected && (
                          <span className="text-[10px] font-black font-race bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Check className="w-3 h-3" /> EQUIPPED
                          </span>
                        )}
                        {!isSelected && isOwned && (
                          <span className="text-[10px] font-black font-race bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full">
                            OWNED
                          </span>
                        )}
                      </div>
                      <h4 className="font-race font-black text-sm text-white">{aura.name}</h4>
                      <p className="text-xs text-slate-400 mt-0.5 mb-3">{aura.desc}</p>
                    </div>

                    <button
                      onClick={() => handleBuyAura(aura)}
                      className={`w-full py-2 px-3 rounded-xl font-race font-black text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 min-h-[38px] ${
                        isSelected
                          ? 'bg-slate-800 text-slate-400 cursor-default'
                          : isOwned
                          ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                          : isVip
                          ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-slate-950'
                          : 'bg-amber-500 hover:bg-amber-400 text-slate-950'
                      }`}
                    >
                      {isSelected ? 'EQUIPPED' : isOwned ? 'EQUIP AURA' : isVip ? 'CLAIM FREE (VIP)' : `UNLOCK (${aura.costCoins.toLocaleString()} 🪙)`}
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 4: EXPANDED PACKS & BUNDLES */}
          {activeTab === 'exchange' && (
            <div className="space-y-3.5">
              {/* Daily Lucky Sack */}
              <div className="bg-gradient-to-r from-emerald-950/40 via-teal-950/30 to-slate-900 border border-emerald-500/50 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🎲</span>
                  <div>
                    <h3 className="font-race font-black text-sm sm:text-base text-emerald-300">Daily Mystery Lucky Sack</h3>
                    <p className="text-xs text-slate-300">Pop open for an instant burst of 10,000 to 40,000 coins &amp; bonus diamonds!</p>
                  </div>
                </div>
                <button
                  onClick={handleOpenLuckySack}
                  className="py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black font-race text-xs rounded-xl shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Dice5 className="w-4 h-4" />
                  <span>{isVip ? 'OPEN FREE (VIP)' : 'OPEN SACK (5 💎)'}</span>
                </button>
              </div>

              {/* Special Theme Bundles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* Bundle 1: Sakura Pack */}
                <div className="bg-slate-950/70 border border-pink-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-2xl">🌸</span>
                      <span className="text-[9px] font-black font-race bg-pink-500/30 text-pink-300 px-2 py-0.5 rounded-full">SPRING PACK</span>
                    </div>
                    <h4 className="font-race font-black text-sm text-white">Sakura Spring Festival</h4>
                    <p className="text-xs text-slate-300 mt-0.5 mb-3">Includes: Sakura Blossom Trail + 60,000 Coins + 50 Diamonds!</p>
                  </div>
                  <button
                    onClick={handleBuySakuraBundle}
                    className="w-full py-2 bg-gradient-to-r from-pink-500 to-rose-500 hover:brightness-110 text-white font-black font-race text-xs rounded-xl cursor-pointer"
                  >
                    {isVip ? 'CLAIM FREE (VIP)' : 'GET PACK (45 💎)'}
                  </button>
                </div>

                {/* Bundle 2: Candy Pack */}
                <div className="bg-slate-950/70 border border-rose-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-2xl">🍭</span>
                      <span className="text-[9px] font-black font-race bg-rose-500/30 text-rose-300 px-2 py-0.5 rounded-full">CANDY PACK</span>
                    </div>
                    <h4 className="font-race font-black text-sm text-white">Candy Wonderland Pack</h4>
                    <p className="text-xs text-slate-300 mt-0.5 mb-3">Includes: Candy Confetti Trail + Ice Breaker + 120,000 Coins!</p>
                  </div>
                  <button
                    onClick={handleBuyCandyBundle}
                    className="w-full py-2 bg-gradient-to-r from-rose-500 to-pink-500 hover:brightness-110 text-white font-black font-race text-xs rounded-xl cursor-pointer"
                  >
                    {isVip ? 'CLAIM FREE (VIP)' : 'GET PACK (70 💎)'}
                  </button>
                </div>

                {/* Bundle 3: Mega Champion Bundle */}
                <div className="bg-slate-950/70 border border-amber-500/40 rounded-2xl p-3.5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-2xl">👑</span>
                      <span className="text-[9px] font-black font-race bg-amber-500/30 text-amber-300 px-2 py-0.5 rounded-full">BEST VALUE</span>
                    </div>
                    <h4 className="font-race font-black text-sm text-white">Mega Champion Bundle</h4>
                    <p className="text-xs text-slate-300 mt-0.5 mb-3">Includes: +100K 🪙, +100 💎, 2X Token, Glider Wings &amp; Golden Aura!</p>
                  </div>
                  <button
                    onClick={handleBuyMegaChampionBundle}
                    className="w-full py-2 bg-gradient-to-r from-amber-400 to-yellow-400 hover:brightness-110 text-slate-950 font-black font-race text-xs rounded-xl cursor-pointer"
                  >
                    {isVip ? 'CLAIM FREE (VIP)' : 'GET BUNDLE (85 💎)'}
                  </button>
                </div>
              </div>

              {/* Currency Conversions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Coins to Diamonds */}
                <div className="bg-slate-950/70 border border-cyan-500/30 rounded-2xl p-3.5 space-y-2.5">
                  <div className="font-race font-black text-xs sm:text-sm text-cyan-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    Coin to Diamond Exchange
                  </div>
                  <div className="space-y-1.5">
                    <button
                      onClick={() => handleExchangeCoinsToGems(10000, 25)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>10,000 🪙</span>
                      <span className="text-cyan-400 font-black">➔ +25 💎</span>
                    </button>
                    <button
                      onClick={() => handleExchangeCoinsToGems(35000, 100)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>35,000 🪙</span>
                      <span className="text-cyan-400 font-black">➔ +100 💎</span>
                    </button>
                    <button
                      onClick={() => handleExchangeCoinsToGems(100000, 350)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>100,000 🪙</span>
                      <span className="text-cyan-400 font-black">➔ +350 💎</span>
                    </button>
                  </div>
                </div>

                {/* Diamonds to Coins */}
                <div className="bg-slate-950/70 border border-amber-500/30 rounded-2xl p-3.5 space-y-2.5">
                  <div className="font-race font-black text-xs sm:text-sm text-amber-300 flex items-center gap-2">
                    <Coins className="w-4 h-4" />
                    Diamond to Coin Exchange
                  </div>
                  <div className="space-y-1.5">
                    <button
                      onClick={() => handleExchangeGemsToCoins(20, 25000)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>20 💎</span>
                      <span className="text-amber-400 font-black">➔ +25,000 🪙</span>
                    </button>
                    <button
                      onClick={() => handleExchangeGemsToCoins(75, 120000)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>75 💎</span>
                      <span className="text-amber-400 font-black">➔ +120,000 🪙</span>
                    </button>
                    <button
                      onClick={() => handleExchangeGemsToCoins(200, 380000)}
                      className="w-full py-2 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-700/80 rounded-xl text-xs font-race font-bold flex items-center justify-between cursor-pointer"
                    >
                      <span>200 💎</span>
                      <span className="text-amber-400 font-black">➔ +380,000 🪙</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: 35 PLAYABLE RACERS ROSTER */}
          {activeTab === 'roster' && (
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {['all', 'mythic', 'legendary', 'epic', 'rare', 'common'].map((r) => (
                  <button
                    key={r}
                    onClick={() => setFilterRarity(r)}
                    className={`py-1 px-3 rounded-lg text-xs font-race font-bold capitalize transition-all cursor-pointer whitespace-nowrap ${
                      filterRarity === r
                        ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                        : 'bg-slate-800/80 text-slate-400 hover:text-white'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {filteredCharacters.map((char) => {
                  const unlocked = progress.unlockedCharacters.includes(char.id);
                  const isSelected = progress.selectedCharacter === char.id;
                  const rarityBadge = getRarityBadge(char.rarity);

                  return (
                    <div
                      key={char.id}
                      className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                        isSelected
                          ? 'border-cyan-400 bg-cyan-950/40 ring-1 ring-cyan-400'
                          : 'border-slate-800 bg-slate-950/60'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-2xl">
                            {char.vehicleType === 'skis' ? '⛷️' :
                             char.vehicleType === 'yeti_stride' ? '🐾' :
                             char.vehicleType === 'roller_skates' ? '🛼' :
                             char.vehicleType === 'hoverboard' ? '🛸' : '🏂'}
                          </span>
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded border ${rarityBadge.bg} font-race`}>
                            {char.rarity || 'common'}
                          </span>
                        </div>

                        <div className="font-race font-black text-sm text-white truncate">
                          {char.name}
                        </div>
                        <div className="text-[11px] text-slate-400 truncate mb-2">
                          {char.title}
                        </div>

                        <div className="text-[10px] text-slate-300 line-clamp-2 bg-slate-900/60 p-1.5 rounded-lg mb-2">
                          {char.specialAbility}
                        </div>
                      </div>

                      <div className="pt-1">
                        {isSelected ? (
                          <div className="w-full py-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 rounded-xl text-center text-xs font-race font-black flex items-center justify-center gap-1">
                            <Check className="w-3.5 h-3.5" /> EQUIPPED
                          </div>
                        ) : unlocked ? (
                          <button
                            onClick={() => {
                              sound.playGate();
                              onSelectCharacter(char.id);
                            }}
                            className="w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl text-center text-xs font-race font-bold transition-all cursor-pointer active:scale-95"
                          >
                            SELECT RACER
                          </button>
                        ) : (
                          <div className="w-full py-1.5 bg-slate-900/80 text-slate-500 border border-slate-800 rounded-xl text-center text-xs font-race font-bold flex items-center justify-center gap-1">
                            <span>LOCKED (CRATE DROP)</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* 4. Footer */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 flex-shrink-0">
          <span className="text-[11px] font-race truncate">
            Collection: <strong className="text-amber-400">{progress.unlockedCharacters.length}</strong> / 35 Racers Unlocked
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-race font-bold text-xs transition-all cursor-pointer active:scale-95"
          >
            Close Shop
          </button>
        </div>

      </div>
    </div>
  );
};
