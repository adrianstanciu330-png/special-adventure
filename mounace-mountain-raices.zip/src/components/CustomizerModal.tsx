import React, { useState } from 'react';
import { 
  CharacterDef, 
  CharacterCustomization, 
  CharacterId, 
  PlayerProgress,
} from '../types/game';
import { CHARACTERS, PALETTES, PATTERNS } from '../game/charactersConfig';
import { 
  Check, 
  Lock, 
  Sparkles, 
  X, 
  Zap, 
  Gauge, 
  Wind, 
  Flame, 
  ShieldCheck,
  Palette,
  RotateCw,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';
import { sound } from '../game/audio';

interface CustomizerModalProps {
  progress: PlayerProgress;
  onClose: () => void;
  onSelectCharacter: (id: CharacterId) => void;
  onUpdateCustomization: (characterId: CharacterId, customization: CharacterCustomization) => void;
  onUnlockCharacter: (id: CharacterId, cost: number) => void;
}

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  progress,
  onClose,
  onSelectCharacter,
  onUpdateCustomization,
  onUnlockCharacter,
}) => {
  const [activeTab, setActiveTab] = useState<'racers' | 'outfit' | 'gear'>('racers');
  const [selectedCharId, setSelectedCharId] = useState<CharacterId>(progress.selectedCharacter);

  const selectedDef = CHARACTERS.find((c) => c.id === selectedCharId) || CHARACTERS[0];
  const isUnlocked = progress.unlockedCharacters.includes(selectedCharId);
  const currentCustom = progress.customizations[selectedCharId] || selectedDef.defaultCustomization;

  const [customDraft, setCustomDraft] = useState<CharacterCustomization>(currentCustom);

  const handleSelectChar = (char: CharacterDef) => {
    sound.playGate();
    setSelectedCharId(char.id);
    const draft = progress.customizations[char.id] || char.defaultCustomization;
    setCustomDraft(draft);
    if (progress.unlockedCharacters.includes(char.id)) {
      onSelectCharacter(char.id);
    }
  };

  const handleApplyCustom = (newCustom: Partial<CharacterCustomization>) => {
    sound.playCoin();
    const updated = { ...customDraft, ...newCustom };
    setCustomDraft(updated);
    onUpdateCustomization(selectedCharId, updated);
  };

  const handleUnlock = () => {
    if (progress.isVip) {
      sound.playStarChime();
      sound.playPowerUp();
      onUnlockCharacter(selectedDef.id, 0);
      onSelectCharacter(selectedDef.id);
      return;
    }
    if (progress.coins >= selectedDef.unlockCost) {
      sound.playGem();
      onUnlockCharacter(selectedDef.id, selectedDef.unlockCost);
      onSelectCharacter(selectedDef.id);
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col pointer-events-none p-3 sm:p-6 overflow-hidden">
      {/* Top Header & Currencies Bar */}
      <div className="pointer-events-auto flex items-center justify-between bg-slate-900/80 backdrop-blur-xl border border-white/10 rounded-2xl px-5 py-3 shadow-2xl mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/20">
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-race font-extrabold text-white tracking-wide">
              RACE LAB & ATELIER
            </h1>
            <p className="text-[11px] text-cyan-200/70 hidden sm:block">
              Clear Blue Sky Showcase • Customize your racer & gear
            </p>
          </div>
        </div>

        {/* Currency & Actions */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-950/60 border border-amber-500/30 px-3.5 py-1.5 rounded-xl shadow-inner">
            <span className="text-base">🪙</span>
            <span className="font-race text-sm sm:text-base text-amber-300 font-bold tabular-nums">
              {progress.coins.toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 bg-slate-950/60 border border-cyan-500/30 px-3.5 py-1.5 rounded-xl shadow-inner">
            <span className="text-base">💎</span>
            <span className="font-race text-sm sm:text-base text-cyan-300 font-bold tabular-nums">
              {progress.gems.toLocaleString()}
            </span>
          </div>

          <button
            onClick={() => {
              sound.playJump();
              onClose();
            }}
            className="w-10 h-10 flex items-center justify-center bg-slate-800/80 hover:bg-slate-700/80 text-slate-300 hover:text-white rounded-xl transition-all cursor-pointer border border-white/10 hover:scale-105 active:scale-95"
            aria-label="Close Customizer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Split View: Left (Character in 3D Blue Sky) | Right (Customization Options) */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 items-stretch min-h-0">
        
        {/* Left Side: Unobstructed 3D character area with floating info pill */}
        <div className="flex-1 hidden md:flex flex-col justify-end p-4 pointer-events-none">
          <div className="w-fit bg-slate-900/70 backdrop-blur-md border border-white/15 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-race uppercase text-cyan-300 font-bold tracking-widest mb-1">
              <RotateCw className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
              <span>360° TURNTABLE PREVIEW</span>
            </div>
            <div className="text-xl font-race font-black text-white">
              {selectedDef.name}
            </div>
            <div className="text-xs text-slate-300 mt-0.5">
              {selectedDef.title}
            </div>
          </div>
        </div>

        {/* Right Side: Options Panel (All options docked neatly to the right) */}
        <div className="pointer-events-auto w-full md:w-[460px] lg:w-[500px] h-full flex flex-col bg-slate-900/90 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl p-5 overflow-hidden">
          
          {/* Navigation Tabs */}
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/70 rounded-2xl border border-white/5 mb-4">
            <button
              onClick={() => {
                sound.playGate();
                setActiveTab('racers');
              }}
              className={`py-2 px-3 rounded-xl font-race font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'racers'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <span>1. Racers</span>
            </button>

            <button
              onClick={() => {
                sound.playGate();
                setActiveTab('outfit');
              }}
              className={`py-2 px-3 rounded-xl font-race font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'outfit'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <span>2. Outfit</span>
            </button>

            <button
              onClick={() => {
                sound.playGate();
                setActiveTab('gear');
              }}
              className={`py-2 px-3 rounded-xl font-race font-bold text-xs uppercase tracking-wider transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                activeTab === 'gear'
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-black shadow-lg shadow-cyan-500/25'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <span>3. Gear</span>
            </button>
          </div>

          {/* Scrollable Content Container */}
          <div className="flex-1 overflow-y-auto pr-1 space-y-4 scrollbar-thin scrollbar-thumb-slate-700">
            
            {/* Tab 1: Racers & Unique Abilities */}
            {activeTab === 'racers' && (
              <div className="space-y-4">
                {/* Character Selection Grid */}
                <div>
                  <label className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 block mb-2">
                    Select Downhill Racer
                  </label>
                  <div className="grid grid-cols-2 gap-2.5">
                    {CHARACTERS.map((char) => {
                      const unlocked = progress.unlockedCharacters.includes(char.id);
                      const isSelected = selectedCharId === char.id;
                      return (
                        <button
                          key={char.id}
                          onClick={() => handleSelectChar(char)}
                          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                            isSelected
                              ? 'border-cyan-400 bg-cyan-950/60 shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400'
                              : 'border-slate-800 bg-slate-950/40 hover:bg-slate-800/60 text-slate-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-2xl">
                              {char.vehicleType === 'skis' ? '⛷️' : 
                               char.vehicleType === 'yeti_stride' ? '🐾' : 
                               char.vehicleType === 'roller_skates' ? '🛼' :
                               char.vehicleType === 'hoverboard' ? '🛸' : '🏂'}
                            </span>
                            <div className="flex items-center gap-1.5">
                              {char.rarity && (
                                <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${
                                  char.rarity === 'mythic' ? 'bg-fuchsia-500/20 text-fuchsia-300 border border-fuchsia-500/40' :
                                  char.rarity === 'legendary' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                                  char.rarity === 'epic' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40' :
                                  char.rarity === 'rare' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' :
                                  'bg-slate-700/40 text-slate-400'
                                }`}>
                                  {char.rarity}
                                </span>
                              )}
                              {!unlocked && (
                                <div className="p-1 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/40">
                                  <Lock className="w-3.5 h-3.5" />
                                </div>
                              )}
                              {isSelected && unlocked && (
                                <div className="p-1 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                                  <Check className="w-3.5 h-3.5" />
                                </div>
                              )}
                            </div>
                          </div>
                          <div>
                            <div className="font-race font-bold text-sm text-white truncate">{char.name}</div>
                            <div className="text-[10px] text-cyan-300/80 capitalize">{char.vehicleType.replace('_', ' ')}</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Selected Character Profile & Unlock Action */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-race font-extrabold text-base text-white">{selectedDef.name}</h3>
                        {selectedDef.rarity && (
                          <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                            selectedDef.rarity === 'mythic' ? 'bg-fuchsia-500/30 text-fuchsia-300 border border-fuchsia-400/50 shadow-sm shadow-fuchsia-500/30' :
                            selectedDef.rarity === 'legendary' ? 'bg-amber-500/30 text-amber-300 border border-amber-400/50 shadow-sm shadow-amber-500/30' :
                            selectedDef.rarity === 'epic' ? 'bg-purple-500/30 text-purple-300 border border-purple-400/50' :
                            selectedDef.rarity === 'rare' ? 'bg-blue-500/30 text-blue-300 border border-blue-400/50' :
                            'bg-slate-700/50 text-slate-300'
                          }`}>
                            {selectedDef.rarity}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">{selectedDef.title}</p>
                    </div>

                    {isUnlocked ? (
                      <span className="text-[11px] font-race font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-3 py-1 rounded-full flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5" /> EQUIPPED
                      </span>
                    ) : (
                      <button
                        onClick={handleUnlock}
                        disabled={!progress.isVip && progress.coins < selectedDef.unlockCost}
                        className={`px-3.5 py-1.5 rounded-xl font-race font-black text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                          progress.isVip
                            ? 'bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 shadow-lg shadow-amber-400/25 animate-pulse'
                            : progress.coins >= selectedDef.unlockCost
                            ? 'bg-gradient-to-r from-amber-400 to-yellow-500 hover:from-amber-300 hover:to-yellow-400 text-slate-950 shadow-lg shadow-amber-400/25'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                        }`}
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>{progress.isVip ? 'UNLOCK FREE (VIP)' : `UNLOCK (${selectedDef.unlockCost} 🪙)`}</span>
                      </button>
                    )}
                  </div>

                  {/* Special Ability Pill */}
                  <div className="bg-cyan-950/40 border border-cyan-800/40 rounded-xl p-3 flex items-start gap-2.5 text-xs text-cyan-200">
                    <Zap className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <div className="font-race font-bold text-amber-300 text-[11px] uppercase tracking-wider mb-0.5">Signature Trait</div>
                      <span>{selectedDef.specialAbility}</span>
                    </div>
                  </div>

                  {/* Stat Meters */}
                  <div className="space-y-2 pt-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <Gauge className="w-3.5 h-3.5 text-sky-400" /> Top Speed
                      </span>
                      <div className="w-36 bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                        <div className="bg-sky-400 h-full rounded-full transition-all duration-300" style={{ width: `${selectedDef.stats.speed * 10}%` }} />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <Wind className="w-3.5 h-3.5 text-emerald-400" /> Carving
                      </span>
                      <div className="w-36 bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                        <div className="bg-emerald-400 h-full rounded-full transition-all duration-300" style={{ width: `${selectedDef.stats.carving * 10}%` }} />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-purple-400" /> Airtime
                      </span>
                      <div className="w-36 bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                        <div className="bg-purple-400 h-full rounded-full transition-all duration-300" style={{ width: `${selectedDef.stats.airtime * 10}%` }} />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <Flame className="w-3.5 h-3.5 text-amber-400" /> Nitro Boost
                      </span>
                      <div className="w-36 bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                        <div className="bg-amber-400 h-full rounded-full transition-all duration-300" style={{ width: `${selectedDef.stats.boost * 10}%` }} />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-rose-400" /> Resilience
                      </span>
                      <div className="w-36 bg-slate-800/80 h-2 rounded-full overflow-hidden border border-white/5">
                        <div className="bg-rose-400 h-full rounded-full transition-all duration-300" style={{ width: `${selectedDef.stats.resilience * 10}%` }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Outfit & Patterns */}
            {activeTab === 'outfit' && (
              <div className="space-y-4">
                {/* Pattern Selection */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <label className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 block mb-2">
                    Jacket Print & Livery
                  </label>
                  <div className="space-y-2">
                    {PATTERNS.map((pat) => (
                      <button
                        key={pat.id}
                        onClick={() => handleApplyCustom({ jacketPattern: pat.id })}
                        className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${
                          customDraft.jacketPattern === pat.id
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-md shadow-cyan-500/10'
                            : 'bg-slate-900/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200 border border-transparent'
                        }`}
                      >
                        <div>
                          <div className="font-race font-bold text-white">{pat.label}</div>
                          <div className="text-[10px] text-slate-400">{pat.desc}</div>
                        </div>
                        {customDraft.jacketPattern === pat.id && <Check className="w-4 h-4 text-cyan-400" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Jacket Color Swatches */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <div className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 mb-2 flex items-center justify-between">
                    <span>Jacket Fabric Color</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{customDraft.jacketColor}</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {PALETTES.map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ jacketColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.jacketColor === c.hex ? 'border-white scale-110 shadow-lg ring-2 ring-cyan-400' : 'border-transparent opacity-80 hover:opacity-100 hover:scale-105'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>

                {/* Pants Color Swatches */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <div className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 mb-2 flex items-center justify-between">
                    <span>Pants Fabric Color</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{customDraft.pantsColor}</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {PALETTES.map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ pantsColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.pantsColor === c.hex ? 'border-white scale-110 shadow-lg ring-2 ring-cyan-400' : 'border-transparent opacity-80 hover:opacity-100 hover:scale-105'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Helmets, Visors, Board/Skis */}
            {activeTab === 'gear' && (
              <div className="space-y-4">
                {/* Board / Skis Graphics */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <div className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 mb-2 flex items-center justify-between">
                    <span>{selectedDef.vehicleType === 'skis' ? 'Skis Top-Sheet Graphic' : 'Board Deck Graphics'}</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{customDraft.boardColor}</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {PALETTES.map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ boardColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.boardColor === c.hex ? 'border-white scale-110 shadow-lg ring-2 ring-cyan-400' : 'border-transparent opacity-80 hover:opacity-100 hover:scale-105'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>

                {/* Helmet Shell */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <div className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 mb-2 flex items-center justify-between">
                    <span>Aero Helmet Shell</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{customDraft.helmetColor}</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {PALETTES.map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ helmetColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.helmetColor === c.hex ? 'border-white scale-110 shadow-lg ring-2 ring-cyan-400' : 'border-transparent opacity-80 hover:opacity-100 hover:scale-105'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>

                {/* Visor Goggles */}
                <div className="bg-slate-950/60 border border-white/10 rounded-2xl p-4">
                  <div className="text-[11px] font-race font-extrabold uppercase tracking-widest text-slate-400 mb-2 flex items-center justify-between">
                    <span>UV Polarized Visor Tint</span>
                    <span className="text-[10px] text-cyan-400 font-mono">{customDraft.visorColor}</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {PALETTES.map((c) => (
                      <button
                        key={c.hex}
                        onClick={() => handleApplyCustom({ visorColor: c.hex })}
                        style={{ backgroundColor: c.hex }}
                        className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer ${
                          customDraft.visorColor === c.hex ? 'border-white scale-110 shadow-lg ring-2 ring-cyan-400' : 'border-transparent opacity-80 hover:opacity-100 hover:scale-105'
                        }`}
                        title={c.name}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
