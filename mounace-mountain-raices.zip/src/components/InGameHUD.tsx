import React from 'react';
import { RunStats, WeatherInfo } from '../types/game';
import { 
  Pause, 
  Volume2, 
  VolumeX, 
  Flame, 
  ChevronLeft, 
  ChevronRight, 
  ArrowUp,
  Crown,
  Heart,
  Skull
} from 'lucide-react';
import { sound } from '../game/audio';
import { getSavedLanguage, t } from '../game/i18n';

interface InGameHUDProps {
  stats: RunStats;
  weather: WeatherInfo | null;
  activePowerUps?: any[];
  recentTrick?: any;
  nearMissFlash?: boolean;
  soundEnabled: boolean;
  isVip?: boolean;
  onPause: () => void;
  onToggleSound: () => void;
  onCycleWeather: () => void;
  onSteerTouch: (val: number) => void;
  onJumpTouch: () => void;
  onBoostTouch: (active: boolean) => void;
}

export const InGameHUD: React.FC<InGameHUDProps> = ({
  stats,
  weather,
  soundEnabled,
  isVip = false,
  onPause,
  onToggleSound,
  onCycleWeather,
  onSteerTouch,
  onJumpTouch,
  onBoostTouch,
}) => {
  const lang = getSavedLanguage();

  const triggerHaptic = (ms: number = 20) => {
    try {
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
        navigator.vibrate(ms);
      }
    } catch {
      // Ignore vibration error on unsupported platforms
    }
  };

  const currentLives = stats.lives !== undefined ? stats.lives : 3;
  const maxLives = stats.maxLives || 3;

  return (
    <div className="absolute inset-0 pointer-events-none select-none flex flex-col justify-between p-2 sm:p-5 overflow-hidden">
      {/* 1. Dynamic Blizzard Frost Vignette */}
      {weather && weather.frostVignette > 0.05 && (
        <div 
          className="absolute inset-0 pointer-events-none transition-opacity duration-500 z-0"
          style={{
            opacity: weather.frostVignette * 0.7,
            background: 'radial-gradient(circle at 50% 50%, transparent 55%, rgba(186, 230, 253, 0.3) 85%, rgba(224, 242, 254, 0.6) 100%)',
          }}
        />
      )}

      {/* 2. Top Perimeter Status Cluster */}
      <div className="relative z-10 flex items-start justify-between gap-2 sm:gap-4 flex-wrap">
        
        {/* Top-Left Cluster: Pure Speed & Distance */}
        <div className="flex flex-col items-start gap-1 sm:gap-2">
          {/* Speed & Distance Card */}
          <div className="bg-slate-900/90 backdrop-blur-xl border-2 border-cyan-500/40 rounded-2xl px-3.5 sm:px-5 py-2 sm:py-2.5 shadow-[0_0_20px_rgba(6,182,212,0.25)] flex items-center gap-3 sm:gap-5">
            <div>
              <div className="text-[8px] sm:text-[9px] text-cyan-400 font-race uppercase tracking-widest font-black">{t('speed', lang)}</div>
              <div className="flex items-baseline gap-0.5 sm:gap-1">
                <span className="font-race text-xl sm:text-3xl font-black text-white tabular-nums tracking-tight">
                  {stats.speed}
                </span>
                <span className="text-[8px] sm:text-[10px] font-race font-bold text-cyan-400">KM/H</span>
              </div>
            </div>

            <div className="h-6 sm:h-7 w-[2px] bg-cyan-500/30" />

            <div>
              <div className="text-[8px] sm:text-[9px] text-slate-400 font-race uppercase tracking-widest font-bold">{t('distance', lang)}</div>
              <div className="flex items-baseline gap-0.5 sm:gap-1">
                <span className="font-race text-base sm:text-2xl font-bold text-slate-100 tabular-nums">
                  {stats.distance}
                </span>
                <span className="text-[8px] sm:text-[10px] font-race font-semibold text-slate-400">M</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top-Center: Hardcore 1 LIFE Sudden Death HUD + Mode Widget + VIP + Weather */}
        <div className="flex flex-col items-center gap-1.5 sm:gap-2">
          <div className="flex items-center gap-2 flex-wrap justify-center">
            {/* HARDCORE 1 LIFE CONTAINER (Requested: All modes only 1 life! 1 hit = wipeout) */}
            <div className="bg-gradient-to-r from-rose-950/95 via-slate-900/95 to-rose-950/95 backdrop-blur-xl border-2 border-rose-500/80 rounded-2xl px-3 sm:px-4 py-1.5 shadow-[0_0_25px_rgba(244,63,94,0.5)] flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-race font-black text-rose-400 uppercase tracking-widest">
                <Skull className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                <span>1 LIFE</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg animate-pulse drop-shadow-[0_0_12px_rgba(244,63,94,1)]">
                  {currentLives > 0 ? '❤️' : '💀'}
                </span>
                <span className="text-[8px] sm:text-[9px] font-mono font-black text-amber-300 bg-rose-900/60 border border-rose-500/50 px-1.5 py-0.5 rounded-md uppercase">
                  1 HIT = WIPEOUT
                </span>
              </div>
            </div>

            {isVip && (
              <div className="bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-950 font-race font-black px-3 py-1 rounded-full shadow-[0_0_20px_rgba(251,191,36,0.6)] text-[10px] tracking-wider uppercase flex items-center gap-1 border-2 border-white/80 animate-pulse">
                <Crown className="w-3.5 h-3.5 fill-current" />
                <span>V.I.P PASS</span>
              </div>
            )}

            {weather && (
              <button
                onClick={() => {
                  sound.playGate();
                  onCycleWeather();
                }}
                title="Click to cycle atmosphere"
                className="hidden sm:flex bg-slate-900/90 hover:bg-slate-800 backdrop-blur-md border border-white/20 rounded-full px-3 py-1 shadow-lg items-center gap-1.5 pointer-events-auto cursor-pointer transition-all hover:scale-105 active:scale-95"
              >
                <span className="text-xs sm:text-sm">{weather.icon}</span>
                <span className="text-[10px] sm:text-[11px] font-race font-bold text-slate-200 uppercase tracking-wide">
                  {weather.name}
                </span>
                {weather.windSpeed > 1 && (
                  <span className="text-[8px] sm:text-[9px] font-race text-cyan-300 font-semibold bg-cyan-950/60 px-1.5 py-0.5 rounded-full border border-cyan-800/40">
                    💨 {weather.windSpeed.toFixed(1)}m/s
                  </span>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Top-Right: Score, Multiplier, Coins, Gems, Sound, Pause */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          <div className="bg-slate-900/90 backdrop-blur-xl border-2 border-amber-500/40 rounded-2xl px-3.5 sm:px-4 py-1.5 sm:py-2.5 shadow-[0_0_20px_rgba(245,158,11,0.25)] flex items-center gap-3 sm:gap-4 text-right">
            <div>
              <div className="text-[8px] sm:text-[9px] text-amber-400 font-race uppercase tracking-widest font-black">{t('score', lang)}</div>
              <div className="font-race text-lg sm:text-2xl font-black text-amber-300 tabular-nums">
                {stats.score.toLocaleString()}
              </div>
            </div>

            {stats.multiplier > 1 && (
              <div className="bg-gradient-to-br from-amber-500 to-rose-600 text-white font-race font-black px-1.5 py-0.5 rounded-md text-[9px] sm:text-[10px] tabular-nums shadow-sm">
                x{stats.multiplier.toFixed(1)}
              </div>
            )}

            <div className="flex flex-col gap-0.5 text-[11px] sm:text-xs">
              <div className="flex items-center gap-1 font-race font-bold text-amber-300 tabular-nums">
                <span>🪙</span>
                <span>{stats.coinsCollected}</span>
              </div>
              <div className="flex items-center gap-1 font-race font-bold text-cyan-300 tabular-nums">
                <span>💎</span>
                <span>{stats.gemsCollected}</span>
              </div>
            </div>
          </div>

          <button
            onClick={onToggleSound}
            className="w-10 h-10 sm:w-11 sm:h-11 flex items-center justify-center bg-slate-900/90 hover:bg-slate-800 backdrop-blur-xl border-2 border-white/20 border-b-4 border-b-slate-700 active:border-b-2 active:translate-y-0.5 rounded-2xl text-slate-300 hover:text-white transition-all pointer-events-auto cursor-pointer shadow-lg hover:shadow-[0_0_15px_rgba(56,189,248,0.4)] hover:scale-105 active:scale-95"
            aria-label="Sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          <button
            onClick={() => {
              sound.playJump();
              onPause();
            }}
            className="w-10 h-10 sm:w-11 sm:h-11 flex items-center justify-center bg-slate-900/90 hover:bg-slate-800 backdrop-blur-xl border-2 border-white/20 border-b-4 border-b-slate-700 active:border-b-2 active:translate-y-0.5 rounded-2xl text-slate-300 hover:text-white transition-all pointer-events-auto cursor-pointer shadow-lg hover:shadow-[0_0_15px_rgba(56,189,248,0.4)] hover:scale-105 active:scale-95"
            aria-label="Pause Game"
          >
            <Pause className="w-4 h-4 text-slate-200" />
          </button>
        </div>
      </div>

      {/* 3. Bottom Screen: 10X Cooler 3D Touch Arcade Driving Pedals */}
      <div className="w-full flex items-end justify-between px-2 sm:px-6 pb-2 sm:pb-4 pointer-events-auto">
        {/* Left Touch Pad: 3D Beveled Left / Right Steering Pedals */}
        <div className="flex items-center gap-2 sm:gap-3 touch-none">
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerHaptic(15);
              onSteerTouch(-1);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              onSteerTouch(0);
            }}
            onPointerCancel={() => onSteerTouch(0)}
            onPointerLeave={() => onSteerTouch(0)}
            className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-b from-slate-800 to-slate-950 border-2 border-cyan-400/50 border-b-4 border-b-cyan-700 active:border-b-2 active:translate-y-1 rounded-3xl flex flex-col items-center justify-center text-white active:bg-cyan-500/80 shadow-[0_0_25px_rgba(6,182,212,0.35)] hover:shadow-[0_0_35px_rgba(6,182,212,0.65)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
            aria-label="Steer Left"
          >
            <ChevronLeft className="w-8 h-8 sm:w-10 sm:h-10 text-cyan-300 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
            <span className="text-[9px] font-race font-black text-cyan-400 -mt-1">&larr; LEFT</span>
          </button>

          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerHaptic(15);
              onSteerTouch(1);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              onSteerTouch(0);
            }}
            onPointerCancel={() => onSteerTouch(0)}
            onPointerLeave={() => onSteerTouch(0)}
            className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-b from-slate-800 to-slate-950 border-2 border-cyan-400/50 border-b-4 border-b-cyan-700 active:border-b-2 active:translate-y-1 rounded-3xl flex flex-col items-center justify-center text-white active:bg-cyan-500/80 shadow-[0_0_25px_rgba(6,182,212,0.35)] hover:shadow-[0_0_35px_rgba(6,182,212,0.65)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
            aria-label="Steer Right"
          >
            <ChevronRight className="w-8 h-8 sm:w-10 sm:h-10 text-cyan-300 drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
            <span className="text-[9px] font-race font-black text-cyan-400 -mt-1">RIGHT &rarr;</span>
          </button>
        </div>

        {/* Right Touch Pad: 3D Beveled Nitro Boost & Jump Arcade Buttons */}
        <div className="flex items-center gap-2 sm:gap-3 touch-none">
          {/* Speed Boost Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerHaptic(25);
              onBoostTouch(true);
            }}
            onPointerUp={(e) => {
              e.preventDefault();
              onBoostTouch(false);
            }}
            onPointerCancel={() => onBoostTouch(false)}
            onPointerLeave={() => onBoostTouch(false)}
            className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-tr from-amber-500 via-orange-500 to-red-500 border-2 border-amber-200 border-b-4 border-b-orange-800 active:border-b-2 active:translate-y-1 rounded-3xl flex flex-col items-center justify-center text-slate-950 font-race font-black text-[10px] sm:text-xs shadow-[0_0_30px_rgba(245,158,11,0.6)] hover:shadow-[0_0_45px_rgba(245,158,11,0.85)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
            aria-label="Nitro Boost"
          >
            <Flame className="w-6 h-6 sm:w-7 sm:h-7 fill-current mb-0.5 animate-pulse" />
            <span className="tracking-wider">{t('boostTouch', lang)}</span>
          </button>

          {/* Jump Button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              triggerHaptic(30);
              onJumpTouch();
            }}
            className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-tr from-cyan-300 via-sky-400 to-blue-600 border-2 border-cyan-100 border-b-4 border-b-blue-800 active:border-b-2 active:translate-y-1 rounded-3xl flex flex-col items-center justify-center text-slate-950 font-race font-black text-[10px] sm:text-xs shadow-[0_0_30px_rgba(6,182,212,0.6)] hover:shadow-[0_0_45px_rgba(6,182,212,0.85)] hover:scale-105 active:scale-95 transition-all cursor-pointer"
            aria-label="Jump & Stunt"
          >
            <ArrowUp className="w-6 h-6 sm:w-7 sm:h-7 stroke-[3.5] mb-0.5 animate-bounce" />
            <span className="tracking-wider">{t('jumpTouch', lang)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
