import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../game/audio';
import { Zap, Sparkles, Coins, X, Target, Flame, RotateCcw } from 'lucide-react';

interface PowerTapModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  onReward: (rewardCoins: number, rewardGems: number) => void;
  onClose: () => void;
}

export const PowerTapModal: React.FC<PowerTapModalProps> = ({
  coins,
  gems,
  isVip = false,
  onReward,
  onClose,
}) => {
  const [position, setPosition] = useState(50);
  const [isOscillating, setIsOscillating] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [attemptsLeft, setAttemptsLeft] = useState(3);
  const [combo, setCombo] = useState(0);
  const [totalWonCoins, setTotalWonCoins] = useState(0);
  const [totalWonGems, setTotalWonGems] = useState(0);
  const [lastResult, setLastResult] = useState<{
    type: 'perfect' | 'great' | 'miss';
    text: string;
    coins: number;
    gems: number;
  } | null>(null);

  const directionRef = useRef<number>(1);
  const posRef = useRef<number>(50);
  const speedRef = useRef<number>(130);

  const ENTRY_COST_GEMS = isVip ? 0 : 10;
  const canAfford = isVip || gems >= ENTRY_COST_GEMS;

  // Handle start session costing 10 gems (0 for VIP)
  const handleStartSession = () => {
    if (!canAfford) {
      sound.playCrash();
      return;
    }
    sound.playPowerUp();
    if (!isVip) {
      onReward(0, -ENTRY_COST_GEMS);
    }
    setGameStarted(true);
    setAttemptsLeft(3);
    setCombo(0);
    setTotalWonCoins(0);
    setTotalWonGems(0);
    setLastResult(null);
    setIsOscillating(true);
  };

  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const loop = (time: number) => {
      const dt = Math.min((time - lastTime) / 1000, 0.1);
      lastTime = time;

      if (isOscillating) {
        const speed = speedRef.current * (1 + combo * 0.15);
        posRef.current += directionRef.current * speed * dt;

        if (posRef.current >= 100) {
          posRef.current = 100;
          directionRef.current = -1;
        } else if (posRef.current <= 0) {
          posRef.current = 0;
          directionRef.current = 1;
        }

        setPosition(posRef.current);
      }

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isOscillating, combo]);

  const handleTap = () => {
    if (!isOscillating || attemptsLeft <= 0) return;

    setIsOscillating(false);
    const hitPos = posRef.current;

    let wonCoins = 0;
    let wonGems = 0;
    let resultType: 'perfect' | 'great' | 'miss';
    let resultText = '';

    if (hitPos >= 42 && hitPos <= 58) {
      // Perfect green zone!
      resultType = 'perfect';
      wonCoins = 600 + combo * 150;
      wonGems = 5;
      resultText = `🎯 PERFECT HIT! GREEN SWEET SPOT (+${wonCoins} COINS, +${wonGems} 💎)`;
      sound.playStarChime();
      setCombo((prev) => prev + 1);
    } else if ((hitPos >= 28 && hitPos < 42) || (hitPos > 58 && hitPos <= 72)) {
      // Great yellow zone
      resultType = 'great';
      wonCoins = 250 + combo * 50;
      wonGems = 0;
      resultText = `⚡ GREAT TIMING! (+${wonCoins} COINS)`;
      sound.playDoubleCoins();
      setCombo((prev) => prev + 1);
    } else {
      // Missed red zone
      resultType = 'miss';
      wonCoins = 50;
      wonGems = 0;
      resultText = `❌ MISSED CENTER! (+50 CONSOLATION COINS)`;
      sound.playCrash();
      setCombo(0);
    }

    setLastResult({ type: resultType, text: resultText, coins: wonCoins, gems: wonGems });
    setTotalWonCoins((prev) => prev + wonCoins);
    setTotalWonGems((prev) => prev + wonGems);
    onReward(wonCoins, wonGems);

    const nextAttempts = attemptsLeft - 1;
    setAttemptsLeft(nextAttempts);

    if (nextAttempts > 0) {
      setTimeout(() => {
        setIsOscillating(true);
      }, 1000);
    }
  };

  // Keyboard Spacebar listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        if (!gameStarted) {
          handleStartSession();
        } else {
          handleTap();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOscillating, attemptsLeft, gameStarted, canAfford]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-emerald-500/30 rounded-3xl shadow-2xl p-6 text-white flex flex-col items-center">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-bold mb-1">
            <Zap className="w-3.5 h-3.5" />
            REACTION TIMING CHALLENGE
          </div>
          <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-400 font-race tracking-wider">
            POWER TAP
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Tap the button or press Space exactly when the cursor is in the green zone! Entry: <strong className="text-cyan-300 font-bold">10 💎</strong>
          </p>
        </div>

        {/* User Balance */}
        <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-1.5 rounded-full border border-slate-800 text-xs mb-3">
          <span className="flex items-center gap-1 text-amber-300 font-bold font-race">
            🪙 {coins.toLocaleString()}
          </span>
          <span className="flex items-center gap-1 text-cyan-300 font-bold font-race">
            💎 {gems.toLocaleString()}
          </span>
          {gameStarted && (
            <span className="text-slate-300 font-semibold font-race">
              Attempts: <strong className="text-amber-400">{attemptsLeft}/3</strong>
            </span>
          )}
        </div>

        {/* Power Meter Gauge */}
        <div className="w-full bg-slate-950/90 rounded-2xl p-5 border border-slate-800 flex flex-col items-center my-2 shadow-inner">
          <div className="w-full flex justify-between text-[10px] font-race font-bold text-slate-400 mb-2 uppercase">
            <span className="text-rose-400">0% Slow</span>
            <span className="text-emerald-400 font-black">Sweet Spot (50%)</span>
            <span className="text-rose-400">100% Fast</span>
          </div>

          {/* Bar track */}
          <div className="relative w-full h-12 bg-slate-800/80 rounded-xl overflow-hidden border-2 border-slate-700 shadow-inner">
            {/* Red left miss */}
            <div className="absolute inset-y-0 left-0 w-[28%] bg-rose-950/60" />
            {/* Yellow left great */}
            <div className="absolute inset-y-0 left-[28%] w-[14%] bg-amber-500/40" />
            {/* Green center sweet spot */}
            <div className="absolute inset-y-0 left-[42%] w-[16%] bg-gradient-to-r from-emerald-500 to-teal-400 shadow-[0_0_15px_rgba(16,185,129,0.8)] flex items-center justify-center">
              <span className="text-[10px] font-black font-race text-slate-950 drop-shadow">GREEN ZONE</span>
            </div>
            {/* Yellow right great */}
            <div className="absolute inset-y-0 left-[58%] w-[14%] bg-amber-500/40" />
            {/* Red right miss */}
            <div className="absolute inset-y-0 left-[72%] w-[28%] bg-rose-950/60" />

            {/* Moving Cursor Indicator */}
            <div
              className="absolute top-0 bottom-0 w-2.5 bg-white border-2 border-slate-950 rounded-full shadow-[0_0_12px_#ffffff] transition-none -ml-1.5 z-10"
              style={{ left: `${position}%` }}
            />
          </div>

          {/* Combo Multiplier Tracker */}
          {combo > 0 && (
            <div className="mt-3 flex items-center gap-1.5 text-xs font-race font-black text-amber-300">
              <Flame className="w-4 h-4 text-orange-500 animate-bounce" />
              <span>COMBO STREAK x{combo}!</span>
            </div>
          )}
        </div>

        {/* Last Result Message */}
        {lastResult && (
          <div
            className={`w-full p-2.5 my-2 rounded-xl text-xs font-race font-bold text-center border ${
              lastResult.type === 'perfect'
                ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-200'
                : lastResult.type === 'great'
                ? 'bg-amber-950/80 border-amber-500/60 text-amber-200'
                : 'bg-rose-950/80 border-rose-500/60 text-rose-200'
            }`}
          >
            {lastResult.text}
          </div>
        )}

        {/* Tap Action / Start Session Button */}
        <div className="w-full mt-3">
          {!gameStarted || attemptsLeft <= 0 ? (
            <button
              onClick={handleStartSession}
              disabled={!canAfford}
              className={`w-full py-4 px-6 rounded-2xl font-race font-black text-base tracking-wider uppercase transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg ${
                canAfford
                  ? 'bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-500 hover:from-emerald-300 hover:to-cyan-400 text-slate-950 shadow-emerald-500/25 hover:scale-[1.02] active:scale-[0.98]'
                  : 'bg-rose-950/60 border border-rose-800 text-rose-300 cursor-not-allowed'
              }`}
            >
              <Zap className="w-5 h-5 fill-current" />
              {isVip ? (
                <span>PLAY POWER TAP (FREE WITH VIP 👑)</span>
              ) : canAfford ? (
                <span>{attemptsLeft <= 0 ? 'PLAY AGAIN (COST: 10 💎)' : 'START POWER TAP (10 💎)'}</span>
              ) : (
                <span>NEED 10 💎 TO PLAY</span>
              )}
            </button>
          ) : (
            <button
              onClick={handleTap}
              disabled={!isOscillating}
              className={`w-full py-5 px-6 rounded-2xl font-race font-black text-lg tracking-wider uppercase transition-all flex items-center justify-center gap-3 cursor-pointer shadow-xl ${
                isOscillating
                  ? 'bg-gradient-to-r from-emerald-400 to-green-500 hover:scale-[1.03] active:scale-[0.96] text-slate-950 shadow-emerald-500/40 animate-pulse'
                  : 'bg-slate-800 text-slate-400 cursor-wait'
              }`}
            >
              <Target className="w-6 h-6 stroke-[3]" />
              <span>TAP NOW! (SPACE)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
