import React, { useState } from 'react';
import { sound } from '../game/audio';
import { HelpCircle, CheckCircle2, XCircle, Coins, Sparkles, X, ArrowRight, Award } from 'lucide-react';

interface QuizQuestion {
  id: number;
  question: string;
  category: string;
  options: {
    text: string;
    isCorrect: boolean;
  }[];
  explanation: string;
}

const QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'What is the best vehicle to climb a steep, deep snowy mountain?',
    category: 'MOUNTAIN VEHICLES',
    options: [
      { text: '🚜 Snowcat / Tracked Groomer', isCorrect: true },
      { text: '🚲 City bicycle with skinny tires', isCorrect: false },
      { text: '🏎️ Formula 1 asphalt racer', isCorrect: false },
    ],
    explanation: 'Wide tracks distribute vehicle weight and provide maximum grip on deep powder without sinking!',
  },
  {
    id: 2,
    question: 'Which drivetrain system is ideal for snowy, icy mountain passes?',
    category: 'AUTO MECHANICS',
    options: [
      { text: '🚙 All-Wheel Drive (AWD / 4WD)', isCorrect: true },
      { text: '🚗 Rear-Wheel Drive only (RWD)', isCorrect: false },
      { text: '🛹 Non-powered coaster chassis', isCorrect: false },
    ],
    explanation: 'AWD sends active power to all 4 tires simultaneously to maximize traction and prevent wheel slip!',
  },
  {
    id: 3,
    question: 'What piece of safety gear is vital when racing at 80 km/h down a steep slope?',
    category: 'ALPINE SAFETY',
    options: [
      { text: '🪖 Certified impact helmet & anti-fog goggles', isCorrect: true },
      { text: '🧢 Plain cotton baseball cap', isCorrect: false },
      { text: '🕶️ Sunglasses alone with no head protection', isCorrect: false },
    ],
    explanation: 'A certified helmet absorbs high-velocity impact energy and prevents head trauma in case of a tumble.',
  },
  {
    id: 4,
    question: 'Which mountain vehicle has rear rubber tracks and twin front steering skis?',
    category: 'SNOW MACHINES',
    options: [
      { text: '🛷 High-performance Snowmobile', isCorrect: true },
      { text: '🚌 Double-decker municipal bus', isCorrect: false },
      { text: '🛴 Commuter kick scooter', isCorrect: false },
    ],
    explanation: 'Snowmobiles combine front steering skis with a track belt for rapid traversing of powdery ridges!',
  },
  {
    id: 5,
    question: 'What substance is applied to ski and snowboard bases for maximum glide speed?',
    category: 'GEAR TUNING',
    options: [
      { text: '🕯️ Hydrocarbon Paraffin Hot Ski Wax', isCorrect: true },
      { text: '🌻 Kitchen sunflower cooking oil', isCorrect: false },
      { text: '🧴 Liquid dish soap and water', isCorrect: false },
    ],
    explanation: 'Hot wax fills microscopic pores in the base, repelling friction moisture for ultra-smooth gliding.',
  },
  {
    id: 6,
    question: 'What surfing maneuver do you perform when a heavy breaking wave approaches you?',
    category: 'OCEAN SURF',
    options: [
      { text: '🌊 Duck Dive (submerge under the wave with your board)', isCorrect: true },
      { text: '🤸 Stand still and jump on the spot', isCorrect: false },
      { text: '🏖️ Abandon board and swim backward to the sand', isCorrect: false },
    ],
    explanation: 'The duck dive pushes you and your board beneath the wave turbulence, escaping the rolling whitewash.',
  },
  {
    id: 7,
    question: 'On a steep, prolonged mountain descent, how should you control a car’s speed?',
    category: 'MOUNTAIN DRIVING',
    options: [
      { text: '⚙️ Engine braking by downshifting into a lower gear', isCorrect: true },
      { text: '🛑 Riding the brake pedal continuously all the way down', isCorrect: false },
      { text: '🏎️ Flooring the accelerator around mountain hairpins', isCorrect: false },
    ],
    explanation: 'Engine braking prevents brake pads from overheating and suffering catastrophic brake fade!',
  },
];

interface MountainQuizModalProps {
  coins: number;
  gems: number;
  isVip?: boolean;
  onReward: (rewardCoins: number, rewardGems: number) => void;
  onClose: () => void;
}

export const MountainQuizModal: React.FC<MountainQuizModalProps> = ({
  coins,
  gems,
  isVip = false,
  onReward,
  onClose,
}) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [streak, setStreak] = useState(0);
  const [totalEarnedCoins, setTotalEarnedCoins] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);

  const ENTRY_COST_GEMS = isVip ? 0 : 10;
  const canAfford = isVip || gems >= ENTRY_COST_GEMS;

  const q = QUESTIONS[currentIdx];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;

    if (!canAfford && streak === 0) {
      sound.playCrash();
      return;
    }

    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = q.options[idx].isCorrect;
    if (isCorrect) {
      sound.playDoubleCoins();
      const bonusCoins = 300 + streak * 100;
      const bonusGems = 2;
      setStreak((prev) => prev + 1);
      setTotalEarnedCoins((prev) => prev + bonusCoins);
      // If first question in run, deduct entry fee (0 if VIP)
      const netGems = (streak === 0 && !isVip) ? bonusGems - 10 : bonusGems;
      onReward(bonusCoins, netGems);
    } else {
      sound.playCrash();
      const netGems = (streak === 0 && !isVip) ? -10 : 0;
      setStreak(0);
      onReward(50, netGems); // Consolation 50 coins
    }
  };

  const handleNext = () => {
    setSelectedOption(null);
    setIsAnswered(false);
    setCurrentIdx((prev) => (prev + 1) % QUESTIONS.length);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-cyan-500/30 rounded-3xl shadow-2xl p-6 text-white flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/30">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">{q.category}</span>
              <h2 className="text-xl font-black text-white font-race">MOUNTAIN TRIVIA</h2>
            </div>
          </div>
          <div className="flex items-center gap-2 pr-8">
            <span className="text-xs bg-slate-800 border border-slate-700 px-2.5 py-1 rounded-full text-slate-300 font-race">
              Question {currentIdx + 1}/{QUESTIONS.length}
            </span>
          </div>
        </div>

        {/* Balance & Streak Bar */}
        <div className="w-full flex items-center justify-between px-3 py-1.5 bg-slate-950/70 border border-slate-800 rounded-xl text-xs mb-3 font-race">
          <div className="flex items-center gap-3">
            <span className="text-amber-300 font-bold">🪙 {coins.toLocaleString()}</span>
            <span className="text-cyan-300 font-bold">💎 {gems.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-emerald-400 font-bold">Streak: {streak} 🔥</span>
            <span className="text-cyan-300 text-[11px]">Cost: 10 💎 / round</span>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-slate-800/40 border border-slate-700/60 rounded-2xl p-4 mb-4">
          <h3 className="text-base sm:text-lg font-black text-slate-100 leading-snug font-race">
            {q.question}
          </h3>
        </div>

        {/* Options */}
        <div className="space-y-2.5 mb-4">
          {q.options.map((opt, idx) => {
            const isChosen = selectedOption === idx;
            let btnStyle = 'border-slate-700/80 bg-slate-800/60 hover:bg-slate-700/60 text-slate-200';

            if (isAnswered) {
              if (opt.isCorrect) {
                btnStyle = 'border-emerald-500 bg-emerald-950/80 text-emerald-200 ring-2 ring-emerald-500/50';
              } else if (isChosen && !opt.isCorrect) {
                btnStyle = 'border-rose-500 bg-rose-950/80 text-rose-200 ring-2 ring-rose-500/50';
              } else {
                btnStyle = 'opacity-40 border-slate-800 bg-slate-900/60 text-slate-400';
              }
            }

            return (
              <button
                key={idx}
                onClick={() => handleSelect(idx)}
                disabled={isAnswered || (gems < ENTRY_COST_GEMS && streak === 0)}
                className={`w-full p-3.5 rounded-xl border text-left font-bold text-sm transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
              >
                <span>{opt.text}</span>
                {isAnswered && (
                  <div>
                    {opt.isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                    {isChosen && !opt.isCorrect && <XCircle className="w-5 h-5 text-rose-400" />}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Explanation Card */}
        {isAnswered && (
          <div className="p-3 bg-slate-900/90 border border-slate-700/80 rounded-xl mb-4 text-xs text-slate-300">
            <p className="font-semibold text-cyan-300 mb-0.5">ℹ️ Did you know?</p>
            <p>{q.explanation}</p>
          </div>
        )}

        {/* Footer Navigation */}
        <div className="flex items-center justify-between mt-auto pt-2">
          <div className="text-xs text-slate-400 font-race font-bold">
            Total Earned: <span className="text-amber-400">+{totalEarnedCoins.toLocaleString()} 🪙</span>
          </div>

          {isAnswered && (
            <button
              onClick={handleNext}
              className="py-2.5 px-5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black font-race text-xs tracking-wider rounded-xl flex items-center gap-2 cursor-pointer transition-transform hover:scale-105"
            >
              <span>NEXT QUESTION</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
