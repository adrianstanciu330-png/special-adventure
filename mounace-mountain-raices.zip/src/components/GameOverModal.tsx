import React, { useEffect } from 'react';
import { RunStats } from '../types/game';
import { RotateCcw, Palette, Home, Award, Zap, Compass, Flag, Heart } from 'lucide-react';
import { getSavedLanguage, t } from '../game/i18n';
import { sound } from '../game/audio';

interface GameOverModalProps {
  stats: RunStats;
  isNewHighScore: boolean;
  gems: number;
  isVip?: boolean;
  onRevive: () => void;
  onRestart: () => void;
  onOpenCustomizer: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  stats,
  isNewHighScore,
  gems,
  isVip = false,
  onRevive,
  onRestart,
  onOpenCustomizer,
  onMainMenu,
}) => {
  const lang = getSavedLanguage();
  const REVIVE_COST_GEMS = 30;
  const canAffordRevive = isVip || gems >= REVIVE_COST_GEMS;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyR' && canAffordRevive) {
        e.preventDefault();
        onRevive();
      } else if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        onRestart();
      } else if (e.code === 'KeyC') {
        onOpenCustomizer();
      } else if (e.code === 'Escape') {
        onMainMenu();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onRevive, onRestart, onOpenCustomizer, onMainMenu, canAffordRevive]);

  const handleReviveClick = () => {
    if (!canAffordRevive) {
      sound.playCrash();
      return;
    }
    sound.playPowerUp();
    onRevive();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md select-none overflow-y-auto">
      <div className="w-full max-w-lg max-h-[92vh] overflow-y-auto bg-slate-900 border border-slate-700/80 rounded-3xl p-4 sm:p-7 shadow-2xl flex flex-col items-center text-center animate-in fade-in zoom-in-95 duration-200">
        
        {/* Banner */}
        {isNewHighScore ? (
          <div className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 text-slate-950 font-race font-black px-5 py-1.5 rounded-full text-xs sm:text-sm tracking-wider uppercase flex items-center gap-2 mb-3 shadow-lg shadow-amber-500/30">
            <Award className="w-4 h-4 fill-current" />
            <span>{t('newRecord', lang)}</span>
          </div>
        ) : (
          <div className="text-[11px] font-race font-bold text-rose-400 uppercase tracking-widest bg-rose-950/60 border border-rose-800/60 px-4 py-1 rounded-full mb-2">
            {t('wipeout', lang)}
          </div>
        )}

        <h2 className="text-2xl sm:text-4xl font-race font-black text-white tracking-wide mb-1">
          {t('gameOver', lang)}
        </h2>
        <p className="text-[11px] sm:text-xs text-slate-400 mb-4">{t('title', lang)} &bull; {t('subtitle', lang)}</p>

        {/* Big Score Box */}
        <div className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-4 shadow-inner">
          <div className="text-[11px] font-race text-slate-400 uppercase tracking-wider font-semibold">{t('score', lang)}</div>
          <div className="font-race text-3xl sm:text-5xl font-black text-amber-300 tabular-nums">
            {stats.score.toLocaleString()}
          </div>
        </div>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-2 gap-2 sm:gap-3 mb-4 text-left text-xs">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 sm:p-3">
            <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">{t('distanceDownPeak', lang)}</div>
            <div className="font-race text-base sm:text-lg font-bold text-white tabular-nums">
              {stats.distance} <span className="text-[10px] text-slate-400 font-normal">{t('meters', lang)}</span>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 sm:p-3">
            <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">{t('peakSpeed', lang)}</div>
            <div className="font-race text-base sm:text-lg font-bold text-cyan-400 tabular-nums">
              {stats.topSpeed} <span className="text-[10px] text-slate-400 font-normal">km/h</span>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 sm:p-3 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">{t('snowCoins', lang)}</div>
              <div className="font-race text-base sm:text-lg font-bold text-amber-400 tabular-nums">
                +{stats.coinsCollected}
              </div>
            </div>
            <span className="text-xl sm:text-2xl">🪙</span>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-2.5 sm:p-3 flex items-center justify-between">
            <div>
              <div className="text-[10px] text-slate-400 font-race uppercase font-semibold">{t('mountainGems', lang)}</div>
              <div className="font-race text-base sm:text-lg font-bold text-cyan-400 tabular-nums">
                +{stats.gemsCollected}
              </div>
            </div>
            <span className="text-xl sm:text-2xl">💎</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5 sm:gap-3">
          {/* 1. REVIVE BUTTON (Costs 30 diamonds or Free for VIP) */}
          <button
            onClick={handleReviveClick}
            disabled={!canAffordRevive}
            className={`w-full py-4 px-4 rounded-2xl font-race font-black text-sm sm:text-base tracking-wider transition-all flex items-center justify-center gap-2.5 shadow-2xl cursor-pointer ${
              canAffordRevive
                ? 'bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-500 hover:from-emerald-300 hover:to-cyan-400 text-slate-950 border-2 border-emerald-200 border-b-[5px] border-b-emerald-700 active:border-b-2 active:translate-y-1 shadow-[0_0_30px_rgba(16,185,129,0.6)] animate-pulse'
                : 'bg-slate-850/80 border border-slate-700/80 border-b-4 border-b-slate-900 text-slate-500 cursor-not-allowed opacity-75'
            }`}
          >
            <Heart className="w-4 h-4 fill-current text-rose-600 animate-ping" />
            <Zap className="w-4 h-4 fill-current text-slate-950" />
            <span>
              {isVip 
                ? `👑 ${t('vipFreeRevive', lang)}` 
                : `${t('revive', lang)} (30 💎)`
              }
            </span>
            {!isVip && !canAffordRevive && (
              <span className="text-[10px] font-sans font-bold text-rose-300 ml-1">
                ({gems}/30 💎)
              </span>
            )}
          </button>

          {/* 2. Restart Button */}
          <button
            onClick={onRestart}
            className="w-full py-3.5 sm:py-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-race font-black text-sm sm:text-base tracking-wider rounded-2xl border-2 border-cyan-200 border-b-[5px] border-b-cyan-800 active:border-b-2 active:translate-y-1 shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:shadow-[0_0_40px_rgba(6,182,212,0.85)] hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5 stroke-[3] filter drop-shadow" />
            <span>{t('restart', lang)}</span>
          </button>

          {/* 3. Footer Navigation Grid */}
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <button
              onClick={onOpenCustomizer}
              className="py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-race font-bold text-xs sm:text-sm rounded-xl border border-slate-700 border-b-4 border-b-slate-900 active:border-b-0 active:translate-y-1 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Palette className="w-4 h-4 text-cyan-400" />
              <span>{t('customize', lang)}</span>
            </button>

            <button
              onClick={onMainMenu}
              className="py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-race font-bold text-xs sm:text-sm rounded-xl border border-slate-700 border-b-4 border-b-slate-900 active:border-b-0 active:translate-y-1 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Home className="w-4 h-4 text-slate-400" />
              <span>{t('mainMenu', lang)}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
